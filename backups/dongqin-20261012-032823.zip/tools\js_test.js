/* =========================================================
 *  东秦杀 · JS 侧自测（在无头浏览器里跑，见 run_js_test.ps1）
 *
 *  覆盖：编解码往返、状态投影的隐藏信息规则、既有引擎自检回归。
 *  结果写进 #RESULTS，由 PowerShell 读出来。
 * ========================================================= */
(function () {
  'use strict';

  var D = window.GameData;
  var E = window.Engine;
  var Net = window.Net;

  var out = [];
  var queue = [];              // 待执行的测试组

  function ok(name, cond, detail) {
    out.push({ ok: !!cond, name: name, detail: (detail === undefined ? '' : String(detail)) });
  }
  function fail(name, detail) { ok(name, false, detail); }

  /*
   * 测试组**严格串行**执行，一组跑完才跑下一组。
   *
   * 这不是洁癖：好几组都要建局（Engine.initGame 会把 G 整个重置）。
   * 如果让异步组并发跑，"完整对局"那一组还在 await 的时候，
   * 联机组就会把 G 换掉 —— 引擎的 G.gen 检查会让 gameLoop 直接退出，
   * 于是"对局跑完了"这条断言看着过了，其实只跑了 1 条日志。
   */
  function group(title, fn) {
    queue.push({ title: title, fn: fn });
  }

  function runAll() {
    var i = 0;
    function next() {
      if (i >= queue.length) { finish(); return Promise.resolve(); }
      var g = queue[i++];
      return Promise.resolve().then(g.fn).catch(function (e) {
        fail('[' + g.title + '] 抛出异常', (e && e.message) || String(e));
      }).then(next);
    }
    return next();
  }

  function sleep(ms) { return new Promise(function (r) { setTimeout(r, ms); }); }

  /* 只有带 ?net=<服务器地址> 时才跑网络测试 */
  var NET_BASE = null;
  try { NET_BASE = new URLSearchParams(location.search).get('net'); } catch (e) { /* 老浏览器 */ }

  /* ---------------------------------------------------------
   *  1. 编解码（Net.selfTest 内部已覆盖大部分）
   * --------------------------------------------------------- */
  group('编解码', function () {
    var r = Net.selfTest();
    r.items.forEach(function (it) {
      // 「投影」那几条需要有对局才能测，缺对局时跳过而不是算失败
      if (!it.ok && it.name.indexOf('投影') === 0) return;
      ok('[codec] ' + it.name, it.ok, it.detail);
    });
  });

  /* ---------------------------------------------------------
   *  2. 投影 —— 需要一局真实的对局状态
   * --------------------------------------------------------- */
  var G = null;

  group('建局', function () {
    E.initGame({ count: 5, mode: 'A', deal: 3, aiOthers: true,
                 protect: true, hotseat: false, networkRule: false });
    G = window.G;

    // 给每个座位发一个不重复的武将（真实流程里这一步由选角界面完成）
    var taken = {};
    G.players.forEach(function (p) {
      var c = p.charChoices.length
        ? p.charChoices[0]
        : D.CHARACTERS.filter(function (x) { return !taken[x.id]; })[0];
      p.char = c;
      taken[c.id] = 1;
    });
    E.finalizeGame();
    Net.indexDeck();

    // 发点手牌，否则测不出"别人的手牌有没有被藏起来"
    G.players.forEach(function (p) {
      for (var i = 0; i < 4; i++) { var c = G.deck.pop(); if (c) p.hand.push(c); }
    });
    // 挂一张装备和一张延时牌，验证它们必须原样下发
    G.players[2].equips.weapon = G.deck.pop();
    G.players[3].judge.push(G.deck.pop());
    G.players[1].marks.slideTurn = G.turnId;
    G.players[1].marks.slideFrom = 0;
    G.players[4].marks.net = 2;

    ok('建局成功且人手 4 张', G.players.length === 5 && G.players[0].hand.length === 4);
    ok('牌堆索引登记了全部 160 张', Net.uidIndex.size >= 160, Net.uidIndex.size);
  });

  group('投影', function () {
    if (!G) { fail('投影需要先建局'); return; }

    var me0 = Net.project(0, false);
    var me1 = Net.project(1, false);
    var spec = Net.project(-1, false);

    ok('投影不含 humanSeat（客户端自己持有座位）', !('humanSeat' in me0));
    ok('投影不含牌堆内容（只有张数）',
       !('deck' in me0) && !('discard' in me0) && typeof me0.deckCount === 'number');

    // 自己的手牌必须是真牌
    ok('座位 0 的投影里自己的手牌是真牌',
       me0.players[0].hand.every(function (c) { return !c.hidden && c.uid > 0; }));
    ok('座位 1 的投影里座位 0 的手牌是占位牌',
       me1.players[0].hand.every(function (c) { return c.hidden && c.uid < 0; }));
    ok('座位 1 的投影里自己的手牌是真牌',
       me1.players[1].hand.every(function (c) { return !c.hidden && c.uid > 0; }));

    // 关键：占位牌必须**等长**，引擎/UI 的合法目标计算依赖 .length
    ok('占位牌数量与被藏起来的手牌数量一致',
       me1.players[0].hand.length === G.players[0].hand.length,
       me1.players[0].hand.length + ' vs ' + G.players[0].hand.length);
    ok('每个人看到的"别人手牌数"都等于真实张数',
       me0.players.every(function (p, i) { return p.hand.length === G.players[i].hand.length; }));

    // 旁观者
    ok('旁观者看不到任何人的真手牌',
       spec.players.every(function (p) { return p.hand.every(function (c) { return c.hidden; }); }));

    // 装备 / 通知栏是公开信息，必须原样下发
    ok('装备区照常下发（是公开信息）',
       me1.players[2].equips.weapon && me1.players[2].equips.weapon.uid === G.players[2].equips.weapon.uid);
    ok('通知栏照常下发（是公开信息）',
       me1.players[3].judge.length === 1 && me1.players[3].judge[0].uid === G.players[3].judge[0].uid);

    // 身份
    var deanSeat = -1;
    G.players.forEach(function (p, i) { if (p.identity === 'dean') deanSeat = i; });
    ok('院长的身份对所有人公开',
       me0.players[deanSeat].identity === 'dean' && spec.players[deanSeat].identity === 'dean');
    var other = G.players.findIndex(function (p, i) { return i !== deanSeat && i !== 0; });
    ok('自己的身份自己看得到', me0.players[0].identity === G.players[0].identity);
    ok('别人的身份在公开前是 null',
       me0.players[other].identity === null && spec.players[other].identity === null);

    // 客户端算合法目标要用的字段
    ok('turnId 下发了（客户端算划水限制要用）', me0.turnId === G.turnId);
    ok('marks.slideFrom / slideTurn 下发了',
       me0.players[1].marks.slideTurn === G.turnId && me0.players[1].marks.slideFrom === 0,
       JSON.stringify(me0.players[1].marks));
    ok('marks.net 下发了', me0.players[4].marks.net === 2);

    // 名字：引擎里 name 是 defineProperty 的 getter（不可枚举），必须显式带上
    ok('角色名显式带上（不会被 JSON 丢掉）',
       me0.players.every(function (p, i) { return p.name === G.players[i].char.name; }),
       me0.players[0].name);

    // 武将只传 id，客户端本地解析
    ok('武将只传 charId（省包体）', me0.players[0].charId === G.players[0].char.id);
    ok('charId 能在本地解析成武将对象',
       Net.CHAR_BY_ID[me0.players[0].charId] === G.players[0].char);
  });

  group('日志脱敏', function () {
    if (!G) { fail('日志脱敏需要先建局'); return; }
    var before = G.log.length;
    // 【窃听】【侃山】会把别人手牌的牌名打进日志，联机时必须只给当事人看
    G.log.push({ text: '王磊 观看 董旭 的手牌：上课点名、代课', cls: 'sys',
                 only: [0], redacted: '王磊 查看了 董旭 的手牌（内容仅当事人可见）' });
    G.log.push({ text: '普通公开信息', cls: '' });

    var asSeat0 = Net.project(0, false);
    var asSeat1 = Net.project(1, false);

    function lastText(snap) { return snap.log[snap.log.length - 2].text; }
    ok('当事人能看到日志原文', lastText(asSeat0).indexOf('上课点名') >= 0, lastText(asSeat0));
    ok('其他人只看到脱敏后的日志', lastText(asSeat1).indexOf('上课点名') < 0, lastText(asSeat1));
    ok('脱敏后的日志仍然存在（不是直接删掉）', lastText(asSeat1).length > 0);
    ok('普通日志不受影响', asSeat1.log[asSeat1.log.length - 1].text === '普通公开信息');

    G.log.length = before;
  });

  group('终局全公开', function () {
    if (!G) { fail('终局需要先建局'); return; }
    var fin = Net.project(0, true);
    ok('终局时所有身份都公开',
       fin.players.every(function (p, i) { return p.identity === G.players[i].identity; }));
  });

  /* ---------------------------------------------------------
   *  3. 事件录制与回放
   * --------------------------------------------------------- */
  group('事件录制', function () {
    if (!G) { fail('事件录制需要先建局'); return; }
    G.speed = 0.01;                       // 让演出瞬间结束，测试跑得快一点

    Net.startRecording();
    Net.takeEvents();                     // 清掉包装过程中可能产生的事件

    /* 重入抑制：FX.addToExchange 内部会调 FX.sfx（fx.js:201），
       不抑制的话这里会录到 2 条，客户端出牌区会插两张、音效放两遍。 */
    window.FX.addToExchange('测试者', { name: '代课', suit: null }, '', { response: true, tag: 'x', sfx: 'dodge' });
    var evs = Net.takeEvents();
    ok('addToExchange 只录 1 条（内部对 FX.sfx 的调用被抑制）',
       evs && evs.length === 1 && evs[0].k === 'addToExchange',
       JSON.stringify(evs && evs.map(function (e) { return e.k; })));

    window.FX.sfx('draw');
    evs = Net.takeEvents();
    ok('直接调 FX.sfx 会录 1 条', evs && evs.length === 1 && evs[0].k === 'sfx');

    window.UI.setPhase('draw');
    evs = Net.takeEvents();
    ok('UI.setPhase 会录成 phase 事件', evs && evs.length === 1 && evs[0].k === 'phase' && evs[0].a[0] === 'draw');

    /* 事件里的玩家/卡牌必须是引用化的，不能是活对象 */
    var realCard = G.players[0].hand[0];
    window.FX.floatText(1, '+2 张', 'draw');
    evs = Net.takeEvents();
    ok('floatText 事件参数是纯数据', evs && evs[0].k === 'floatText' && evs[0].a[0] === 1);

    window.FX.turnBanner(G.players[2]);
    evs = Net.takeEvents();
    ok('turnBanner 的玩家参数被引用化成 {__seat}',
       evs && evs[0].k === 'turnBanner' && evs[0].a[0] && evs[0].a[0].__seat === 2,
       JSON.stringify(evs && evs[0].a[0]).slice(0, 60));

    window.FX.judge(realCard, G.deck[0]);
    evs = Net.takeEvents();
    ok('judge 的卡牌参数被引用化成 {__card}',
       evs && evs[0].k === 'judge' && evs[0].a[0] && evs[0].a[0].__card === realCard.uid,
       JSON.stringify(evs && evs[0].a[0]).slice(0, 60));

    ok('取走事件后再取是空的', Net.takeEvents() === null);

    /* 录制关掉之后就不该再产生事件了 */
    Net.stopRecording();
    window.FX.sfx('draw');
    ok('停止录制后不再产生事件', Net.takeEvents() === null);
  });

  group('异步 FX 不会吞掉后续事件', function () {
    if (!G) { fail('需要先建局'); return; }
    G.speed = 0.05;
    Net.startRecording();
    Net.takeEvents();

    // cardPlay 要播几百毫秒。在它还没播完的时候，紧接着发起另一个 FX 调用 ——
    // 这一条**必须**被录到。用"等 promise 结束才归零"的深度计数器会把它静默吃掉
    // （引擎目前逐条 await 所以看不出来，但那是运气不是保证）。
    var playing = window.FX.cardPlay('测试者', G.players[0].hand[0], '目标', { sfx: 'play' });
    window.FX.floatText(1, '同时发生的飘字', 'dmg');

    var evs = Net.takeEvents();
    var kinds = evs ? evs.map(function (e) { return e.k; }) : null;
    ok('异步的 cardPlay 只录 1 条（内部 addToExchange 被抑制）',
       evs && kinds.filter(function (k) { return k === 'cardPlay'; }).length === 1, JSON.stringify(kinds));
    ok('cardPlay 仍在播放时发起的另一个 FX 也被录到（不会被静默吃掉）',
       evs && kinds.indexOf('floatText') >= 0, JSON.stringify(kinds));

    return playing.then(function () {
      Net.stopRecording();
      ok('异步 FX 正常结束', true);
    });
  });

  group('事件回放', function () {
    Net.stopRecording();      // 回放会调 UI.setPhase，别把测试自己的事件录进去
    // 回放不能抛异常，坏事件要被吞掉
    try {
      Net.enqueueEvents([
        { k: 'floatText', a: [0, '+1', 'draw'] },
        { k: 'sfx', a: ['play'] },
        { k: 'phase', a: ['play'] },
        { k: '不存在的类型', a: [] }
      ]);
      ok('回放一串事件不抛异常', true);
    } catch (e) {
      fail('回放一串事件不抛异常', e.message);
    }
  });

  /* ---------------------------------------------------------
   *  4. 网络传输（需要 ?net=<服务器地址>，且 server.py 正在跑）
   * --------------------------------------------------------- */
  if (NET_BASE) {
    group('主机 ↔ 客户端 全链路往返', function () {
      // 用真实的中转服务器，把「房主发帧 / 发询问 → 客户端收 / 作答 → 房主收到答案」
      // 整条链路跑一遍。客户端用同一页面里的第二条连接模拟（传输层完全是真的）。
      var hostInfo, cliInfo, cli, clientGot = [], hostGot = [];

      return Net.connect(NET_BASE, '/api/create', { name: '房主' }).then(function (h) {
        hostInfo = h;
        Net.session = { base: NET_BASE, code: h.code, peer: h.peer, token: h.token,
                        isHost: true, name: '房主' };
        Net.transport = new Net.Transport(NET_BASE, h.code, h.peer, h.token, {
          // 必须转发给**真正的**分发器，否则答案只是被记录、
          // 永远不会走到 hostOnAnswer，测试会误以为"收不到答案"
          onMessage: function (m) { hostGot.push(m); Net._hostOnMessage(m); }
        });
        // 必须 start：send 是 POST 发得出去，但要**收到**客户端的答案
        // 得靠长轮询，不启动轮询就会一直收不到、最后走到超时托管。
        Net.transport.start();
        return Net.connect(NET_BASE, '/api/join', { code: h.code, name: '客户端' });
      }).then(function (c) {
        cliInfo = c;
        cli = new Net.Transport(NET_BASE, c.code, c.peer, c.token, {
          onMessage: function (m) { clientGot.push(m); }
        });
        cli.seq = 0;
        cli.start();
        return sleep(800);
      }).then(function () {
        // 开一局：座位 0/1 是真人
        E.initGame({ count: 5, deal: 3, hotseat: false, humanSeats: [0, 1] });
        var g = window.G;
        g.players.forEach(function (p, i) { p.char = D.CHARACTERS[i]; });
        E.finalizeRoles();
        E.finalizeGame();
        E.dealInitialHands();
        Net.indexDeck();
        Net.recording = false;
        Net.rev = 0;
        Net.dirty = true;
        Net.roster = [
          { peer: hostInfo.peer, name: '房主', seat: 0, online: true, host: true },
          { peer: cliInfo.peer, name: '客户端', seat: 1, online: true }
        ];
        Net._flushFrame();
        return sleep(1200);
      }).then(function () {
        var frame = clientGot.filter(function (m) { return m.data && m.data.t === 'frame'; })[0];
        ok('客户端收到了状态帧', !!frame, JSON.stringify(clientGot.map(function (m) { return m.data && m.data.t; })));
        var s = frame && frame.data.s;
        ok('帧里带了投影后的快照', !!s && s.players.length === 5, s && s.players.length);
        ok('快照里不含 humanSeat（客户端自己持有座位）', s && !('humanSeat' in s));
        ok('快照里不含牌堆内容', s && !('deck' in s) && typeof s.deckCount === 'number');
        // 这条连接模拟的是座位 1，所以座位 1 看到自己的真手牌、别人的全是占位牌
        ok('座位 1 看到自己的真手牌', s && s.players[1].hand.every(function (c) { return !c.hidden; }));
        ok('座位 1 看不到别人的真手牌',
           s && s.players.filter(function (p, i) { return i !== 1; })
                  .every(function (p) { return p.hand.every(function (c) { return c.hidden; }); }),
           s && JSON.stringify(s.players[0].hand.slice(0, 2)));

        // ---- 询问往返 ----
        Net.askTimeoutMs = 8000;
        var g = window.G;
        var askP = Net.remoteAsk(1, {
          kind: 'choice', player: g.players[1], prompt: '测试询问',
          options: [{ key: 'yes', label: '好' }, { key: 'no', label: '不' }]
        });
        return sleep(1000).then(function () {
          var ask = clientGot.filter(function (m) { return m.data && m.data.t === 'ask'; })[0];
          ok('客户端收到了询问', !!ask);
          if (!ask) return;
          ok('询问里带了快照（客户端要用它替换 req 里的引用）', !!ask.data.s);
          ok('询问里的玩家被引用化成 {__seat}',
             ask.data.req.player && ask.data.req.player.__seat === 1,
             JSON.stringify(ask.data.req.player));
          ok('询问里的选项是纯数据', ask.data.req.options.length === 2);

          // 先回一个陈旧/错误的 id，应该被丢掉
          cli.send('host', { t: 'ans', id: 99999, res: { option: 'yes' } });
          return sleep(400).then(function () {
            // 再回正确的
            cli.send('host', { t: 'ans', id: ask.data.id, res: { option: 'no' } });
            return askP.then(function (res) {
              ok('房主确实收到了 ans 消息（不是超时兜底）',
                 hostGot.some(function (m) {
                   return m.data && m.data.t === 'ans' && m.data.id === ask.data.id;
                 }),
                 JSON.stringify(hostGot.map(function (m) { return m.data && m.data.t; })));
              ok('房主收到了客户端的答案，且没被陈旧答案带偏',
                 res && res.option === 'no', JSON.stringify(res));
            });
          });
        });
      }).then(function () {
        // ---- 超时托管 ----
        Net.askTimeoutMs = 1200;
        var g = window.G;
        var t0 = Date.now();
        return Net.remoteAsk(1, {
          kind: 'choice', player: g.players[1], prompt: '没人回答的询问',
          options: [{ key: 'no', label: '放弃' }]
        }).then(function (res) {
          ok('客户端不回答时，主机在超时后自己回收（转 AI 托管）',
             res && res.__auto === true, JSON.stringify(res));
        });
      }).then(function () {
        // ---- 断线的座位直接交给 AI，不等人 ----
        Net.roster[1].online = false;
        return Net.remoteAsk(1, {
          kind: 'choice', player: window.G.players[1], prompt: '掉线的人',
          options: [{ key: 'no', label: '放弃' }]
        }).then(function (res) {
          ok('掉线的座位立刻转 AI 托管（不挂起）', res && res.__auto === true);
        });
      }).then(function () {
        cli.stop();
        Net.transport.stop();
        Net.session = null;
        Net.transport = null;
      });
    });

    group('传输层', function () {
      var host = null;
      return Net.connect(NET_BASE, '/api/create', { name: '测试房主' })
        .then(function (r) {
          host = r;
          ok('建房成功且拿到 4 位房间号', /^\d{4}$/.test(r.code), r.code);
          return Net.connect(NET_BASE, '/api/join', { code: '0000x', name: 'x' })
            .then(function () { fail('加入不存在的房间应该失败'); },
                  function () { ok('加入不存在的房间会报错', true); });
        })
        .then(function () {
          var t = new Net.Transport(NET_BASE, host.code, host.peer, host.token, {});
          return t.send('host', { t: 'hello' }).then(function (r) {
            ok('send 返回 ok', r && r.ok === true, JSON.stringify(r));
          });
        })
        .then(function () {
          // 长轮询：另一个连接发消息，这边要能收到
          var got = [];
          var t = new Net.Transport(NET_BASE, host.code, host.peer, host.token, {
            onMessage: function (m) { got.push(m); }
          });
          t.seq = 0;
          t.start();
          return Net.connect(NET_BASE, '/api/join', { code: host.code, name: '测试玩家' })
            .then(function (other) {
              var t2 = new Net.Transport(NET_BASE, other.code, other.peer, other.token, {});
              return t2.send('all', { t: 'broadcast', n: 7 }).then(function () { return other; });
            })
            .then(function (other) {
              return sleep(1500).then(function () {
                t.stop();
                var hit = got.filter(function (m) { return m.data && m.data.t === 'broadcast'; });
                ok('另一个连接发的广播能通过长轮询收到', hit.length === 1, JSON.stringify(got.map(function (m) { return m.data && m.data.t; })));
                ok('to=all 不会回声给发送者', true);
                return other;
              });
            });
        });
    });
  }

  /* ---------------------------------------------------------
   *  4b. 主机侧的 req 预处理（filter 是全项目唯一的函数字段）
   * --------------------------------------------------------- */
  group('req 预处理', function () {
    E.initGame({ count: 5, deal: 3, hotseat: false });
    var g = window.G;
    g.players.forEach(function (p, i) { p.char = D.CHARACTERS[i]; });
    E.finalizeGame();
    Net.indexDeck();                   // 主机每局 finalizeGame 之后都要做这一步
    var me = g.players[0];
    me.hand = [g.deck.pop(), g.deck.pop(), g.deck.pop()];

    var out = Net._prepareReq({
      kind: 'selectCards', player: me, from: 'self', min: 1, max: 1,
      filter: function (c) { return c.name === me.hand[1].name; }
    });
    ok('from/filter 被解析掉（filter 是函数，没法序列化）',
       !('filter' in out) && !('from' in out), JSON.stringify(Object.keys(out)));
    ok('解析成了具体的 cards 列表', Array.isArray(out.cards) && out.cards.length >= 1,
       out.cards && out.cards.length);
    ok('filter 真的生效了（只剩匹配的那张）',
       out.cards.every(function (c) { return c.name === me.hand[1].name; }));

    // from:'any' 要包含装备
    me.equips.weapon = g.deck.pop();
    var out2 = Net._prepareReq({ kind: 'selectCards', player: me, from: 'any', min: 1, max: 1 });
    ok('from:any 的牌池包含装备区的牌',
       out2.cards.length === me.hand.length + 1
       && out2.cards.indexOf(me.equips.weapon) >= 0,
       out2.cards.length + ' vs ' + (me.hand.length + 1));

    // 预处理结果必须能安全序列化
    var packed = Net.pack(out, 0);
    ok('预处理后的 req 能安全打包', packed && packed.cards && packed.cards.length >= 1);
    var round = Net.unpack(packed, 0);
    ok('预处理后的 req 解包回原对象（同一性校验能过）',
       round.cards.every(function (c) { return me.hand.indexOf(c) >= 0 || c === me.equips.weapon; }));
  });

  /* ---------------------------------------------------------
   *  5. 引擎：多真人选角 / 日志脱敏 / 旁观席 / 完整对局
   * --------------------------------------------------------- */
  group('单人多真人等价性', function () {
    // humanCount === 1 时新公式必须和改动前**完全一致**，单机行为一个字都不能变
    var n = 5, total = D.CHARACTERS.length;
    E.initGame({ count: n, deal: 3, hotseat: false, humanSeats: [0] });
    var expected = Math.max(2, Math.min(3, total - (n - 1)));
    ok('单人时候选数与改动前完全一致（' + window.G.dealPer + ' vs ' + expected + '）',
       window.G.dealPer === expected);
    ok('单人时只有座位 0 是真人',
       window.G.players.filter(function (p) { return p.isHuman; }).length === 1);
  });

  group('多真人选角', function () {
    // 8 个真人 × 3 选 1 = 24 张，超过全部 20 张武将 —— 老公式在这里会崩
    E.initGame({ count: 8, deal: 3, hotseat: false, humanSeats: [0, 1, 2, 3, 4, 5, 6, 7] });
    var g = window.G;
    ok('8 个真人时候选数被自动收紧', g.dealPer >= 2 && g.dealPer * 8 <= D.CHARACTERS.length,
       g.dealPer + ' × 8 = ' + (g.dealPer * 8));
    ok('每个真人都拿到了候选',
       g.players.every(function (p) { return p.charChoices.length === g.dealPer; }));
    ok('候选之间互不重叠', (function () {
      var seen = {}, n = 0;
      g.players.forEach(function (p) {
        p.charChoices.forEach(function (c) { if (!seen[c.id]) { seen[c.id] = 1; n++; } });
      });
      return n === 8 * g.dealPer;
    })(), 'unique=' + 8 * g.dealPer);
    ok('全部座位都是真人', g.players.every(function (p) { return p.isHuman; }));

    // 混编：真人 + 电脑
    E.initGame({ count: 6, deal: 3, hotseat: false, humanSeats: [0, 2, 4] });
    ok('混编模式下只有指定的座位是真人',
       window.G.players.map(function (p) { return p.isHuman ? 1 : 0; }).join('') === '101010',
       window.G.players.map(function (p) { return p.isHuman ? 1 : 0; }).join(''));
  });

  group('选角去重', function () {
    E.initGame({ count: 6, deal: 3, hotseat: false, humanSeats: [0, 2] });
    var g = window.G;
    var pick0 = g.players[0].charChoices[0];
    var pick2 = g.players[2].charChoices[1];
    E.assignRole(0, pick0);
    E.assignRole(2, pick2);
    ok('真人还没全选完时 pendingRoleSeats 认得出来', E.pendingRoleSeats().length === 0);
    E.finalizeRoles();
    var ids = g.players.map(function (p) { return p.char && p.char.id; });
    ok('所有座位都分到了武将', ids.every(Boolean));
    ok('没有重复武将', new Set(ids).size === ids.length, ids.join(','));
    ok('真人自己选的武将被保留', g.players[0].char === pick0 && g.players[2].char === pick2);
  });

  group('选角等待中', function () {
    E.initGame({ count: 5, deal: 3, hotseat: false, humanSeats: [0, 3] });
    E.assignRole(0, window.G.players[0].charChoices[0]);
    ok('只选了一个人时还在等另一个', E.pendingRoleSeats().length === 1
       && E.pendingRoleSeats()[0] === 3);
  });

  group('日志脱敏字段', function () {
    E.initGame({ count: 5, deal: 3, hotseat: false });
    E.log('公开的信息', 'sys');
    E.log('秘密的信息', 'sys', [1], '脱敏版');
    var g = window.G;
    var secret = g.log[g.log.length - 1];
    ok('带 only 的日志记下了座位与脱敏文本',
       secret.only && secret.only[0] === 1 && secret.redacted === '脱敏版', JSON.stringify(secret));
    ok('普通日志没有 only 字段', !g.log[0].only);
  });

  group('旁观席不崩', function () {
    E.initGame({ count: 5, deal: 3, hotseat: false });
    var g = window.G;
    g.players.forEach(function (p, i) { p.char = D.CHARACTERS[i]; });
    E.finalizeGame();
    g.humanSeat = -1;                       // 旁观席
    try { E.endGame('dean', '测试'); ok('旁观席下 endGame 不抛异常', true); }
    catch (e) { fail('旁观席下 endGame 不抛异常', e.message); }
  });

  group('完整对局（全 AI 跑完一局）', function () {
    // 这是最强的回归保险：改完引擎之后，一整局还能从头跑到结束
    E.initGame({ count: 5, mode: 'A', deal: 3, protect: true, hotseat: false, networkRule: false });
    var g = window.G;
    g.speed = 0.01;
    g.players.forEach(function (p, i) { p.char = D.CHARACTERS[i]; });
    E.finalizeGame();
    // 全交给 AI：有一个 isHuman 就会弹窗等人点，无头环境会永远卡住
    g.players.forEach(function (p) { p.isHuman = false; });
    g.players.forEach(function (p) {
      for (var i = 0; i < 4; i++) { var c = g.deck.pop(); if (c) p.hand.push(c); }
    });

    var before = (window.Net && Net.recording) ? Net.takeEvents() : null;

    return E.gameLoop().then(function () {
      ok('一局能在无头环境从头跑到结束', g.over === true);
      ok('结束时产生了日志', g.log.length > 10, g.log.length);
      ok('对局中有人的体力被扣过（说明牌真的打出来了）',
         g.players.some(function (p) { return p.hp < p.maxHp; }) || g.log.some(function (e) {
           return /伤害/.test(e.text);
         }));
      ok('所有人的名字都是字符串（没有 undefined）',
         g.players.every(function (p) { return typeof p.name === 'string' && p.name.length; }));
      ok('没有出现重复武将',
         new Set(g.players.map(function (p) { return p.char.id; })).size === g.players.length);
      return before;
    }).then(function () {
      Net.selfTest();     // 跑完一局后再验一次编解码还能用
      ok('一局结束后编解码仍然正常', true);
    });
  });

  /* ---------------------------------------------------------
   *  5b. 身份模式 A / B / C（规则书 9.1）
   * --------------------------------------------------------- */
  group('身份模式 B 自选阵营', function () {
    E.initGame({ count: 5, deal: 3, hotseat: false, mode: 'B', humanSeats: [0] });
    var g = window.G;
    var cfg = D.IDENTITY_CONFIG[5];

    ok('B 模式开局时所有人身份都还没定',
       g.players.every(function (p) { return p.identity === null; }));
    ok('B 模式有一个公开的身份池', g.idPool.length === 5, g.idPool && g.idPool.length);
    ok('池子构成和配置表一致',
       g.idPool.filter(function (k) { return k === 'dean'; }).length === cfg.dean &&
       g.idPool.filter(function (k) { return k === 'student'; }).length === cfg.student,
       g.idPool.join(','));

    var stop = E.advanceIdentityDraft();
    ok('轮抽停在真人座位上等他挑', stop === 0, stop);
    ok('没人挑之前池子不动', g.idPool.length === 5);

    ok('挑了之后从池子里移除', E.assignIdentity(0, 'mole') === true &&
       g.idPool.indexOf('mole') < 0 && g.idPool.length === 4);
    ok('挑到的身份记在自己身上', g.players[0].identity === 'mole');

    ok('剩下的电脑座位被自动补完', E.advanceIdentityDraft() === -1);
    ok('所有人都分到了身份', g.players.every(function (p) { return !!p.identity; }));
    // 注意：身份**本来就该重复**（5 人局配置是 学生 ×2），
    // 所以这里只能查"种类对"，张数由下面那条按配置表逐项核对。
    ok('身份种类正好是 4 种',
       new Set(g.players.map(function (p) { return p.identity; })).size === 4,
       g.players.map(function (p) { return p.identity; }).join(','));
    ok('最终构成仍与配置表一致', (function () {
      var c = {};
      g.players.forEach(function (p) { c[p.identity] = (c[p.identity] || 0) + 1; });
      return c.dean === cfg.dean && c.staff === cfg.staff &&
             c.student === cfg.student && c.mole === cfg.mole;
    })(), JSON.stringify(cfg));
    ok('院长身份公开',
       g.players.filter(function (p) { return p.identity === 'dean'; })[0].revealed === true);
    ok('其他身份都不公开',
       g.players.filter(function (p) { return p.identity !== 'dean'; })
                .every(function (p) { return !p.revealed; }));
    ok('轮抽结束后池子清空', g.idPool.length === 0);
  });

  group('模式 B 的边界', function () {
    E.initGame({ count: 5, deal: 3, hotseat: false, mode: 'B', humanSeats: [0, 1] });
    var g = window.G;
    E.assignIdentity(0, 'dean');
    ok('同一张身份不能被挑第二次', E.assignIdentity(1, 'dean') === false);
    ok('已经挑过的人不能改主意', E.assignIdentity(0, 'student') === false);
    ok('另一个人能挑剩下的', E.assignIdentity(1, 'student') === true);
    ok('两个真人都在等的时候会依次停下',
       E.advanceIdentityDraft() === -1 ||
       g.players.filter(function (p) { return !p.identity; })
                .every(function (p) { return p.seat >= 0; }));
  });

  group('身份模式 A / C 的差别', function () {
    E.initGame({ count: 5, deal: 3, hotseat: false, mode: 'A' });
    ok('A 模式开局就分好身份',
       window.G.players.every(function (p) { return !!p.identity; }));
    ok('A 模式没有待挑的身份池', window.G.idPool.length === 0);
    ok('A 模式记下了自己的模式', window.G.mode === 'A');

    E.initGame({ count: 5, deal: 3, hotseat: false, mode: 'C' });
    ok('C 模式身份照常分配（只是选角界面上先不揭晓）',
       window.G.players.every(function (p) { return !!p.identity; }));
    ok('C 模式记下了自己的模式', window.G.mode === 'C');
  });

  group('自选阵营能打完一整局', function () {
    E.initGame({ count: 5, mode: 'B', deal: 3, hotseat: false, humanSeats: [0] });
    var g = window.G;
    E.assignIdentity(0, 'student');
    E.advanceIdentityDraft();
    g.players.forEach(function (p, i) { p.char = D.CHARACTERS[i]; });
    E.finalizeRoles();
    E.finalizeGame();
    g.speed = 0.01;
    g.players.forEach(function (p) { p.isHuman = false; });
    g.players.forEach(function (p) {
      for (var i = 0; i < 4; i++) { var c = g.deck.pop(); if (c) p.hand.push(c); }
    });
    return E.gameLoop().then(function () {
      ok('自选阵营模式也能从头打到结束', g.over === true);
      ok('结束时产生了日志', g.log.length > 10, g.log.length);
    });
  });

  /* ---------------------------------------------------------
   *  6. UI 交互：点棋盘选目标 / 手牌排序 / 旁观 / 快捷语 / 键盘
   * --------------------------------------------------------- */
  function freshGame(n, humanSeats){
    E.initGame({ count: n || 5, deal: 3, hotseat: false, humanSeats: humanSeats || [0] });
    var g = window.G;
    g.players.forEach(function (p, i) { p.char = D.CHARACTERS[i]; });
    E.finalizeGame();
    g.players.forEach(function (p) {
      for (var i = 0; i < 4; i++) { var c = g.deck.pop(); if (c) p.hand.push(c); }
    });
    return g;
  }
  function panelAt(seat){ return document.querySelector('#opponents .player-panel[data-seat="' + seat + '"]'); }
  function targetBar(){ return document.getElementById('target-bar'); }

  group('点棋盘选目标', function () {
    var g = freshGame(5);
    g.turnSeat = 0;
    var me = g.players[0];
    window.UI.setConfirmBeforePlay(true);          // 默认就该走确认条这条路径
    var cands = E.alivePlayers().filter(function (p) { return p !== me; });
    var resolved = null;
    window.UI.askHuman({ kind:'selectTargets', player:me, targets:cands,
                         min:1, max:1, prompt:'测试选目标' })
      .then(function (r) { resolved = r; });

    ok('合法目标被标成 targetable',
       document.querySelectorAll('#opponents .player-panel.targetable').length === cands.length,
       document.querySelectorAll('#opponents .player-panel.targetable').length + ' vs ' + cands.length);
    ok('不在候选里的座位没有被高亮',
       document.querySelectorAll('#opponents .player-panel.targetable').length < g.players.length);
    ok('底部弹出选目标操作条', !targetBar().classList.contains('hide'));
    ok('一个都没选时「出手」是禁用的',
       document.querySelector('#target-bar button.primary').disabled === true,
       document.querySelector('#target-bar button.primary').textContent);

    panelAt(cands[0].seat).click();                // 点棋盘上的人
    ok('点中的面板带上 selected',
       panelAt(cands[0].seat).classList.contains('selected'));
    var okBtn = document.querySelector('#target-bar button.primary');
    ok('选了人之后「出手」可点', okBtn.disabled === false);
    okBtn.click();

    return sleep(60).then(function () {
      ok('点「出手」后询问带着选中的目标结束',
         resolved && resolved.targets && resolved.targets.length === 1 &&
         resolved.targets[0] === cands[0], JSON.stringify(resolved));
      ok('结束后操作条收起', targetBar().classList.contains('hide'));
      ok('结束后高亮被清干净',
         document.querySelectorAll('#opponents .player-panel.targetable').length === 0);
    });
  });

  group('选目标时可以反悔', function () {
    var g = freshGame(5);
    var me = g.players[0];
    window.UI.setConfirmBeforePlay(true);
    var cands = E.alivePlayers().filter(function (p) { return p !== me; });
    var resolved = null;
    window.UI.askHuman({ kind:'selectTargets', player:me, targets:cands,
                         min:1, max:1, prompt:'反悔测试' })
      .then(function (r) { resolved = r; });

    panelAt(cands[0].seat).click();
    ok('第一次点击选中了 A', panelAt(cands[0].seat).classList.contains('selected'));
    panelAt(cands[1].seat).click();
    ok('点另一个：单目标下直接换成 B',
       panelAt(cands[1].seat).classList.contains('selected') &&
       !panelAt(cands[0].seat).classList.contains('selected'));
    panelAt(cands[1].seat).click();
    ok('再点一次选中的：取消选择',
       !panelAt(cands[1].seat).classList.contains('selected'));
    document.dispatchEvent(new KeyboardEvent('keydown', { key:'Escape' }));
    return sleep(60).then(function () {
      ok('Esc 取消后询问以「空目标」结束',
         resolved && resolved.targets && resolved.targets.length === 0, JSON.stringify(resolved));
    });
  });

  group('关掉出手确认后立即结算', function () {
    var g = freshGame(5);
    var me = g.players[0];
    UI.setConfirmBeforePlay(false);
    var cands = E.alivePlayers().filter(function (p) { return p !== me; });
    var resolved = null;
    window.UI.askHuman({ kind:'selectTargets', player:me, targets:cands,
                         min:1, max:1, prompt:'快速模式' })
      .then(function (r) { resolved = r; });
    panelAt(cands[0].seat).click();                // 点一下就该直接出
    return sleep(60).then(function () {
      ok('关掉确认后点一下目标就直接结算',
         resolved && resolved.targets && resolved.targets[0] === cands[0],
         JSON.stringify(resolved));
      UI.setConfirmBeforePlay(true);               // 恢复默认，别影响后面的组
    });
  });

  group('键盘选目标', function () {
    var g = freshGame(5);
    var me = g.players[0];
    window.UI.setConfirmBeforePlay(true);
    var cands = E.alivePlayers().filter(function (p) { return p !== me; });
    var resolved = null;
    window.UI.askHuman({ kind:'selectTargets', player:me, targets:cands,
                         min:1, max:1, prompt:'键盘测试' })
      .then(function (r) { resolved = r; });

    var seat = cands[0].seat;
    document.dispatchEvent(new KeyboardEvent('keydown', { key: String(seat + 1) }));
    ok('数字键按座位号选中了目标',
       panelAt(seat).classList.contains('selected'));
    document.dispatchEvent(new KeyboardEvent('keydown', { key:'Enter' }));
    return sleep(60).then(function () {
      ok('Enter 确认后询问带着目标结束',
         resolved && resolved.targets && resolved.targets[0] === cands[0], JSON.stringify(resolved));
    });
  });

  group('手牌排序', function () {
    var g = freshGame(5);
    var me = g.players[0];
    var basic = g.deck.filter(function (c) { return c.type === 'basic'; })[0];
    var equip = g.deck.filter(function (c) { return c.type === 'equip'; })[0];
    var delayed = g.deck.filter(function (c) { return c.type === 'delayed'; })[0];
    // 故意按"乱序"塞进手牌
    me.hand = [delayed, equip, basic];
    UI.render();
    var names = Array.prototype.map.call(
      document.querySelectorAll('#my-hand .card .c-name'),
      function (n) { return n.textContent; });
    ok('渲染时基本牌排在装备牌前面',
       names.indexOf(basic.name) < names.indexOf(equip.name), names.join(','));
    ok('装备牌排在延时牌前面',
       names.indexOf(equip.name) < names.indexOf(delayed.name), names.join(','));
    ok('排序只是显示顺序，没动真实手牌数组',
       me.hand.length === 3 && me.hand[0] === delayed, me.hand.map(function(c){return c.name;}).join(','));
  });

  group('手牌超限提前提醒', function () {
    var g = freshGame(5);
    var me = g.players[0];
    me.hp = 2;                                     // 手牌上限 = 当前体力
    while (me.hand.length < 6) { var c = g.deck.pop(); if (c) me.hand.push(c); }
    UI.render();
    var hint = document.getElementById('hand-hint').textContent;
    ok('手牌超过上限时提前警告（不用等到弃牌阶段）',
       hint.indexOf('需弃') >= 0 && hint.indexOf('上限') >= 0, hint);
    me.hp = 20; UI.render();
    ok('没超限时不再警告',
       document.getElementById('hand-hint').textContent.indexOf('需弃') < 0);
  });

  group('旁观席界面', function () {
    var g = freshGame(5);
    g.humanSeat = -1;
    UI.render();
    var bar = document.getElementById('spectator-bar');
    ok('旁观时显示观战条', !bar.classList.contains('hide'));
    ok('观战条里有当前回合和存活人数',
       bar.textContent.indexOf('观战中') >= 0 && bar.textContent.indexOf('当前回合') >= 0,
       bar.textContent);
    ok('旁观时不渲染手牌', document.querySelectorAll('#my-hand .card').length === 0);
    ok('旁观时顶部横幅说明是旁观',
       document.getElementById('my-id-banner').textContent.indexOf('旁观') >= 0);
    g.humanSeat = 0; UI.render();
    ok('回到自己座位后观战条收起', bar.classList.contains('hide'));
  });

  group('快捷语气泡', function () {
    var g = freshGame(5);
    UI.render();
    UI.showChatBubble(2, '快点出牌啦');
    var b = document.querySelector('.player-panel[data-seat="2"] .chat-bubble');
    ok('气泡挂在对应角色的面板上', !!b && b.textContent === '快点出牌啦');
    ok('气泡带 data-seat（座位区重建后靠它挂回来）', !!b && b.dataset.seat === '2');
    UI.render();                                   // 模拟一次状态同步导致的重建
    ok('座位区重绘之后气泡仍在',
       !!document.querySelector('.player-panel[data-seat="2"] .chat-bubble'));
  });

  group('牌面类型角标', function () {
    var g = freshGame(5);
    var me = g.players[0];
    UI.render();
    var badges = document.querySelectorAll('#my-hand .card .c-type');
    ok('每张手牌都有类型角标', badges.length === me.hand.length,
       badges.length + ' vs ' + me.hand.length);
    ok('角标写的是中文类型名',
       Array.prototype.every.call(badges, function (b) {
         return ['基本', '装备', '事件', '延时'].indexOf(b.textContent) >= 0;
       }),
       Array.prototype.map.call(badges, function (b) { return b.textContent; }).join(','));
    ok('不再有"长按看详情"占位文字',
       document.querySelectorAll('#my-hand .card .c-tip').length === 0);
  });

  group('窄屏默认收起日志抽屉', function () {
    // 这条防的是一类"只在单文件版里测过"的回归：收起日志的逻辑原本只存在于
    // build-mobile.ps1 注入的补丁里，而手机直接打开服务器地址走的是
    // index.html + mobile.css —— 没有那段，一开局日志就占掉半个屏幕。
    var w = window;
    if (!w.matchMedia || !w.matchMedia('(max-width: 900px)').matches){
      ok('（测试窗口不在手机断点内，跳过）', true);
      return;
    }
    var sb = document.getElementById('sidebar');
    sb.classList.remove('hide');
    UI.bindTopbar();
    ok('窄屏下 bindTopbar 会把日志抽屉收起来', sb.classList.contains('hide'));
    sb.classList.remove('hide');
  });

  group('布局切换', function () {
    var g = freshGame(6);
    // 测试页没加载 style.css，所以这里替 CSS 给容器一个尺寸 ——
    // 真实环境里 #board-main 是 flex:1，尺寸由布局给出。
    var box = document.getElementById('opponents');
    box.style.width = '900px';
    box.style.height = '600px';

    var before = UI.getLayout();
    var after = UI.toggleLayout();
    ok('切换布局会真的换一种', before !== after, before + ' -> ' + after);
    ok('切到座位圈时座位区带 ring 类',
       (after === 'ring') === box.classList.contains('ring'),
       after + ' / ' + box.className);
    ok('切到座位圈时出牌区也知道（好给中间留白）',
       (after === 'ring') ===
         document.getElementById('board-main').classList.contains('ring'));

    if (after === 'ring'){
      var panel = document.querySelector('#opponents .player-panel');
      ok('圆桌下面板被算出了绝对坐标（left/top 是 px）',
         /^\d+px$/.test(panel.style.left) && /^\d+px$/.test(panel.style.top),
         panel.style.left + ' / ' + panel.style.top);
      ok('「我」被摆在正下方（圆桌的基准位）',
         (function () {
           var mine = document.querySelector('#opponents .player-panel.is-me');
           if (!mine) return false;
           return parseInt(mine.style.top, 10) > 300;     // 容器高 600 → 下半区
         })());
    }

    UI.toggleLayout();                             // 切回去，别影响后面的组
    box.style.width = ''; box.style.height = '';
  });

  /* ---------------------------------------------------------
   *  6b. AI 与提示语文案的耦合
   * ---------------------------------------------------------
   *  ai.js 是从**中文提示语文本**里正则抠玩家名字的（parseTargetName）。
   *  这个耦合很容易被无声破坏：改一句 engine.js 的提示文案，
   *  正则可能就抠出了半个人名，AI 于是"什么都不做" —— 不报错、不崩溃，
   *  只是悄悄变笨。这几条就是钉住它。 */
  group('AI 能认出提示语里的目标', function () {
    var g = freshGame(5);
    var t = g.players[3];

    // 下面三句是从 engine.js 里逐字抄来的真实提示语
    var real = [
      '【兄弟】' + t.name + ' 即将受到 2 点伤害，是否弃一张牌令伤害-1？',
      '【人脉】' + t.name + ' 使用了事件牌，是否弃一张牌令其额外摸一张？',
      '【设局】' + t.name + ' 刚刚摸了牌，是否弃一张牌令其跳过出牌阶段？'
    ];
    real.forEach(function (p, i) {
      ok('第 ' + (i + 1) + ' 种真实提示语能抠出正确的人名（' + t.name + '）',
         window.AI._parseTargetName(p) === t.name, window.AI._parseTargetName(p));
    });

    // 所有角色名都要能过。用 allCharacters()（含全部拓展包）：
    // 一旦有角色名抠不出来，AI 的【兄弟】【人脉】【设局】就会**静默失效**
    // ——不报错，只是永远不发动。
    //
    // parseTargetName 现在读 G.players（改成比对**真名**而不是抠中文正则了，
    // 因为牢师包有 Tania / Hogo 这种英文名，中文正则会匹配到技能名自己）。
    // 所以每个名字要先放进场上才能测。
    var allNames = D.allCharacters().map(function (c) { return c.name; });
    var savedPlayers = window.G.players;
    var bad = allNames.filter(function (n) {
      window.G.players = [{ seat:0, name:n, alive:true }, { seat:1, name:'陪测', alive:true }];
      return window.AI._parseTargetName('【兄弟】' + n + ' 即将受到 2 点伤害') !== n;
    });
    window.G.players = savedPlayers;
    ok('全部 ' + allNames.length + ' 个角色名都能被正确抠出来', bad.length === 0, bad.join('、'));

    // 英文名单独钉一条：这正是它坏过的形式 —— 中文正则会匹配到【兄弟】里的"兄弟"
    ok('英文角色名也能被抠出来（Tania / Hogo）',
       (function () {
         var save = window.G.players;
         window.G.players = [{ seat:0, name:'Tania', alive:true }, { seat:1, name:'Hogo', alive:true }];
         var r1 = window.AI._parseTargetName('【兄弟】Tania 即将受到 2 点伤害');
         var r2 = window.AI._parseTargetName('【设局】Hogo 刚刚摸了牌');
         window.G.players = save;
         return r1 === 'Tania' && r2 === 'Hogo';
       })());

    // 濒死求援走的是另一个函数，它返回的是**玩家对象**（不是在场上的人就返回 null），
    // 所以只能在场上这几个角色里测。
    var inGame = g.players.map(function (p) { return p.name; });
    var miss = inGame.filter(function (n) {
      var t = window.AI._parseDyingTarget('是否救援 ' + n + '？（其体力 0）');
      return !t || t.name !== n;
    });
    ok('濒死救援的提示语能认出场上每个人的名字', miss.length === 0, miss.join('、'));

    // 真实 decide 调用不能崩、必须给出合法选项
    return window.AI.decide({ kind:'choice', player: g.players[0], prompt: real[0],
                              options: [{ key:'yes', label:'发动' }, { key:'no', label:'放弃' }] })
      .then(function (r) {
        ok('AI.decide 对真实提示语返回了合法选项',
           r && (r.option === 'yes' || r.option === 'no'), JSON.stringify(r));
      });
  });

  /* ---------------------------------------------------------
   *  6c. 存档往返 / 弃牌堆 / 新手引导 / 复盘录制
   * --------------------------------------------------------- */

  group('存档序列化往返（房主接手要靠它）', function () {
    var g = freshGame(6);
    // 摆一些有代表性的状态，确保往返不丢东西
    g.players[1].equips.weapon = g.deck.pop();
    g.players[2].judge.push(g.deck.pop());
    g.players[0].hp = 2;
    g.players[4].alive = false;
    g.players[4].revealed = true;
    g.players[3].chained = true;
    g.turnSeat = 3;
    g.round = 4;
    g.rescueLog = { 2: 1 };
    var before = {
      ids: g.players.map(function (p) { return p.identity; }).join(','),
      hp: g.players.map(function (p) { return p.hp; }).join(','),
      hands: g.players.map(function (p) { return p.hand.length; }).join(','),
      deck: g.deck.length, discard: g.discard.length
    };
    var weaponUid = g.players[1].equips.weapon.uid;
    var judgeUid = g.players[2].judge[0].uid;

    var saved = JSON.parse(JSON.stringify(window.Net._serializeGame()));
    window.Net._deserializeGame(saved);
    var g2 = window.G;

    ok('往返后身份不变', g2.players.map(function (p) { return p.identity; }).join(',') === before.ids);
    ok('往返后体力不变', g2.players.map(function (p) { return p.hp; }).join(',') === before.hp);
    ok('往返后手牌张数不变',
       g2.players.map(function (p) { return p.hand.length; }).join(',') === before.hands);
    ok('往返后牌堆/弃牌堆张数不变',
       g2.deck.length === before.deck && g2.discard.length === before.discard);
    ok('往返后仍知道谁死了', g2.players[4].alive === false && g2.players[4].revealed === true);
    ok('往返后横置状态还在', g2.players[3].chained === true);
    ok('往返后回合与轮次还在', g2.turnSeat === 3 && g2.round === 4);
    ok('往返后救援记录还在', g2.rescueLog && g2.rescueLog[2] === 1);

    // 关键：JSON 会丢掉 defineProperty 的 name getter，必须补回来
    ok('往返后每个玩家仍有可用的 name',
       g2.players.every(function (p) { return typeof p.name === 'string' && p.name.length; }),
       g2.players.map(function (p) { return p.name; }).join(','));
    ok('往返后 char 对象接回来了',
       g2.players.every(function (p) { return !!p.char && !!p.char.skills; }));

    // 关键：接手之后引擎靠 uid 索引把客户端回传的牌对回原对象
    ok('往返后装备牌能按 uid 解析回同一个对象',
       window.Net.resolveCard(weaponUid) === g2.players[1].equips.weapon);
    ok('往返后通知栏的牌也能按 uid 解析',
       window.Net.resolveCard(judgeUid) === g2.players[2].judge[0]);
  });

  group('弃牌堆查看', function () {
    var g = freshGame(5);
    // 三张都显式命名，别依赖随机牌堆恰好不重名（这条以前会偶发红）
    var a = g.deck.pop(), b = g.deck.pop(), c = g.deck.pop();
    a.name = '上课点名'; b.name = '上课点名'; c.name = '代课';
    g.discard = [a, b, c];
    UI.showDiscard();
    var rows = document.querySelectorAll('#modal-layer .discard-row');
    ok('弃牌堆按牌名聚合，同名合并成一行', rows.length === 2, rows.length);
    var first = rows[0] && rows[0].querySelector('.dr-name').textContent;
    ok('出现次数最多的牌排在最前面', first === '上课点名', first);
    ok('行里写明了几张',
       rows[0] && /×2/.test(rows[0].querySelector('.dr-n').textContent),
       rows[0] && rows[0].querySelector('.dr-n').textContent);
    UI.closeModal();
  });

  group('新手引导', function () {
    UI.showTutorial(0);
    var layer = document.getElementById('modal-layer');
    ok('引导弹窗打开了', layer.classList.contains('show'));
    ok('显示的是第 1 步', /第 1 \/ \d+ 步/.test(layer.textContent), layer.textContent.slice(0, 40));
    ok('有"下一步"按钮', !!Array.prototype.find.call(
      layer.querySelectorAll('button'), function (b) { return b.textContent.indexOf('下一步') >= 0; }));
    UI.closeModal();
    // 看过之后就不再自动弹
    UI.showTutorial(99);                      // 走到底 → 打上已看标记
    ok('走完引导会记下"看过了"',
       (function () { try { return localStorage.getItem('dqk_tutorial') === '1'; } catch (e) { return true; } })());
    ok('看过之后不再自动弹',
       UI.maybeShowTutorial() === false);
  });

  group('复盘录制', function () {
    Net.stopLocalRec();
    Net.rec = null;
    freshGame(5);
    Net.startLocalRec(0);
    ok('开始录制后有了一个复盘容器',
       !!Net.rec && Net.rec.type === 'dqk-replay' && Array.isArray(Net.rec.frames));
    ok('记下了录制者的座位', Net.rec.seat === 0);
    // 制造一次状态变化 + 一次演出，看会不会被录进去
    window.FX.sfx('draw');
    UI.render();
    return sleep(300).then(function () {
      ok('状态变化和演出被录成了帧', Net.rec.frames.length >= 1, Net.rec.frames.length);
      ok('帧里带时间戳', typeof Net.rec.frames[0].t === 'number');
      Net.stopLocalRec();
      Net.stopRecording();
      Net.recLive = false;
      ok('录到的数据能序列化成 JSON（就是保存下来的东西）',
         (function () { try { JSON.stringify(Net.rec); return true; } catch (e) { return false; } })());
    });
  });

  /* ---------------------------------------------------------
   *  6d. 点名类牌统一 + 平衡性削弱
   * --------------------------------------------------------- */

  group('点名类牌三者统一（火杀/雷杀也算"杀"）', function () {
    var g = freshGame(4);
    var a = g.players[0], b = g.players[1];
    var mk = function (name, suit, rank){
      return { name: name, suit: suit, rank: rank, type:'basic', kind:'attack', dmg:'normal' };
    };
    var black = mk('上课点名', 'S', 7);
    var fire  = mk('公开处刑', 'H', 4);
    var thund = mk('雷同警告', 'S', 4);

    // 学生证：挡黑色"点名类"
    b.equips.armor = { name:'学生证', slot:'armor' };
    ok('学生证挡黑色上课点名', !!E.isImmuneByCard(b, black, a));
    ok('学生证挡黑色雷同警告（全黑 → 现在也被挡）', !!E.isImmuneByCard(b, thund, a));
    ok('学生证挡不住公开处刑（它全红）', !E.isImmuneByCard(b, fire, a));

    // 试卷：无视防具，对整类生效
    a.equips.weapon = { name:'试卷', slot:'weapon', range:2 };
    ok('试卷让黑色雷同警告也无视学生证', !E.isImmuneByCard(b, thund, a));

    // 点名册：解除整类的次数上限
    a.equips.weapon = { name:'点名册', slot:'weapon', range:1 };
    a.usedAttackCardThisPhase = 1;
    a.pointBan = false;
    ok('点名册下公开处刑不受限制', E.canUseAttack(a, { name:'公开处刑' }) === true);
    ok('点名册下雷同警告不受限制', E.canUseAttack(a, { name:'雷同警告' }) === true);

    // 吹牛的禁令覆盖整类
    a.pointBan = true;
    ok('【吹牛】失败后公开处刑也被禁', E.canUseAttack(a, { name:'公开处刑' }) === false);
  });

  group('平衡调整：肾小球【过滤】每轮一次', function () {
    var g = freshGame(4);
    var k = g.players[1], src = g.players[0];
    k.char = D.CHARACTER_BY_NAME['肾小球'];
    k.maxHp = 4; k.hp = 4; k.marks = {};
    g.round = 1;
    return E.damage(k, 1, src, 'normal').then(function () {
      ok('本轮第一次非属性伤害被减到 0', k.hp === 4, k.hp);
      return E.damage(k, 1, src, 'normal');
    }).then(function () {
      ok('同一轮里第二次不再减免（原来会一直免疫）', k.hp === 3, k.hp);
      return E.damage(k, 1, src, 'fire');
    }).then(function () {
      ok('属性伤害本来就不受过滤影响', k.hp === 2, k.hp);
      // 进到下一轮：又该生效了。判据是"记轮号"而不是一个布尔标志，
      // 所以这里只改 G.round 就够，不需要谁去重置
      g.round = 2;
      return E.damage(k, 1, src, 'normal');
    }).then(function () {
      ok('进入下一轮后重新生效（每轮一次，不是每局一次）', k.hp === 2, k.hp);
      // 换一个新回合但轮号没变 → 不该重新生效
      var k2 = g.players[2];
      k2.char = D.CHARACTER_BY_NAME['肾小球']; k2.maxHp = 4; k2.hp = 4; k2.marks = {};
      g.round = 3;
      return E.damage(k2, 1, src, 'normal').then(function (){
        ok('新轮第一次生效', k2.hp === 4, k2.hp);
        return E.damage(k2, 1, src, 'normal');
      }).then(function (){
        ok('轮号不变就一直是"已用过"（回合换了也不重置）', k2.hp === 3, k2.hp);
      });
    });
  });

  group('平衡调整：另外三个武将', function () {
    var g = freshGame(5);

    var song = g.players[1];
    song.char = D.CHARACTER_BY_NAME['宋美丽'];
    song.hp = 1;
    var cands = E.skillTargets(song, { name:'共情', healOnly:true });
    ok('【共情】不能选自己了', cands.indexOf(song) < 0, cands.map(function (p) { return p.name; }).join(','));
    var textOf = function (p, n) {
      var s = p.char.skills.find(function (x) { return x.name === n; });
      return s ? s.text : '';
    };
    ok('【共情】的文案写了"其他"', /其他/.test(textOf(song, '共情')), textOf(song, '共情'));

    var wang = g.players[2];
    wang.char = D.CHARACTER_BY_NAME['王三金'];
    ok('【炫富】的文案改成了"每轮限一次"', /每轮限一次/.test(textOf(wang, '炫富')), textOf(wang, '炫富'));

    var dong = g.players[3];
    dong.char = D.CHARACTER_BY_NAME['董昌程'];
    ok('【设局】的代价改成了弃两张牌', /弃两张牌/.test(textOf(dong, '设局')), textOf(dong, '设局'));

    var shen = g.players[4];
    shen.char = D.CHARACTER_BY_NAME['肾小球'];
    ok('【过滤】的文案是"每轮…首次"（不是每回合）',
       /每轮[^，。]*首次/.test(textOf(shen, '过滤')), textOf(shen, '过滤'));
  });

  group('辅导员签字的时机', function () {
    // 延时牌不再在"放置时"被抵消 —— 描述里必须写清时机，免得玩家以为丢了窗口
    var det = D.CARD_DETAIL['辅导员签字'];
    ok('辅导员签字的详情写明了延时牌的时机',
       /回合开始/.test(det.limit) && /放置时不问/.test(det.limit), det.limit);
    ok('辅导员签字的详情写明了群体牌逐个目标询问',
       /每个目标分别/.test(det.limit), det.limit);
    ok('卡面上的简述也改成了"生效时"',
       /生效时/.test(D.CARDS['辅导员签字'].desc), D.CARDS['辅导员签字'].desc);
  });

  /* ---------------------------------------------------------
   *  6d-2. 延时牌被辅导员签字抵消后的去向
   *
   *  论文查重（闪电）和手机没电/饭卡没钱不一样：它的身份是**热土豆**，
   *  没劈中就得传给下家。辅导员签字抵消掉的是"受到 3 点雷电伤害"
   *  这一次判定，不是这张牌本身 —— 所以它应该照常流转，而不是进弃牌堆。
   * --------------------------------------------------------- */
  group('论文查重被抵消后是流转，不是消失', function () {
    var realAsk = window.UI.askHuman;

    /** 真人才走 UI.askHuman，所以把座位 1 设成真人，它的"打不打签字"就由我们说了算 */
    function answerNullify(yes) {
      window.UI.askHuman = function (req) {
        if (req.kind === 'choice' && /辅导员签字/.test(req.prompt || '')) {
          return Promise.resolve({ option: yes ? 'yes' : 'no' });
        }
        return Promise.resolve({});
      };
    }

    /** 从牌堆或任何人手里抽一张出来 —— 免得"刚好都发到手上了"这种随机跳过 */
    function takeCard(g, name) {
      var i = g.deck.findIndex(function (c) { return c.name === name; });
      if (i >= 0) return g.deck.splice(i, 1)[0];
      for (var k = 0; k < g.players.length; k++) {
        var h = g.players[k].hand;
        var j = h.findIndex(function (c) { return c.name === name; });
        if (j >= 0) return h.splice(j, 1)[0];
      }
      return null;
    }

    /** 造一局干净的对局：0 号位通知栏里放一张延时牌，1 号位捏着一张辅导员签字 */
    function setup(delayedName) {
      var g = freshGame(4, [0, 1]);
      g.speed = 0.01;
      g.turnSeat = 0;
      g.players.forEach(function (p) { p.hand = []; p.judge = []; });
      var delayed = takeCard(g, delayedName);
      var sign = takeCard(g, '辅导员签字');
      if (!delayed || !sign) return { g: g, missing: true };
      g.players[0].judge.push(delayed);
      g.players[1].hand.push(sign);
      return { g: g, delayed: delayed, sign: sign };
    }

    // ---- 1. 被签字抵消：应该传给下家，不该进弃牌堆 ----
    var s = setup('论文查重');
    if (s.missing){ ok('牌堆里找得到论文查重和辅导员签字', false, '找不到，跳过'); return; }
    answerNullify(true);
    var deckBefore = s.g.deck.length;
    return E.judgePhase(s.g.players[0]).then(function () {
      window.UI.askHuman = realAsk;
      // 闪电的官方时机：无懈必须抢在判定牌翻开**之前**，翻开了就只剩改判窗口。
      // 所以抵消掉 = **根本不进行判定** = 一张牌都没翻。
      // 这条最容易被"优化"成"等看到结果再问"，那样 15.6% 命中的牌就永远没人愿意掏签字了。
      ok('抵消后一张抽签牌都没翻（= 在翻牌之前问的）',
         s.g.deck.length === deckBefore,
         '牌堆 ' + deckBefore + ' → ' + s.g.deck.length);
      ok('抵消后论文查重**不在**弃牌堆里（它没消失）',
         s.g.discard.indexOf(s.delayed) < 0,
         '弃牌堆里有它 = 被当成普通延时牌弃掉了');
      ok('抵消后论文查重传给了下家（1 号位通知栏）',
         s.g.players[1].judge.indexOf(s.delayed) >= 0,
         '1 号位通知栏：' + s.g.players[1].judge.map(function (c) { return c.name; }).join(','));
      ok('它已经离开自己（0 号位）的通知栏', s.g.players[0].judge.indexOf(s.delayed) < 0);
      ok('辅导员签字自己进了弃牌堆（它是一次性消耗）',
         s.g.discard.indexOf(s.sign) >= 0);

      // ---- 2. 判定没命中：一样流转（这条本来就对，重构后要保证没坏）----
      var t = setup('论文查重');
      if (t.missing){ ok('第二局也找得到牌', false, '找不到，跳过'); return; }
      // drawFromDeck 是 pop()，所以放末尾 = 下一张翻开的就是它
      var safe = t.g.deck.find(function (c) {
        return !(c.suit === 'S' && c.rank >= 2 && c.rank <= 9);
      });
      t.g.deck.splice(t.g.deck.indexOf(safe), 1);
      t.g.deck.push(safe);
      answerNullify(false);
      return E.judgePhase(t.g.players[0]).then(function () {
        window.UI.askHuman = realAsk;
        ok('判定没命中时，论文查重同样传给下家',
           t.g.players[1].judge.indexOf(t.delayed) >= 0);

        // ---- 3. 对照组：手机没电被抵消 → 照旧进弃牌堆 ----
        var u = setup('手机没电');
        if (u.missing){ ok('第三局也找得到牌', false, '找不到，跳过'); return; }
        answerNullify(true);
        return E.judgePhase(u.g.players[0]).then(function () {
          window.UI.askHuman = realAsk;
          ok('手机没电被抵消后仍然进弃牌堆（它没有流转这回事）',
             u.g.discard.indexOf(u.delayed) >= 0 &&
             u.g.players[1].judge.indexOf(u.delayed) < 0,
             '弃牌=' + (u.g.discard.indexOf(u.delayed) >= 0) +
             ' 下家通知栏=' + (u.g.players[1].judge.indexOf(u.delayed) >= 0));
        });
      });
    }).catch(function (e) {
      window.UI.askHuman = realAsk;
      ok('这组测试本身没有抛异常', false, (e && e.message) || String(e));
    });
  });

  /* ---------------------------------------------------------
   *  6e. 平衡调整：四个弱势武将获得加强
   * --------------------------------------------------------- */
  group('弱势武将加强（文案）', function () {
    var txt = function (id, n) {
      var c = D.CHARACTER_BY_NAME[id];
      var s = c && c.skills.find(function (x) { return x.name === n; });
      return s ? s.text : '';
    };

    ok('【概率】不再有"弃一张手牌"的负收益（数学郭）',
       !/弃一张手牌/.test(txt('数学郭', '概率')) && /黑色摸一张牌/.test(txt('数学郭', '概率')),
       txt('数学郭', '概率'));
    ok('【水课】主动跳过也触发（方三水）',
       /都没出/.test(txt('方三水', '水课')), txt('方三水', '水课'));
    ok('【划水】交换后补一张牌（方三水）',
       /然后你摸一张牌/.test(txt('方三水', '划水')), txt('方三水', '划水'));
    ok('【撒娇】交换后补一张牌（奶扣）',
       /并摸一张牌/.test(txt('奶扣', '撒娇')), txt('奶扣', '撒娇'));
    ok('【伦理】加上了成为事件牌目标的收益（董伦）',
       /摸一张牌/.test(txt('董伦', '伦理')) && /事件牌/.test(txt('董伦', '伦理')),
       txt('董伦', '伦理'));
  });

  group('【伦理】真的会发牌', function () {
    var g = freshGame(5);
    var user = g.players[0];
    var dong = g.players[2];
    dong.char = D.CHARACTER_BY_NAME['董伦'];
    dong.hp = 3; dong.maxHp = 3;
    // 把所有人的手牌清空，只留董伦的。
    // 否则别人随机摸到【辅导员签字】会把这张通报批评抵消掉 ——
    // 那时【伦理】本来就不该触发（牌没生效），但测试会随机变红。
    g.players.forEach(function (p) { p.hand = []; });
    // 给董伦摸两张时**要避开辅导员签字** —— 上面只清空了别人的手牌，
    // 而他自己摸到的签字会把指向自己的通报批评抵消掉：那时【伦理】本来就不该触发，
    // 但这条断言会随机变红（约 7% 的运行，是个一直在的偶发失败）。
    while (dong.hand.length < 2){
      var dc = g.deck.pop();
      if (!dc) break;
      if (dc.name === '辅导员签字'){ g.deck.unshift(dc); continue; }   // 塞回牌堆底换一张
      dong.hand.push(dc);
    }
    var before = dong.hand.length;
    // 通报批评 = 弃置目标一张牌，正好用来测"成为事件牌目标"这条触发
    var ev = g.deck.find(function (c) { return c.name === '通报批评'; }) ||
             g.deck.find(function (c) { return D.CARDS[c.name].kind === 'dismantle'; });
    if (!ev){ ok('（牌堆里找不到通报批评，跳过）', true); return; }
    return E.useCard(user, ev, [dong]).then(function () {
      ok('【伦理】触发时写了日志',
         g.log.some(function (e) { return /伦理/.test(e.text); }),
         g.log.slice(-3).map(function (e) { return e.text; }).join(' | '));
      ok('他被弃了一张牌，但伦理补回一张（净手牌不变）',
         dong.hand.length === before, dong.hand.length + ' vs ' + before);
    });
  });

  /* ---------------------------------------------------------
   *  6e-3. 超开心（基础角色）+ 拓展包开关
   *
   *  一个主动技要接 4 个地方才真的能用：SKILLS 函数 / usableSkills /
   *  skillTargets / AI 评分。少接一个不会报错 —— 症状是"AI 永远不用"
   *  或者"按钮是灰的"。所以这里四处各测一处。
   * --------------------------------------------------------- */
  group('超开心与拓展包', function () {
    var kx = D.CHARACTER_BY_NAME['超开心'];
    ok('超开心在基础名单里（不属于任何拓展包）', !!kx);
    if (!kx){ ok('（找不到超开心，本组跳过）', false); return; }
    ok('超开心体力 4', kx.hp === 4, kx.hp);
    ok('两个技能是 傻乐 / 起哄',
       kx.skills.length === 2 && kx.skills[0].name === '傻乐' && kx.skills[1].name === '起哄',
       kx.skills.map(function (s) { return s.name; }).join('、'));
    ok('性别表收了他（漏了自检会红）', !!E.SEX['超开心'], E.SEX['超开心']);

    ok('牢师包 7 名角色', D.PACKS.laoshi.length === 7, D.PACKS.laoshi.length);
    ok('不启用任何包时，名单长度就是基础名单',
       D.roster({}).length === D.CHARACTERS.length);
    // 结构性断言：不加数字，包里的内容以后怎么变都成立
    ok('开启哪个包，名单就多出那个包的人数',
       D.roster({ laoshi:true }).length === D.CHARACTERS.length + D.PACKS.laoshi.length &&
       D.roster({ pack1:true }).length  === D.CHARACTERS.length + D.PACKS.pack1.length);

    // ---- 【傻乐】：受到伤害后摸一张 ----
    var g = freshGame(4);
    var me = g.players[0];
    me.char = kx; me.hp = 4; me.maxHp = 4; me.hand = [];
    return E.damage(me, 1, g.players[1], 'normal').then(function (dealt) {
      ok('【傻乐】受伤 1 点后摸一张牌', dealt === 1 && me.hand.length === 1,
         'dealt=' + dealt + ' 手牌=' + me.hand.length);

      var g0 = freshGame(4);
      var me0 = g0.players[0];
      me0.char = kx; me0.hp = 4; me0.maxHp = 4; me0.hand = [];
      return E.damage(me0, 0, g0.players[1], 'normal').then(function (d0) {
        ok('0 点伤害不算"受到伤害"，不触发【傻乐】',
           d0 === 0 && me0.hand.length === 0, 'dealt=' + d0);
        return testQihong();
      });
    });

    function testQihong(){
      var g3 = freshGame(4);
      g3.turnSeat = 0;
      var kai = g3.players[0];
      kai.char = kx; kai.hp = 4; kai.maxHp = 4; kai.hand = [];
      while (kai.hand.length < 2){ var c = g3.deck.pop(); if (c) kai.hand.push(c); }
      var t1 = g3.players[1], t2 = g3.players[2], t3 = g3.players[3];
      t1.chained = false; t2.chained = true; t3.chained = false;

      var usable = E.usableSkills(kai).map(function (s) { return s.name; });
      ok('【起哄】出现在可用技能里', usable.indexOf('起哄') >= 0, usable.join('、'));

      var tg = E.skillTargets(kai, { name:'起哄' });
      ok('【起哄】的候选只含未横置的其他人（已横置的、自己都排除）',
         tg.indexOf(t1) >= 0 && tg.indexOf(t3) >= 0 &&
         tg.indexOf(t2) < 0 && tg.indexOf(kai) < 0,
         '候选=' + tg.map(function (p) { return p.name; }).join('、'));

      // 技能本体：用桩答掉"弃哪张牌"这一问（真 UI 会弹窗等人点，无头环境会挂）
      var realAsk = window.UI.askHuman;
      window.UI.askHuman = function (){ return Promise.resolve({ cards: [kai.hand[0]] }); };
      var before = kai.hand.length;
      return E._skills.起哄(kai, [t1]).then(function (){
        window.UI.askHuman = realAsk;
        ok('【起哄】弃掉了一张牌', kai.hand.length === before - 1, before + ' → ' + kai.hand.length);
        ok('【起哄】把目标横置了', t1.chained === true);
        ok('【起哄】没有误伤其他人', t3.chained === false && t2.chained === true);
      }, function (e){
        window.UI.askHuman = realAsk;
        ok('【起哄】没有抛异常', false, (e && e.message) || e);
      });
    }
  });

  /* ---------------------------------------------------------
   *  6e-4. 牢师包（7 人）
   *
   *  这一组的重点是**新挂到引擎里的钩子**：手牌上限、伤害增减、
   *  伤害转移、点名税、事件牌封禁。主动技本体在别处已有同类覆盖。
   * --------------------------------------------------------- */
  group('牢师包', function () {
    var P = D.PACKS.laoshi;
    var by = {};
    P.forEach(function (c) { by[c.name] = c; });

    ok('牢师包 7 人，名字和设计表一致',
       ['Tania', 'Hogo', '韩鹏', '李岩', '孩子', '亨利', '张金雪']
         .every(function (n) { return !!by[n]; }),
       P.map(function (c) { return c.name; }).join('、'));
    ok('每人最多 2 个技能', P.every(function (c) { return c.skills.length <= 2; }));
    ok('开启牢师包后 D.roster 能拿到他们',
       D.roster({ laoshi:true }).indexOf(by['Tania']) >= 0);
    ok('不开启时拿不到',
       D.roster({}).indexOf(by['Tania']) < 0);

    function put(seat, name, hp){
      var g = window.G;
      var p = g.players[seat];
      p.char = by[name]; p.hp = hp; p.maxHp = hp;
      p.hand = []; p.judge = []; p.equips = { weapon:null, armor:null, mountUp:null, mountDown:null };
      p.marks = {}; p.skillsUsedThisTurn = {};
      return p;
    }

    // ---- 手牌上限：持家 +2 / 挥金 +2 ----
    var g0 = freshGame(4);
    var li = put(0, '李岩', 3), he = put(1, '亨利', 4);
    ok('【持家】手牌上限 +2（体力 3 → 5）', E.handLimit(li) === 5, E.handLimit(li));
    ok('【挥金】手牌上限 +2（体力 4 → 6）', E.handLimit(he) === 6, E.handLimit(he));

    // ---- 挥金：每轮首次受到的伤害 -1 ----
    he.hp = 9; he.maxHp = 9;      // 抬高血量：让他进濒死会把这场测试搅乱
    g0.round = 1;
    return E.damage(he, 1, li, 'normal').then(function (d) {
      ok('【挥金】本轮首次受伤 -1（1 点被减到 0）', d === 0 && he.hp === 9, 'dealt=' + d + ' hp=' + he.hp);
      return E.damage(he, 1, li, 'normal');
    }).then(function (d2) {
      // 这条技能试过三版"代价型"（受伤 +1：不限次 / 每回合 / 每轮），
      // 探针跑出来分别是 0.49 / 0.56 / 0.50，三次都是全场最弱 —— 才反过来做成收益
      ok('【挥金】同一轮第二次不再减', d2 === 1 && he.hp === 8, 'dealt=' + d2 + ' hp=' + he.hp);
      g0.round = 2;
      return E.damage(he, 1, li, 'normal');
    }).then(function (d3) {
      ok('【挥金】下一轮重新生效', d3 === 0 && he.hp === 8, 'dealt=' + d3 + ' hp=' + he.hp);
      return testWusi();
    });

    // ---- 无私：对体力高于自己的角色伤害 +1，且每回合只一次 ----
    function testWusi(){
      var g = freshGame(4);
      var zhang = put(0, '张金雪', 4);
      // 靶子用李岩（持家，没有伤害相关技能）—— 别用亨利，他有【挥金】受伤 +1，
      // 会和【无私】叠在一起，测出来的数字对不上
      var big = put(1, '李岩', 6);      // 体力高于张金雪
      return E.damage(big, 1, zhang, 'normal').then(function (d1) {
        ok('【无私】对体力更高的角色伤害 +1', d1 === 2, 'dealt=' + d1);
        return E.damage(big, 1, zhang, 'normal').then(function (d2) {
          ok('【无私】同一回合第二次不再加成', d2 === 1, 'dealt=' + d2);
          return testDaoluan();
        });
      });
    }

    // ---- 捣乱：受伤后来源随机弃一张 ----
    function testDaoluan(){
      var g = freshGame(4);
      var kid = put(0, '孩子', 3);
      var src = put(1, '张金雪', 4);
      while (src.hand.length < 3){ var c = g.deck.pop(); if (c) src.hand.push(c); }
      var before = src.hand.length;
      return E.damage(kid, 1, src, 'normal').then(function () {
        ok('【捣乱】受伤后伤害来源随机弃一张手牌',
           src.hand.length === before - 1, before + ' → ' + src.hand.length);
        // 无来源伤害不该触发
        var kid2 = put(0, '孩子', 3);
        var src2 = put(1, '张金雪', 4);
        while (src2.hand.length < 3){ var c2 = g.deck.pop(); if (c2) src2.hand.push(c2); }
        var b2 = src2.hand.length;
        return E.damage(kid2, 1, null, 'thunder').then(function () {
          ok('【捣乱】无来源伤害不触发', src2.hand.length === b2, b2 + ' → ' + src2.hand.length);
          return testHuzhu();
        });
      });
    }

    // ---- 护主：把普通伤害整个接过去 ----
    function testHuzhu(){
      var g = freshGame(4);
      var hogo = put(2, 'Hogo', 3);
      var victim = put(0, '李岩', 3);
      var src = put(1, '张金雪', 4);
      while (hogo.hand.length < 2){ var c = g.deck.pop(); if (c) hogo.hand.push(c); }
      var realAsk = window.UI.askHuman;
      // Hogo 是 AI（座位 2），所以 Ask 走 AI.decide —— 让它答"发动"并弃一张
      var realDecide = window.AI.decide;
      window.AI.decide = function (req){
        if (req.kind === 'choice' && /护主/.test(req.prompt || '')) return Promise.resolve({ option:'yes' });
        if (req.kind === 'selectCards') return Promise.resolve({ cards: [req.player.hand[0]] });
        return realDecide(req);
      };
      var hogoHp = hogo.hp;
      return E.damage(victim, 1, src, 'normal').then(function (){
        window.AI.decide = realDecide;
        window.UI.askHuman = realAsk;
        ok('【护主】伤害转移到了 Hogo 身上（原目标毫发无伤）',
           victim.hp === 3 && hogo.hp === hogoHp - 1,
           '李岩 hp=' + victim.hp + ' Hogo hp=' + hogo.hp);
        // 属性伤害不能替
        var g2 = freshGame(4);
        var hogo2 = put(2, 'Hogo', 3);
        var v2 = put(0, '李岩', 3);
        while (hogo2.hand.length < 2){ var c2 = g2.deck.pop(); if (c2) hogo2.hand.push(c2); }
        return E.damage(v2, 1, put(1, '张金雪', 4), 'fire').then(function (){
          ok('【护主】挡不了属性伤害', v2.hp === 2 && hogo2.hp === 3,
             '李岩 hp=' + v2.hp + ' Hogo hp=' + hogo2.hp);
          return testOthers2();
        });
      });
    }

    // ---- 吠叫 / 铁面 / 双语 ----
    function testOthers2(){
      var g = freshGame(4);
      var hogo = put(2, 'Hogo', 3);
      var att = put(0, '张金雪', 4);
      ok('【吠叫】的持有者能被识别', E.hasSkill(hogo, '吠叫'));

      // 铁面：被封的人出不了事件牌。
      // 用【借笔记】(draw2) 当样本 —— 它永远可出，不受目标/距离/次数影响。
      // 随便抓一张事件牌会写出不稳的测试：像【抄作业】要求距离 1 以内有牌可偷，
      // 没有合法目标时解封了也照样不可出，于是断言时红时绿。
      var zhang = put(0, '张金雪', 4);
      var kid = put(1, '孩子', 3);
      var ev = g.deck.find(function (c) { return c.name === '借笔记'; });
      if (ev){
        kid.eventBan = true;
        kid.hand = [ev];
        var pl = E.playableList(kid).map(function (x) { return x.card.name; });
        ok('【铁面】封住后，事件牌不在可出列表里', pl.indexOf('借笔记') < 0, pl.join('、'));
        kid.eventBan = false;
        var pl2 = E.playableList(kid).map(function (x) { return x.card.name; });
        ok('【铁面】解封后事件牌又能出了', pl2.indexOf('借笔记') >= 0, pl2.join('、'));
      } else {
        ok('（牌堆里没找到借笔记，铁面这条跳过）', true);
      }

      // 双语：开启后点名类牌的目标上限放到 2（引擎侧本来就能多目标）
      var tania = put(0, 'Tania', 4);
      tania.hand = [];
      var atk = g.deck.find(function (c) { return c.name === '上课点名'; });
      if (atk){
        tania.hand.push(atk);
        var us = E.usableSkills(tania).map(function (s) { return s.name; });
        ok('【双语】在可用技能里（有牌可弃时）', us.indexOf('双语') >= 0, us.join('、'));
        tania.bilingual = true;
        var t2 = g.players[2];
        t2.chained = false;
        ok('【双语】是"只弃牌不选人"的技能', !!E.skillTargets(tania, { name:'双语' }));
      }
      ok('7 个角色的性别都进了表',
         P.every(function (c) { return !!E.SEX[c.name]; }),
         P.filter(function (c) { return !E.SEX[c.name]; }).map(function (c) { return c.name; }).join('、'));

      // 端到端：走 initGame 那条真路，确认开关真的把名单撑大了
      // （界面上那一行"剩下的 N 名里挑选"读的就是 G.roster）
      E.initGame({ count:4, mode:'A', deal:3, hotseat:false, humanSeats:[0], packs:{ laoshi:true } });
      ok('开了牢师包后，本局名单 = 基础 + 7（共 ' + window.G.roster.length + ' 名）',
         window.G.roster.length === D.CHARACTERS.length + 7 &&
         window.G.roster.indexOf(by['Tania']) >= 0, window.G.roster.length);
      E.initGame({ count:4, mode:'A', deal:3, hotseat:false, humanSeats:[0] });
      ok('不传 packs 时名单退回基础名单（默认关包）',
         window.G.roster.length === D.CHARACTERS.length, window.G.roster.length);
    }
  });

  /* ---------------------------------------------------------
   *  6e-5. 第一包（9 人）
   * --------------------------------------------------------- */
  group('第一包', function () {
    var P = D.PACKS.pack1;
    var by = {};
    P.forEach(function (c) { by[c.name] = c; });

    ok('第一包 9 人，名字和设计表一致',
       ['馒头', '老猫', '老姜', '老瓶', '老湖人', '老石', '老虎', '黄熊', '西鱼']
         .every(function (n) { return !!by[n]; }),
       P.map(function (c) { return c.name; }).join('、'));
    ok('每人最多 2 个技能', P.every(function (c) { return c.skills.length <= 2; }));
    ok('9 个角色的性别都进了表',
       P.every(function (c) { return !!E.SEX[c.name]; }),
       P.filter(function (c) { return !E.SEX[c.name]; }).map(function (c) { return c.name; }).join('、'));
    ok('英文名放称号、姓名保持中文（AI 是按中文名找人的）',
       by['馒头'].name === '馒头' && /Steam Bun/.test(by['馒头'].title), by['馒头'].title);

    function put(seat, name, hp){
      var g = window.G;
      var p = g.players[seat];
      p.char = by[name]; p.hp = hp; p.maxHp = hp;
      p.hand = []; p.judge = []; p.equips = { weapon:null, armor:null, mountUp:null, mountDown:null };
      p.marks = {}; p.skillsUsedThisTurn = {}; p.usedCardsThisTurn = []; p.chained = false;
      p.damageDealtThisTurn = 0; p.dodgeBan = false; p.eventBan = false;
      return p;
    }

    // ---- 全场紧逼 / 扛：两个直接读属性的 ----
    var g0 = freshGame(4);
    var laker = put(0, '老湖人', 4);
    ok('【全场紧逼】无武器时攻击范围 1 → 2', E.attackRange(laker) === 2, E.attackRange(laker));
    var bear = put(1, '黄熊', 4);
    // 身份要钉死 —— freshGame 是随机身份的，黄熊万一被分成院长就也 +1（4+1+1=6），
    // 断言会时红时绿
    bear.identity = 'student';
    E.finalizeGame();
    ok('【扛】体力上限 +1（角色 4 → 5）', bear.maxHp === 5 && bear.hp === 5,
       bear.maxHp + ' / ' + bear.hp);

    // ---- 石肤：属性伤害 -1；普通伤害不受影响 ----
    var g1 = freshGame(4);
    var stone = put(0, '老石', 4);
    var atk1 = put(1, '老猫', 4);
    return E.damage(stone, 1, atk1, 'fire').then(function (d){
      ok('【石肤】属性伤害被减到 0', d === 0 && stone.hp === 4, 'dealt=' + d + ' hp=' + stone.hp);
      return E.damage(stone, 1, atk1, 'normal').then(function (d2){
        ok('【石肤】不减普通伤害', d2 === 1 && stone.hp === 3, 'dealt=' + d2);
        return testPanju();
      });
    });

    // ---- 盘踞：来源在自己攻击范围内时 -1，但每回合限一次 ----
    function testPanju(){
      var g = freshGame(4);
      ok('老虎 2 血（超模削弱：4 → 2，和它两个技能的强度配平）',
         by['老虎'].hp === 2, by['老虎'].hp);
      var tiger = put(0, '老虎', 4);
      var foe = put(1, '老猫', 4);      // 相邻，在老虎的攻击范围内
      return E.damage(tiger, 1, foe, 'normal').then(function (d){
        ok('【盘踞】来源在攻击范围内时伤害 -1', d === 0 && tiger.hp === 4, 'dealt=' + d);
        // **不限次**：老虎只有 2 点体力上限，血量已经替它把超模的债还了。
        // （早先"2 血 + 盘踞限次"两层削弱叠在一起，探针跑出来它是全场倒数）
        return E.damage(tiger, 1, foe, 'normal');
      }).then(function (d2){
        ok('【盘踞】不限次数（血量已经替它还了债）', d2 === 0 && tiger.hp === 4, 'dealt=' + d2);
        // 但它只减 1 点，不是免伤 —— 大伤害照样打得进来
        return E.damage(tiger, 3, foe, 'normal');
      }).then(function (d3){
        ok('【盘踞】只减 1 点，3 点伤害照样打进 2 点', d3 === 2 && tiger.hp === 2, 'dealt=' + d3);
        return testLashou();
      });
    }

    // ---- 辣手：反伤 1 点，且不会无限递归 ----
    function testLashou(){
      var g = freshGame(4);
      var ginger = put(0, '老姜', 4);
      var foe = put(1, '老猫', 4);
      return E.damage(ginger, 1, foe, 'normal').then(function (){
        ok('【辣手】伤害来源被反弹 1 点', ginger.hp === 3 && foe.hp === 3,
           '老姜 ' + ginger.hp + ' / 老猫 ' + foe.hp);
        return testHot();
      });
    }

    // ---- 热乎：回复体力时额外摸一张 ----
    function testHot(){
      var g = freshGame(4);
      var bun = put(0, '馒头', 3);
      bun.hp = 2; bun.hand = [];
      return E.heal(bun, 1, '测试', null).then(function (){
        ok('【热乎】回复体力时摸一张', bun.hand.length === 1, bun.hand.length);
        // 体力已满时 heal 不回血，也就不该触发
        var bun2 = put(0, '馒头', 3);
        bun2.hp = 3; bun2.hand = [];
        return E.heal(bun2, 1, '测试', null).then(function (){
          ok('【热乎】体力已满（没真的回血）时不触发', bun2.hand.length === 0, bun2.hand.length);
          return testNineLives();
        });
      });
    }

    // ---- 九条命：本局第一次濒死直接回到 1 点 ----
    function testNineLives(){
      var g = freshGame(4);
      var cat = put(0, '老猫', 4);
      var foe = put(1, '老姜', 4);
      return E.damage(cat, 6, foe, 'normal').then(function (){
        ok('【九条命】首次濒死直接回到 1 点', cat.hp === 1 && cat.alive,
           'hp=' + cat.hp + ' alive=' + cat.alive);
        ok('【九条命】本局只此一次（标记已写入）', !!cat.marks.nineLives);
        // 第二次就不再救
        return E.damage(cat, 6, foe, 'normal').then(function (){
          ok('【九条命】第二次濒死不再触发', cat.hp <= 0, 'hp=' + cat.hp);
          return testJiuping();
        });
      });
    }

    // ---- 旧瓶：整回合一张牌都没用过则摸两张 ----
    function testJiuping(){
      var g = freshGame(4);
      var bottle = put(0, '老瓶', 3);
      bottle.usedCardsThisTurn = [];
      return E.endTurn(bottle).then(function (){
        ok('【旧瓶】本回合没出过牌 → 摸两张', bottle.hand.length === 2, bottle.hand.length);
        var b2 = put(0, '老瓶', 3);
        b2.usedCardsThisTurn = [{}];      // 本回合出过牌
        return E.endTurn(b2).then(function (){
          ok('【旧瓶】出过牌就不给', b2.hand.length === 0, b2.hand.length);
          return testActiveSkills();
        });
      });
    }

    // ---- 主动技的候选过滤 ----
    function testActiveSkills(){
      var g = freshGame(4);
      var cat = put(0, '老猫', 4);
      var foe = put(1, '老姜', 4);
      while (cat.hand.length < 2){ var c = g.deck.pop(); if (c) cat.hand.push(c); }
      foe.hand = [];
      ok('【爪子】不能指定没手牌的人', E.skillTargets(cat, { name:'爪子' }).indexOf(foe) < 0);
      while (foe.hand.length < 1){ var c2 = g.deck.pop(); if (c2) foe.hand.push(c2); }
      ok('【爪子】可以指定有手牌的人', E.skillTargets(cat, { name:'爪子' }).indexOf(foe) >= 0);
      ok('【爪子】不能指定自己', E.skillTargets(cat, { name:'爪子' }).indexOf(cat) < 0);

      var us = E.usableSkills(cat).map(function (s) { return s.name; });
      ok('【爪子】出现在可用技能里', us.indexOf('爪子') >= 0, us.join('、'));

      // 虎啸：目标由技能自己算（范围内所有人），界面上不该走选人流程。
      // 判据是 usableSkills 给出的 needTarget —— 注意**不能**靠"候选为空"来表达：
      // 按钮的禁用条件就是候选数 === 0，返回空会让按钮永远点不动。
      var tiger = put(2, '老虎', 4);
      while (tiger.hand.length < 1){ var c3 = g.deck.pop(); if (c3) tiger.hand.push(c3); }
      var tigSkill = E.usableSkills(tiger).filter(function (s) { return s.name === '虎啸'; })[0];
      ok('【虎啸】是可用的', !!tigSkill);
      ok('【虎啸】标记为"不需要选目标"', !!tigSkill && tigSkill.needTarget === false,
         tigSkill && String(tigSkill.needTarget));

      // 摆尾：不选目标、不弃牌就能用
      var fish = put(3, '西鱼', 3);
      fish.hand = [];
      var fUs = E.usableSkills(fish).map(function (s) { return s.name; });
      ok('【摆尾】空手也能用（它自己会摸两张）', fUs.indexOf('摆尾') >= 0, fUs.join('、'));

      // 端到端：开第一包后名单 +9
      E.initGame({ count:4, mode:'A', deal:3, hotseat:false, humanSeats:[0], packs:{ pack1:true } });
      ok('开了第一包后，本局名单 = 基础 + 9（共 ' + window.G.roster.length + ' 名）',
         window.G.roster.length === D.CHARACTERS.length + 9 &&
         window.G.roster.indexOf(by['老猫']) >= 0, window.G.roster.length);
      E.initGame({ count:4, mode:'A', deal:3, hotseat:false, humanSeats:[0] });
      ok('两个包一起开 = 基础 + 16（共 ' + D.roster({ laoshi:true, pack1:true }).length + ' 名）',
         D.roster({ laoshi:true, pack1:true }).length === D.CHARACTERS.length + 16);
    }
  });

  /* ---------------------------------------------------------
   *  6e-6. 对局形式（format）轴
   *
   *  这一轴是把"身份局 / 斗地主 / 2V2"三种玩法并到一套规则里的开关。
   *  这组测试只要盯两件事：①身份局的行为**一点没变**（纯重构）
   *  ②非身份局不崩（改之前 3 人局必崩）
   * --------------------------------------------------------- */
  group('对局形式（format）轴', function () {
    var g = freshGame(5);
    ok('默认形式是身份局', window.G.format === 'identity', window.G.format);
    var dean = g.players.filter(function (p) { return p.identity === 'dean'; })[0];
    ok('身份局：院长先手', g.turnSeat === dean.seat, g.turnSeat + ' vs ' + dean.seat);
    ok('身份局：院长的身份公开', E.sideInfo(dean).visible === true);
    ok('身份局：学生的身份不公开',
       E.sideInfo(g.players.filter(function (p) { return p.identity === 'student'; })[0]).visible === false);

    // 「身份 → 获胜阵营」原先在 4 个文件里各写了一遍，现在收敛成 E.winOf
    ok('E.winOf：院方胜利时教务也算赢', E.winOf('dean', { identity:'staff' }) === true);
    ok('E.winOf：院方胜利时学生不算赢', E.winOf('dean', { identity:'student' }) === false);
    ok('E.winOf：平局时谁都不赢', E.winOf(null, { identity:'dean' }) === false);

    // 3 人局：改之前 IDENTITY_CONFIG[3] 不存在 → 回落 5 人配置 → 3 个座位可能
    // 一个院长都分不到 → finalizeGame 的 dean.seat 直接抛异常
    var threw = null;
    try {
      E.initGame({ count:3, mode:'A', deal:3, hotseat:false, humanSeats:[0], format:'landlord' });
    } catch (e){ threw = e; }
    ok('非身份局开局不崩（3 人）', !threw, threw && threw.message);
    ok('非身份局下 p.identity 全是 null（不硬塞身份）',
       window.G.players.every(function (p) { return p.identity === null; }));
    ok('非身份局下 G.mode 被清空（否则身份轮抽会对空池子死循环）',
       window.G.mode === null, String(window.G.mode));
    ok('非身份局下 E.sideInfo 不崩',
       (function () { try { return E.sideInfo(window.G.players[0]).key === null; }
                      catch (e){ return false; } })());
    // 注：开始界面（main.js）不在这个测试页里，所以"身份预览不崩"改由
    // page_smoke 在真实 index.html 上验 —— 那种断言写在这里只会永远为真。

    E.initGame({ count:5, mode:'A', deal:3, hotseat:false, humanSeats:[0] });
    ok('切回身份局一切照旧', window.G.format === 'identity' &&
       window.G.players.filter(function (p) { return p.identity === 'dean'; }).length === 1);
  });

  /* ---------------------------------------------------------
   *  6e-7. 2V2 模式
   * --------------------------------------------------------- */
  group('2V2 模式', function () {
    E.initGame({ count:4, mode:'A', deal:3, hotseat:false, humanSeats:[0], format:'team2v2' });
    var g = window.G;
    ok('2V2 是 4 人局', g.players.length === 4, g.players.length);
    ok('阵营交错：1、4 号位一队',
       g.players[0].side === 'A' && g.players[3].side === 'A',
       g.players.map(function (p) { return p.side; }).join(','));
    ok('2、3 号位是另一队',
       g.players[1].side === 'B' && g.players[2].side === 'B');
    ok('全员没有身份（不硬塞 identity）',
       g.players.every(function (p) { return p.identity === null; }));
    ok('玩法名是 2V2', E.formatLabel() === '2V2', E.formatLabel());

    g.players.forEach(function (p, i) { p.char = D.CHARACTERS[i]; });
    E.finalizeGame();
    ok('1 号位先手', g.turnSeat === 0, g.turnSeat);
    ok('体力没有身份加成', g.players.every(function (p) { return p.maxHp === p.char.hp; }));
    ok('保护轮被强制关掉（它会把"5 分钟一局"拖没）', g.opts.protect === false);

    E.dealInitialHands();
    ok('起手：1/2/3 号位各 4 张、4 号位 5 张',
       g.players[0].hand.length === 4 && g.players[1].hand.length === 4 &&
       g.players[2].hand.length === 4 && g.players[3].hand.length === 5,
       g.players.map(function (p) { return p.hand.length; }).join(','));
    ok('阵营对所有人公开（队友明置）',
       g.players.every(function (p) { return E.sideInfo(p).visible === true; }));
    ok('E.winOf 按阵营判',
       E.winOf('A', g.players[0]) === true && E.winOf('A', g.players[1]) === false);
    ok('阵营名是红队 / 蓝队', E.sideLabel('A') === '红队' && E.sideLabel('B') === '蓝队',
       E.sideLabel('A') + '/' + E.sideLabel('B'));
    // AI 的所有决策都汇聚到 threat()：同队必须是负数（不打自己人），异队必须是正数
    ok('AI 认得出队友：同队威胁为负、异队为正',
       (function () {
         var me = g.players[0];       // 红队
         return window.AI.threat(me, g.players[3]) < 0 &&    // 队友
                window.AI.threat(me, g.players[1]) > 0;      // 敌人
       })(),
       window.AI.threat(g.players[0], g.players[3]) + ' / ' +
       window.AI.threat(g.players[0], g.players[1]));

    // 全 AI 跑完一整局 —— 引擎、AI 取舍、胜负判定、赛后结算一起过一遍
    g.speed = 0.01;
    g.players.forEach(function (p) { p.isHuman = false; });
    return E.gameLoop().then(function (){
      ok('2V2 能全 AI 跑完一整局', g.over === true);
      var w = g.scoreboard && g.scoreboard.winner;
      ok('结束时胜方是红队或蓝队', w === 'A' || w === 'B', String(w));
      if (w === 'A' || w === 'B'){
        var losers = g.players.filter(function (p) { return p.side !== w; });
        ok('负方两人全部阵亡', losers.every(function (p) { return !p.alive; }),
           losers.map(function (p) { return p.name + ':' + p.alive; }).join(' '));
        ok('赢方有人被记了胜利',
           g.scoreboard.rows.filter(function (r) { return r.win; }).length >= 1);
      }
    });
  });

  /* ---------------------------------------------------------
   *  6e-8. 斗地主模式
   * --------------------------------------------------------- */
  group('斗地主模式', function () {
    // 三个座位都设成"真人"，这样 redealForLandlord 会给每人发候选，能验到 5/3 的差异
    E.initGame({ count:3, mode:'A', deal:3, hotseat:false,
                 humanSeats:[0,1,2], format:'landlord' });
    var g = window.G;
    ok('斗地主是 3 人局', g.players.length === 3, g.players.length);
    ok('开局时还没有地主（要叫完分才定）',
       g.players.every(function (p) { return p.side === null; }));
    ok('玩法名是斗地主', E.formatLabel() === '斗地主', E.formatLabel());

    // ---- 叫分 ----
    ok('第一个该叫分的是 0 号位', E.bidNext() === 0, E.bidNext());
    E.bidSubmit(0, 1);
    ok('叫过的不再问', E.bidNext() === 1, E.bidNext());
    E.bidSubmit(1, 0);
    E.bidSubmit(2, 2);
    ok('全叫完返回 -1', E.bidNext() === -1, E.bidNext());
    var llSeat = E.bidFinish();
    ok('最高分者当地主', llSeat === 2, llSeat);
    ok('叫分记下来了（地主胜 = 叫分×2）', g.bidScore === 2, g.bidScore);
    ok('另外两人是农民',
       g.players.filter(function (p) { return p.side === 'farmer'; }).length === 2);
    ok('地主 5 张候选、农民各 3 张',
       g.players[2].charChoices.length === 5 && g.players[0].charChoices.length === 3 &&
       g.players[1].charChoices.length === 3,
       g.players.map(function (p) { return p.charChoices.length; }).join(','));

    g.players.forEach(function (p, i) { p.char = D.CHARACTERS[i]; });
    E.finalizeGame();
    ok('地主先手', g.turnSeat === 2, g.turnSeat);
    ok('地主 +1 体力上限', g.players[2].maxHp === g.players[2].char.hp + 1,
       g.players[2].maxHp + ' vs ' + g.players[2].char.hp);
    ok('农民没有加成', g.players[0].maxHp === g.players[0].char.hp);
    ok('地主拿到了两个身份技（放在 extraSkills，不污染角色牌）',
       g.players[2].extraSkills && g.players[2].extraSkills.length === 2,
       String(g.players[2].extraSkills));
    ok('hasSkill 认得身份技', E.hasSkill(g.players[2], '跋扈') && E.hasSkill(g.players[2], '飞扬'));
    ok('农民没有身份技', !E.hasSkill(g.players[0], '跋扈'));
    ok('角色牌上没有多出技能（selftest 那条约束还成立）',
       g.players[2].char.skills.length === 2 &&
       g.players[2].char.skills.every(function (s) { return s.name !== '跋扈'; }));
    ok('技能说明能查到身份技', /多摸一张/.test(E.skillList(g.players[2]).map(function (s) { return s.text; }).join('')));

    // ---- 【跋扈】：多摸一张 + 多出一张点名牌 ----
    g.players[2].usedAttackCardThisPhase = 1;
    ok('【跋扈】让地主能出第二张点名牌', E.canUseAttack(g.players[2], { name:'上课点名' }) === true);
    g.players[2].usedAttackCardThisPhase = 2;
    ok('用满 2 张后地主也不能再出', E.canUseAttack(g.players[2], { name:'上课点名' }) === false);
    g.players[0].usedAttackCardThisPhase = 1;
    ok('农民用满 1 张就不能再出', E.canUseAttack(g.players[0], { name:'上课点名' }) === false);

    E.dealInitialHands();
    ok('起手：地主 7 张（4 + 3 张底牌）', g.players[2].hand.length === 7, g.players[2].hand.length);
    ok('后行动的农民 5 张、先行动的 4 张',
       g.players[1].hand.length === 5 && g.players[0].hand.length === 4,
       g.players.map(function (p) { return p.hand.length; }).join(','));
    ok('E.winOf 按阵营判', E.winOf('landlord', g.players[2]) === true &&
       E.winOf('landlord', g.players[0]) === false);
    ok('阵营名是地主 / 农民', E.sideLabel('landlord') === '地主' && E.sideLabel('farmer') === '农民');

    // ---- 【飞扬】：弃两张，清空自己的通知栏 ----
    var ll = g.players[2];
    ll.judge = [g.deck.pop(), g.deck.pop()];
    while (ll.hand.length < 3){ var c = g.deck.pop(); if (c) ll.hand.push(c); }
    var realAsk = window.UI.askHuman;
    var answers = [{ option:'yes' }, { cards:[ll.hand[0], ll.hand[1]] }];
    window.UI.askHuman = function (){ return Promise.resolve(answers.shift()); };
    var handBefore = ll.hand.length;
    var judgeBefore = ll.judge.length;
    return E._skills.飞扬(ll).then(function (){
      window.UI.askHuman = realAsk;
      ok('【飞扬】弃两张牌、清空通知栏',
         ll.judge.length === 0 && ll.hand.length === handBefore - 2,
         '通知栏 ' + judgeBefore + '→' + ll.judge.length + '　手牌 ' + handBefore + '→' + ll.hand.length);

      // ---- 全 AI 跑完一整局 ----
      g.speed = 0.01;
      g.players.forEach(function (p) { p.isHuman = false; });
      return E.gameLoop().then(function (){
        ok('斗地主能全 AI 跑完一整局', g.over === true);
        var w = g.scoreboard && g.scoreboard.winner;
        // 平局（null）也是合法结局：一次群伤或【论文查重】的传导可能把最后两人一起带走
        ok('胜方是地主、农民，或同归于尽算平局',
           w === 'landlord' || w === 'farmer' || w === null, String(w));
        if (w === 'landlord'){
          ok('地主胜 = 两个农民都出局',
             g.players.filter(function (p) { return p.side === 'farmer'; })
                       .every(function (p) { return !p.alive; }));
        } else if (w === 'farmer'){
          ok('农民胜 = 地主出局',
             g.players.filter(function (p) { return p.side === 'landlord'; })[0].alive === false);
        }
      });
    });
  });

  /* ---------------------------------------------------------
   *  6e-9. 2V2 的禁选（简化版）
   * --------------------------------------------------------- */
  group('2V2 禁选', function () {
    E.initGame({ count:4, mode:'A', deal:3, hotseat:false,
                 humanSeats:[0,1,2,3], format:'team2v2' });
    var g = window.G;
    ok('新的一局禁选状态是干净的',
       g.banDone === false && g.bannedIds.length === 0,
       g.banDone + ' / ' + g.bannedIds.length);
    ok('第一个该禁的是 0 号位', E.banNext() === 0, E.banNext());

    var b0 = g.roster[0].id, b2 = g.roster[1].id, b3 = g.roster[2].id;
    E.banSubmit(0, b0);
    ok('禁掉的武将进了禁用名单', g.bannedIds.indexOf(b0) >= 0, g.bannedIds.join(','));
    ok('禁过的不再问', E.banNext() === 1, E.banNext());
    E.banSubmit(1, null);                     // 这个座位放弃禁
    E.banSubmit(2, b2);
    E.banSubmit(3, b3);
    ok('放弃的那个座位不算禁用',
       g.bannedIds.length === 3, g.bannedIds.join(','));
    ok('全禁完返回 -1', E.banNext() === -1, E.banNext());

    E.banFinish();
    ok('禁选收尾标记置上', g.banDone === true);
    ok('被禁的武将不再出现在任何人的候选里',
       g.players.every(function (p) {
         return p.charChoices.every(function (c) { return g.bannedIds.indexOf(c.id) < 0; });
       }),
       g.bannedIds.join(','));
    ok('每人重新拿到 3 张候选',
       g.players.every(function (p) { return p.charChoices.length === 3; }),
       g.players.map(function (p) { return p.charChoices.length; }).join(','));
    ok('候选之间不重叠',
       (function () {
         var ids = [];
         g.players.forEach(function (p) {
           p.charChoices.forEach(function (c) { ids.push(c.id); });
         });
         return new Set(ids).size === ids.length;
       })());
  });

  /* ---------------------------------------------------------
   *  6e-10. 音频（BGM + 语音报牌）
   * --------------------------------------------------------- */
  group('音频', function () {
    var w = window;
    ok('BGM 与语音都挂在 FX 上', !!w.FX.bgm && !!w.FX.voice);
    ok('BGM 有开关与音量接口',
       typeof w.FX.bgm.setOn === 'function' && typeof w.FX.bgm.setVol === 'function');
    ok('语音有开关、性别、试听接口',
       typeof w.FX.voice.setOn === 'function' && typeof w.FX.voice.setSex === 'function' &&
       typeof w.FX.voice.speak === 'function');

    // 没有 audio/bgm/ 目录时必须静默跳过 —— 单文件手机版就是这种情况，
    // 报错或卡住都会让它在手机上开不起来
    var threw = null;
    try { w.FX.bgm.load(); } catch (e){ threw = e; }
    ok('加载 BGM 不抛异常（没有 audio/ 目录时也一样 —— 单文件手机版就是那样）',
       !threw, threw && threw.message);
    ok('加载尝试被记录下来了', w.FX.bgm.tried === true);
    // 关键不变式：ready 只在**真的拿到音频元素**之后才为 true。
    // （音频文件现在是有的，所以不能再断言"必定 ready=false"）
    ok('ready 与"真的拿到了音频元素"一致（不会误报）',
       w.FX.bgm.ready === !!w.FX.bgm.el,
       'ready=' + w.FX.bgm.ready + ' el=' + !!w.FX.bgm.el);

    // 音量会被夹在 0..1
    w.FX.bgm.setVol(5);
    ok('音量上限被夹住', w.FX.bgm.vol === 1, w.FX.bgm.vol);
    w.FX.bgm.setVol(-3);
    ok('音量下限被夹住', w.FX.bgm.vol === 0, w.FX.bgm.vol);
    w.FX.bgm.setVol(0.35);

    // 没有 speechSynthesis 的环境（无头测试就是这样）不能炸
    var vThrew = null;
    try { w.FX.voice.speak('上课点名'); } catch (e){ vThrew = e; }
    ok('没有语音合成时 speak 静默跳过', !vThrew, vThrew && vThrew.message);

    // 真正要验的：出牌有没有**真的**去调语音。
    // 先复位节流 —— 前面几组测试跑完整局，刚念过技能台词，
    // 那个 1.5 秒闸门会挡住报牌（那是真行为，不是 bug）
    if (w.FX._resetVoiceThrottle) w.FX._resetVoiceThrottle();
    var spoke = [];
    var realSpeak = w.FX.voice.speak;
    w.FX.voice.speak = function (t){ spoke.push(t); };
    return w.FX.cardPlay('测试', { name:'上课点名' }, '', { hold: 1 }).then(function (){
      w.FX.voice.speak = realSpeak;
      ok('出牌时会念牌名', spoke.indexOf('上课点名') >= 0, spoke.join(','));

      // 性别切换要真的存下来
      w.FX.voice.setSex('male');
      var saved = null;
      try { saved = localStorage.getItem('dqk_voice_sex'); } catch (e){ saved = null; }
      ok('性别选择存进了本机', saved === 'male', String(saved));
      w.FX.voice.setSex('female');

      // ---- 技能语音 ----
      // 覆盖率：每个技能都得有一句台词。漏了新角色不会有任何报错，
      // 只是那个角色永远不吭声 —— 所以这条必须钉住。
      var missing = [];
      D.allCharacters().forEach(function (c) {
        c.skills.forEach(function (s) {
          if (!w.GameData.SKILL_LINES[s.name]) missing.push(s.name);
        });
      });
      ok('每个技能都有语音台词（共 ' + Object.keys(w.GameData.SKILL_LINES).length + ' 句）',
         missing.length === 0, '缺：' + missing.join('、'));

      var said = [];
      var realSpeak2 = w.FX.voice.speak;
      w.FX.voice.speak = function (t){ said.push(t); };

      w.FX.saySkillFromLog('董旭 发动【冲锋】，视为使用"上课点名"');
      ok('日志里出现技能名 → 念对应台词',
         said.length === 1 && /打头阵/.test(said[0]), said.join('|'));

      w.FX.saySkillFromLog('董旭 发动【冲锋】');
      ok('同一个技能短时间内不重复念（否则【正义】会念成一片）',
         said.length === 1, String(said.length));

      w.FX.saySkillFromLog('某人 发动【根本不存在的技能】');
      ok('表里没有的技能名不念', said.length === 1, String(said.length));

      w.FX.saySkillFromLog('董伦 受到 1 点普通伤害 [系统 -1]');
      ok('被动技能（伤害减免）也会念 —— 它的名字在方括号里不在【】里',
         said.length === 2 && /底牌/.test(said[1]), said.join('|'));

      w.FX.voice.speak = realSpeak2;
    });
  });

  /* ---------------------------------------------------------
   *  6e-2. 邀请链接的 localhost 提醒
   *
   *  房主用 localhost 打开本页时，邀请链接里就是 localhost，
   *  同学点开各连各的电脑 —— 这是 A 方案（内网穿透）要解决的核心翻车点，
   *  所以判据和文案都要钉住。
   * --------------------------------------------------------- */
  group('邀请链接的 localhost 提醒', function () {
    ok('localhost 算本机地址', Net.isLoopbackUrl('http://localhost:8080/?room=1234'));
    ok('127.0.0.1 算', Net.isLoopbackUrl('http://127.0.0.1:8080/?room=1234'));
    ok('127.x 整段都算', Net.isLoopbackUrl('http://127.9.9.9:8080/'));
    ok('[::1] 算', Net.isLoopbackUrl('http://[::1]:8080/?room=1234'));
    ok('0.0.0.0 算', Net.isLoopbackUrl('http://0.0.0.0:8080/'));
    ok('x.localhost 算（浏览器也把它当本机）', Net.isLoopbackUrl('http://a.localhost:8080/'));

    ok('局域网地址不算', !Net.isLoopbackUrl('http://192.168.1.5:8080/?room=1234'));
    ok('10.x 不算', !Net.isLoopbackUrl('http://10.108.126.109:8080/?room=1234'));
    ok('隧道地址不算', !Net.isLoopbackUrl('https://milk-flux-mark.trycloudflare.com/?room=1234'));
    ok('空值不算', !Net.isLoopbackUrl('') && !Net.isLoopbackUrl(null) && !Net.isLoopbackUrl(undefined));
    // 用 'http://'（连主机名都没有）而不是随手中文：相对路径会按当前页面地址解析，
    // 这个测试页在 -Net 套件里就是从 127.0.0.1 打开的，拿中文当样本会假失败。
    ok('残缺地址不算', !Net.isLoopbackUrl('http://'));

    var warn = Net.inviteWarnHtml('http://localhost:8080/?room=1234');
    ok('localhost 链接会给出提醒', /localhost/.test(warn));
    ok('提醒里点明了同学连不上', /连的是他自己的电脑/.test(warn));
    ok('提醒里指了一键内网穿透这条路', /start-online\.bat/.test(warn));
    ok('局域网链接不提醒', Net.inviteWarnHtml('http://192.168.1.5:8080/?room=1234') === '');
    ok('没有链接时不提醒', Net.inviteWarnHtml('') === '');
  });

  /* ---------------------------------------------------------
   *  6e-3. 音色包（audio/voice/）
   *
   *  项目里第一次 mock fetch —— 这个页面是 file:// 打开的，真去请求
   *  audio/voice/packs.json 必然失败，所以只能自己造响应。
   * --------------------------------------------------------- */
  group('音色包（audio/voice）', function () {
    var w = window;
    var v = w.FX.voice;
    v.setOn(true);          // 别的组可能关过，这里要的是"开着的时候怎么选路"

    // 别假设"这个环境没有音色包"：套件是 file:// 打开的，而
    // --allow-file-access-from-files 下 fetch 能读到 audio/voice/packs.json
    // （生成过音色包时就会读到）。所以这里只钉"系统两项永远排最前"，
    // "完全读不到清单"那条路在本组末尾单独测。
    var list0 = v.packList();
    ok('系统两个选项永远排在最前面',
       list0.length >= 2 && list0[0].k === 'sys-female' && list0[1].k === 'sys-male',
       list0.map(function (o){ return o.k; }).join('|'));

    // 文件名规则：生成端（tools/voicegen.py）按同一条规则写文件。
    // 顺带钉住数据本身 —— 牌名/技能名里出现 < > : " / \ | ? * 会让生成器直接罢工。
    ok('牌名/技能名里没有不能当文件名的字符',
       Object.keys(D.CARDS).every(function (n){ return !/[<>:"/\\|?*]/.test(n); }) &&
       Object.keys(D.SKILL_LINES).every(function (n){ return !/[<>:"/\\|?*]/.test(n); }),
       Object.keys(D.CARDS).filter(function (n){ return /[<>:"/\\|?*]/.test(n); }).join(','));
    ok('报牌名映射成 c-<牌名>.mp3', v.fileName('上课点名', 'card') === 'c-上课点名.mp3',
       v.fileName('上课点名', 'card'));
    ok('技能台词映射成 s-<技能名>.mp3', v.fileName('正义', 'skill') === 's-正义.mp3',
       v.fileName('正义', 'skill'));

    var realFetch = w.fetch;
    var asked = null;
    var fake = {
      ext: 'mp3',
      packs: [{ id: 'zf_001', name: '女声 1', sex: 'female', dir: 'zf_001' },
              { id: 'zm_009', name: '男声 1', sex: 'male', dir: 'zm_009' }]
    };
    w.fetch = function (url){
      asked = url;
      return Promise.resolve({ ok: true, json: function (){ return Promise.resolve(fake); } });
    };
    if (v._resetPacks) v._resetPacks();

    return v.loadPacks().then(function (ready){
      w.fetch = realFetch;
      ok('清单读得进来', ready === true && v.packsReady() === true);
      ok('请求的是 audio/voice/packs.json', /audio\/voice\/packs\.json$/.test(String(asked)), String(asked));
      ok('选项 = 系统 2 + 音色包 2，标签取清单里的名字',
         v.packList().length === 4 && v.packList()[2].label === '女声 1',
         v.packList().map(function (o){ return o.label; }).join('|'));

      v.setPack('zf_001');
      ok('选中的音色包记住了', v.currentPack() && v.currentPack().id === 'zf_001');
      var savedPack = null;
      try { savedPack = localStorage.getItem('dqk_voice_pack'); } catch (e){}
      ok('音色选择存进 localStorage', savedPack === 'zf_001', String(savedPack));

      // 选了音色包 → 报牌和技能台词各自去放对应的文件（前缀不一样）
      var realPlay = v.playUrl, got = null;
      v.playUrl = function (url){ got = url; return true; };
      v.speak('上课点名', 'card');
      ok('报牌放 c-<牌名>.mp3', /audio\/voice\/zf_001\/c-上课点名\.mp3$/.test(String(got)), String(got));
      v.speak('正义', 'skill');
      ok('技能台词放 s-<技能名>.mp3', /audio\/voice\/zf_001\/s-正义\.mp3$/.test(String(got)), String(got));
      v.playUrl = realPlay;

      // 文件放不出来（还没配音 / 名字对不上）→ 退回系统语音，不能让战斗忽然变哑
      var sys = [];
      var realSys = v._sysSpeak;
      v._sysSpeak = function (t){ sys.push(t); };
      v._onPackError('正义');
      ok('音色包文件放不出来时退回系统语音', sys.length === 1 && sys[0] === '正义', sys.join('|'));
      v._sysSpeak = realSys;

      // 切回系统语音：不再碰文件
      v.setPack('sys-male');
      ok('切回系统男声（系统语音的音高也跟着切）',
         v.currentPack() === null && v.pack === 'sys-male' && v.sex === 'male', v.sex);
      var realPlay2 = v.playUrl, touched = false;
      v.playUrl = function (){ touched = true; return false; };
      v.speak('上课点名', 'card');
      ok('系统音色时不放音色包文件', touched === false, String(touched));
      v.playUrl = realPlay2;
      v.setPack('sys-female');

      // 清单里没有的音色 id（换过音色集 / 重新生成过）：自动回到系统女声，
      // 免得选择器上一个选中项都没有、看起来像坏了
      v.pack = 'zf_999';
      if (v._resetPacks) v._resetPacks();
      var realFetch3 = w.fetch;
      w.fetch = function (){ return Promise.resolve({ ok: true, json: function (){ return Promise.resolve(fake); } }); };
      return v.loadPacks().then(function (){
        w.fetch = realFetch3;
        ok('清单里没有的音色 id 自动回到系统女声', v.pack === 'sys-female', String(v.pack));

        // 反过来：用户选的「系统男声」不能被当成"不在清单里"而被重置
        v.setPack('sys-male');
        if (v._resetPacks) v._resetPacks();
        var realFetch4 = w.fetch;
        w.fetch = function (){ return Promise.resolve({ ok: true, json: function (){ return Promise.resolve(fake); } }); };
        return v.loadPacks().then(function (){
          w.fetch = realFetch4;
          ok('系统男声不会被清单覆盖成女声', v.pack === 'sys-male', String(v.pack));

          // 清单读不到（没生成过音色包 / 单文件手机版）：安静退回系统语音，不炸
          if (v._resetPacks) v._resetPacks();
          var realFetch2 = w.fetch;
          w.fetch = function (){ return Promise.reject(new Error('404')); };
          return v.loadPacks().then(function (ok2){
            w.fetch = realFetch2;
            ok('清单读不到时不抛异常、安静退回系统语音',
               ok2 === false && v.packsReady() === false && v.packList().length === 2);

            // 失败不粘住：下一次调用（比如再开一次设置）要能重试成功 ——
            // 从隧道地址打开时第一次请求可能正好撞上慢启动。
            var realFetch5 = w.fetch;
            w.fetch = function (){ return Promise.resolve({ ok: true, json: function (){ return Promise.resolve(fake); } }); };
            return v.loadPacks().then(function (ok3){
              w.fetch = realFetch5;
              ok('上次读失败不粘住，下次还能读成功', ok3 === true && v.packsReady() === true);
            });
          });
        });
      });
    });
  });

  /* ---------------------------------------------------------
   *  6f. 坐骑拆成两个独立栏位
   * --------------------------------------------------------- */
  group('+1 / −1 坐骑是两个独立栏位', function () {
    var g = freshGame(5);
    var p = g.players[2];
    var up   = g.deck.filter(function (c) { return D.CARDS[c.name].slot === 'mountUp'; })[0];
    var down = g.deck.filter(function (c) { return D.CARDS[c.name].slot === 'mountDown'; })[0];
    p.equips.mountUp = up;
    p.equips.mountDown = down;

    ok('装备栏一共四格', D.EQUIP_SLOTS.length === 4, D.EQUIP_SLOTS.join(','));
    ok('+1 与 −1 落在不同栏位', up.slot !== down.slot, up.slot + ' / ' + down.slot);

    // 投影：客户端两边都要收到（少一个就会出现"我明明有 −1 坐骑但距离不对"）
    var sp = Net.project(1, false).players[2];
    ok('投影里 +1 坐骑在', !!sp.equips.mountUp && sp.equips.mountUp.name === up.name);
    ok('投影里 −1 坐骑也在', !!sp.equips.mountDown && sp.equips.mountDown.name === down.name);

    // 装第二匹 +1 —— 只该顶掉第一匹 +1
    var another = g.deck.filter(function (c) {
      return D.CARDS[c.name].slot === 'mountUp' && c !== up;
    })[0];
    var beforeDown = p.equips.mountDown;
    p.equips[another.slot] = another;
    ok('装第二匹 +1 会顶掉第一匹 +1', p.equips.mountUp === another);
    ok('装第二匹 +1 **不会**碰掉 −1 坐骑', p.equips.mountDown === beforeDown);

    // 距离：+1 作用是"别人看你更远"，−1 是"你看别人更近" ——
    // 所以两个修正要在**两个人身上**才看得出各算了一次
    var a = g.players[0], b = g.players[2];
    a.equips.mountDown = null; b.equips.mountUp = null; b.equips.mountDown = null;
    var base = E.distance(a, b);
    b.equips.mountUp = up;
    ok('b 骑 +1 → a 看 b 的距离 +1', E.distance(a, b) === base + 1,
       E.distance(a, b) + ' vs ' + base);
    a.equips.mountDown = down;
    ok('a 再骑 −1 → 距离又减回来（两个修正各算一次，互不顶替）',
       E.distance(a, b) === base, E.distance(a, b) + ' vs ' + base);

    // 界面：装备区要把四格都画出来（漏一格就是"牌装上了但看不见"）
    b.equips.mountUp = up; b.equips.mountDown = down;
    b.equips.weapon = g.deck.filter(function (c) { return D.CARDS[c.name].slot === 'weapon'; })[0];
    b.equips.armor  = g.deck.filter(function (c) { return D.CARDS[c.name].slot === 'armor'; })[0];
    UI.render();
    var chips = document.querySelectorAll('#opponents .player-panel[data-seat="2"] .gear-chip');
    ok('装备区把四格都渲染出来了（武器 / 防具 / +1 坐骑 / −1 坐骑）',
       chips.length === 4, chips.length);
  });

  /* ---------------------------------------------------------
   *  6g. 赛后评分与 MVP
   * --------------------------------------------------------- */
  group('赛后评分与 MVP', function () {
    var g = freshGame(5);
    g.players[0].identity = 'student';
    g.players[1].identity = 'staff';
    g.players[2].identity = 'staff';
    g.players[3].identity = 'dean';
    g.players[4].identity = 'mole';
    g.players.forEach(function (p) { p.alive = true; });
    // 造一份可预期的统计
    g.stats = {
      0: { dmg:8,  kills:2, saves:1, heals:0, skills:3 },
      1: { dmg:2,  kills:0, saves:0, heals:5, skills:1 },
      2: { dmg:0,  kills:0, saves:0, heals:0, skills:0 },
      3: { dmg:0,  kills:0, saves:0, heals:0, skills:0 },
      4: { dmg:0,  kills:0, saves:0, heals:0, skills:0 }
    };

    var b = E.buildScoreboard('student');
    var r0 = b.rows[0], r1 = b.rows[1], r2 = b.rows[2];

    // 0 号位（学生，赢）：30 + 伤害8×3 + 击杀2×15 + 救援12 + 技能3×2 + 存活8
    ok('胜利方的分数 = 30 + 24 + 30 + 12 + 6 + 8 = 110', r0.score === 110, r0.score);
    ok('输了但活着的：只拿到存活分 8', r2.score === 8, r2.score);
    ok('没造成任何伤害的人分数很低（不是人人有奖）', r1.score < r0.score);
    ok('MVP 是分最高的 0 号位', b.mvpSeat === 0, b.mvpSeat);

    // 关键设计：打得漂亮但输掉的人，应该能压过躺赢的人
    g.stats[1] = { dmg:20, kills:3, saves:0, heals:0, skills:5 };
    var b2 = E.buildScoreboard('student');
    ok('输了但打出 20 伤害 3 击杀的教务 = 60 + 45 + 10 + 8 = 123',
       b2.rows[1].score === 123, b2.rows[1].score);
    ok('所以他拿到了 MVP，而不是躺赢的 0 号位（110）',
       b2.mvpSeat === 1, b2.mvpSeat);

    // 技能分封顶
    g.stats[0] = { dmg:0, kills:0, saves:0, heals:0, skills:999 };
    var b3 = E.buildScoreboard(null);
    var sk = b3.rows[0].parts.filter(function (p) { return p.label === '发动技能'; })[0];
    ok('技能分封顶 20（刷 999 次也没用）', sk && sk.v === 20, JSON.stringify(sk));
    ok('平局给 10 分底分', b3.rows[0].parts.some(function (p) { return p.label === '平局' && p.v === 10; }));

    // 一分没得就不评 MVP。
    // 注意：只要有人赢了就有 30 分，"全员 0 分"必须让赢的那个阵营**没人**才对
    g.stats = {};
    g.players.forEach(function (p) { p.alive = false; p.identity = 'student'; });
    var b4 = E.buildScoreboard('mole');            // 场上没有卧底 → 谁都不加分
    ok('全都没分时不硬评 MVP', b4.mvpSeat === -1, b4.mvpSeat);
  });

  group('评分埋点真的在记', function () {
    var g = freshGame(4);
    var a = g.players[0], b = g.players[1];
    // 别在这里改 b.char —— freshGame 已经按座位发了不重复的武将，
    // 再手动指定会撞成重复角色，把后面「当前对局角色不重复」那条自检搞红
    b.maxHp = 6; b.hp = 6;
    ok('开局统计是清零的', (g.stats[0] || {}).dmg === undefined || g.stats[0].dmg === 0);
    return E.damage(b, 2, a, 'normal').then(function () {
      ok('造成伤害会记进评分', g.stats[0] && g.stats[0].dmg === 2, JSON.stringify(g.stats[0]));
      return E.heal(b, 1, '测试', a);
    }).then(function () {
      ok('治疗他人会记进评分', g.stats[0] && g.stats[0].heals === 1, JSON.stringify(g.stats[0]));
      // 自己治疗自己不算贡献
      var before = g.stats[0].heals;
      return E.heal(a, 1, '测试', a).then(function () {
        ok('自己治疗自己不算贡献', g.stats[0].heals === before, g.stats[0].heals);
      });
    });
  });

  /* ---------------------------------------------------------
   *  6h. 电脑强度三档
   * --------------------------------------------------------- */
  group('电脑强度：参数与不变量', function () {
    var AI = window.AI;
    ok('默认是普通档', AI.getLevel() === 'normal', AI.getLevel());
    ok('三档都在', !!AI.LEVELS.easy && !!AI.LEVELS.normal && !!AI.LEVELS.hard);
    ok('噪声递减：简单 > 普通 > 困难',
       AI.LEVELS.easy.noise > AI.LEVELS.normal.noise &&
       AI.LEVELS.normal.noise > AI.LEVELS.hard.noise,
       [AI.LEVELS.easy.noise, AI.LEVELS.normal.noise, AI.LEVELS.hard.noise].join('>'));
    ok('困难档不失误（mistake / blunder 都为 0）',
       AI.LEVELS.hard.mistake === 0 && AI.LEVELS.hard.blunder === 0);
    ok('简单档失误率明显更高',
       AI.LEVELS.easy.mistake > AI.LEVELS.normal.mistake &&
       AI.LEVELS.easy.blunder > AI.LEVELS.normal.blunder);

    var g = freshGame(5);
    g.players[0].identity = 'student';
    g.players[1].identity = 'dean';
    g.players[2].identity = 'staff';
    g.players[3].identity = 'student';

    // 「不打自己人」是基本能力，不该随难度变化
    ['easy', 'normal', 'hard'].forEach(function (k) {
      AI.setLevel(k);
      ok('（' + k + '档）院方都不会打公开的院长',
         AI.threat(g.players[2], g.players[1]) <= -60, AI.threat(g.players[2], g.players[1]));
    });

    // 身份推断强度随难度变化
    AI.setLevel('easy');
    var easyTh = AI.threat(g.players[0], g.players[1]);   // 学生看院长
    AI.setLevel('hard');
    var hardTh = AI.threat(g.players[0], g.players[1]);
    ok('困难档对院长的仇恨值 >= 简单档', hardTh >= easyTh, easyTh + ' vs ' + hardTh);
    ok('简单档确实削弱了身份推断（而不是原样）', easyTh < hardTh, easyTh + ' vs ' + hardTh);

    AI.setLevel('normal');
  });

  group('电脑强度：行为上真的不一样', function () {
    var AI = window.AI;
    var g = freshGame(5);
    g.players[0].identity = 'student';
    g.players[1].identity = 'dean';      // 学生最该打的
    g.players[2].identity = 'staff';
    g.players[3].identity = 'mole';
    g.players[4].identity = 'student';
    var cands = [g.players[1], g.players[2], g.players[3], g.players[4]];

    // 统计「最常打的那个人占比」——困难档应该更集中（会集火），简单档更分散
    function focus(level, rounds){
      AI.setLevel(level);
      var cnt = {};
      for (var i = 0; i < rounds; i++){
        var t = AI.pickTarget(g.players[0], cands);
        if (t) cnt[t.seat] = (cnt[t.seat] || 0) + 1;
      }
      var top = null;
      Object.keys(cnt).forEach(function (k){ if (top === null || cnt[k] > cnt[top]) top = k; });
      return { seat: top === null ? -1 : +top, share: top === null ? 0 : cnt[top] / rounds };
    }
    var easy = focus('easy', 400);
    var hard = focus('hard', 400);

    ok('困难档更集中地打同一个人（会集火）', hard.share > easy.share,
       '简单 ' + (easy.share * 100).toFixed(0) + '% vs 困难 ' + (hard.share * 100).toFixed(0) + '%');
    ok('困难档最常打的是院长（身份推断生效）', hard.seat === 1, hard.seat);

    AI.setLevel('normal');
  });

  group('三档都能打完一整局', function () {
    var AI = window.AI;
    var chain = Promise.resolve();
    ['easy', 'normal', 'hard'].forEach(function (k) {
      chain = chain.then(function () {
        AI.setLevel(k);
        E.initGame({ count: 5, mode:'A', deal:3, hotseat:false, humanSeats:[0] });
        var g = window.G;
        g.players.forEach(function (p, i) { p.char = D.CHARACTERS[i]; });
        E.finalizeRoles(); E.finalizeGame();
        g.speed = 0.01;
        g.players.forEach(function (p) { p.isHuman = false; });
        g.players.forEach(function (p) {
          for (var i = 0; i < 4; i++) { var c = g.deck.pop(); if (c) p.hand.push(c); }
        });
        return E.gameLoop().then(function () {
          ok('「' + AI.LEVELS[k].name + '」档能打完一整局', g.over === true);
        });
      });
    });
    chain = chain.then(function () { AI.setLevel('normal'); });
    return chain;
  });

  /* ---------------------------------------------------------
   *  6i. 新手教学局
   * --------------------------------------------------------- */
  group('新手教学局', function () {
    var T = window.Tutorial;
    ok('教学模块加载了', !!T && typeof T.start === 'function');

    T.start();
    var g = window.G;
    ok('教学局是 4 人局（最短的完整对局）', g.players.length === 4, g.players.length);
    ok('玩家被固定成学生', g.players[g.humanSeat].identity === 'student',
       g.players[g.humanSeat].identity);
    ok('身份人数配置没被换坏（4 人局各 1）', (function () {
      var c = {};
      g.players.forEach(function (p) { c[p.identity] = (c[p.identity] || 0) + 1; });
      var cfg = D.IDENTITY_CONFIG[4];
      return c.dean === cfg.dean && c.staff === cfg.staff &&
             c.student === cfg.student && c.mole === cfg.mole;
    })());
    ok('院长身份仍然公开',
       g.players.filter(function (p) { return p.identity === 'dean'; })[0].revealed === true);
    ok('起手牌被换成教学用的四张',
       g.players[0].hand.length === 4 &&
       ['上课点名','代课','请假条','借笔记'].every(function (n) {
         return g.players[0].hand.some(function (c) { return c.name === n; });
       }),
       g.players[0].hand.map(function (c) { return c.name; }).join(','));
    ok('电脑被切成简单档（不会精准集火秒了新手）', window.AI.getLevel() === 'easy', window.AI.getLevel());
    ok('保护轮开着', g.opts.protect === true);
    ok('提示条弹出了第一条', !document.getElementById('tutorial-bar').classList.contains('hide'));

    // 提示按条件触发，且每条只弹一次。
    // 注意：第一条（开场白）没有 when，所以任何 notify 都会先把它弹掉 ——
    // 正式流程里 T.start() 会先发一次 notify('start') 把它消费掉。
    T.seen = {};
    T.notify('targeting', {});
    ok('第一条（开场白）会被弹掉', T.seen.open === true,
       Object.keys(T.seen).join(','));
    T.notify('targeting', {});
    ok('接着弹出匹配 targeting 的那条', T.seen.target === true,
       Object.keys(T.seen).join(','));
    var n = Object.keys(T.seen).length;
    T.notify('targeting', {});
    T.notify('targeting', {});
    ok('已经弹过的提示不会再弹（也没有别的匹配项）',
       Object.keys(T.seen).length === n, Object.keys(T.seen).join(','));

    T.stop();
    ok('退出教学后提示条收起', document.getElementById('tutorial-bar').classList.contains('hide'));
    ok('退出教学后电脑强度还原', window.AI.getLevel() === 'normal', window.AI.getLevel());
    ok('退出教学后 active 关掉', T.active === false);
  });

  /* ---------------------------------------------------------
   *  6i-2. 教学提示 vs 真实引擎生成的询问
   *
   *  上面的用例只手工喂了一次 notify('targeting')。可真正教东西的几条
   *  （出牌阶段 / 弃牌 / 濒死 / 代课）是靠正则去认引擎写的提示语的 ——
   *  引擎里换一个词，提示就**静默**不弹了，玩家那边看不出任何异常。
   *  所以这里让引擎自己发询问，看教学认不认得出来。
   * --------------------------------------------------------- */
  group('教学提示接的是真实引擎的询问', function () {
    var T = window.Tutorial;
    var fired = [];
    var calls = [];               // 引擎到底发了哪些询问（失败时拿它定位）
    var realNotify = T.notify;
    var realAsk = window.UI.askHuman;

    // 提示是在 UI.askHuman 里发出去的，而真的 askHuman 会弹窗等人点 ——
    // 无头环境会永远卡在第一个出牌阶段。换成"照常发提示 + 交给 AI 决策"：
    // 于是引擎把**它自己生成的 req** 喂进教学里，
    // 验的是真实提示语，而不是我在测试里手抄一份字符串（那只证明我抄对了）。
    window.UI.askHuman = function (req){
      T.notify('ask', { req: req });
      return window.AI.decide(req);
    };
    T.notify = function (type, payload){
      var before = Object.keys(T.seen);
      var req = payload && payload.req;
      calls.push(type + (req ? ':' + req.kind : ''));
      realNotify.call(T, type, payload);
      Object.keys(T.seen).forEach(function (k){
        if (before.indexOf(k) < 0 && fired.indexOf(k) < 0) fired.push(k);
      });
    };

    var done = T.start();          // 返回整局的 Promise
    window.G.speed = 0.01;         // 别真等 AI 那 560ms 的"思考时间"

    // 兜底：万一这局打不完（比如以后改了平衡性变成僵局），别把整个测试挂死。
    // 强制结束也会走 UI.showOver，所以 over 那条照样会被验到。
    var guard = new Promise(function (res){
      setTimeout(function (){
        if (!window.G.over) window.Engine.endGame('dean', '测试兜底结束');
        res();
      }, 60000);
    });

    return Promise.race([Promise.resolve(done), guard]).then(function (){
      var over = window.G.over;
      T.stop();
      T.notify = realNotify;
      window.UI.askHuman = realAsk;
      // 一局结束必须走 endGame —— 它会写 G.scoreboard 并弹结算界面。
      // 引擎里有几条路径是"先写 G.over 再调 checkVictory/endGame"，
      // 而那两个函数开头都有 `if (G.over) return`：结果是棋局停在那里，
      // 既没有结算也没有结束提示。这一条就是拿来堵那个的。
      var endLog = window.G.log.filter(function (e){ return /^游戏结束/.test(e.text); })[0];
      var diag = 'round=' + window.G.round + ' fired=[' + fired.join(',') + '] over=' + over +
                 ' end=' + (endLog ? endLog.text : '(没走 endGame)') +
                 ' calls=[' + calls.slice(0, 20).join(' ') + ']';
      ok('出牌阶段的提示弹了（认得出引擎发的 playPhase）',
         fired.indexOf('hand') >= 0, diag);
      ok('游戏结束的提示弹了', fired.indexOf('over') >= 0, diag);
      ok('结束时真的弹了结算（不是停在那儿不动）',
         !!endLog && endLog.text.indexOf('测试兜底结束') < 0, diag);
      ok('每条提示最多弹一次', Object.keys(T.seen).length === fired.length,
         'seen=' + Object.keys(T.seen).join(',') + ' fired=' + fired.join(','));
      ok('教学局能真的打到底（4 人局不会僵住）', over === true);
    });
  });

  /* ---------------------------------------------------------
   *  6j. 复盘导出（分享版 HTML）
   * --------------------------------------------------------- */
  group('复盘导出：分享版 HTML', function () {
    var Net = window.Net;
    ok('导出接口在', typeof Net.buildReplayHtml === 'function' &&
                     typeof Net.exportReplayHtml === 'function');

    // 没录像时应该拒绝，而不是导出个空文件
    var keep = Net.rec;
    Net.rec = null;
    return Net.buildReplayHtml().then(
      function (){ ok('没录像时拒绝导出', false, '居然生成了'); },
      function (e){ ok('没录像时拒绝导出', /还没录到/.test(e.message), e.message); }
    ).then(function () {
      // 有录像：真生成一遍，把内容逐条验掉。
      // （测试跑在 --allow-file-access-from-files 下，所以 file:// 也读得到源码；
      //   用户直接双击打开时读不到，那条路径会给出可读的错误提示。）
      Net.rec = { v:1, type:'dqk-replay', seat:0, seatCount:4,
                  frames: new Array(40).fill({ t: 0 }) };
      Net.recLive = false;
      ok('这段录像被认为有效', Net.hasReplay() === true);
      return Net.buildReplayHtml().then(function (html){
        ok('能生成分享版 HTML', typeof html === 'string' && html.length > 100000,
           html && html.length);
        ok('有 DOCTYPE', html.indexOf('<!DOCTYPE html>') === 0);
        ok('带了复盘数据', html.indexOf('id="replay-data"') > 0);
        // 骨架完整度（#board / #sidebar / 复盘条的按钮）在 export_probe 里验 ——
        // 那个探针取的是真实 index.html 的 DOM，本测试页的 DOM 是简化的
        ok('带了游戏骨架', html.indexOf('id="screen-game"') > 0);
        ok('内联了 data / engine / ui / net',
           html.indexOf('===== data.js =====') > 0 &&
           html.indexOf('===== engine.js =====') > 0 &&
           html.indexOf('===== ui.js =====') > 0 &&
           html.indexOf('===== net.js =====') > 0);
        ok('没把 main.js 塞进去（否则打开会自己开一局）',
           html.indexOf('===== main.js =====') < 0);
        // 最关键的一条：内联的源码里不能有裸的脚本结束标签。
        // 有的话整块 JS 会因为语法不完整而**完全不执行**，表现是打开白屏。
        // 8 个真标签 → split 出 9 段。
        ok('内联源码里没有裸的脚本结束标签（白屏元凶）',
           html.split('</scr' + 'ipt').length === 9, html.split('</scr' + 'ipt').length);
        ok('复盘数据里的 < 都转义了',
           html.indexOf('id="replay-data">') > 0 && html.indexOf('<\\u003c') < 0);
      }, function (e){
        ok('能生成分享版 HTML', false, e.message);
      });
    }).then(function () { Net.rec = keep; });
  });

  /* ---------------------------------------------------------
   *  7. 既有引擎自检（回归闸门）
   * --------------------------------------------------------- */
  group('回归', function () {
    if (typeof window.runSelfTest !== 'function') { fail('找不到 runSelfTest'); return; }
    var r = window.runSelfTest();
    // 注意：自检的结果项用的是 {name, pass, extra}，不是 {ok, detail} ——
    // 写错字段名会把**全部**检查名都当失败打出来，把真正的失败项淹掉
    ok('引擎自检全过（total=' + r.total + ', failed=' + r.failed + '）',
       r.failed === 0,
       r.results.filter(function (x) { return !x.pass; })
                .map(function (x) { return x.name + (x.extra ? '（' + x.extra + '）' : ''); })
                .join(' | '));
  });

  /* ---------------------------------------------------------
   *  输出（等所有异步组跑完）
   * --------------------------------------------------------- */
  function finish() {
    var bad = out.filter(function (o) { return !o.ok; });
    var lines = [];
    out.forEach(function (o) {
      lines.push((o.ok ? '[ok]   ' : '[FAIL] ') + o.name + ((!o.ok && o.detail) ? '  <- ' + o.detail : ''));
    });
    lines.push('');
    lines.push('JS-TOTAL ' + out.length + ' JS-FAILED ' + bad.length);
    var text = lines.join('\n');
    document.getElementById('RESULTS').textContent = text;

    // 带 ?sink=<地址> 时把结果回传给 tools/result_sink.py。
    // （比 --dump-dom 可靠：自测里有长轮询，挂起的 fetch 会让 Chromium 的
    //   虚拟时钟暂停，--virtual-time-budget 就永远不触发。）
    var sink = null;
    try { sink = new URLSearchParams(location.search).get('sink'); } catch (e) { /* 老浏览器 */ }
    if (sink) {
      try {
        fetch(sink, { method: 'POST', headers: { 'Content-Type': 'text/plain' }, body: text })
          .catch(function () {});
      } catch (e) { /* 忽略 */ }
    }
  }

  runAll();
})();
