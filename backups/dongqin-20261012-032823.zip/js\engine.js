/* =========================================================
 *  东秦杀：点名册  ·  规则引擎
 *  实现规则书 v1.0：六阶段回合 / 距离与攻击范围 / 装备 /
 *  判定（查考勤）/ 濒死救援 / 死亡奖惩 / 身份胜负 / 40 个技能
 * ========================================================= */
(function(){
'use strict';

const D = window.GameData;
const { CARDS, IDENTITIES, PROBE_CARDS } = D;

/* ---------------- 全局状态 ---------------- */
const G = {
  players: [], deck: [], discard: [], turnSeat: 0, round: 1, turnId: 0,
  phase: '', over: false, humanSeat: 0, opts: {}, log: [], startSeat: 0,
  speed: 1.35, firstRound: true, roundDone: new Set(), harmLog: [],
  format: 'identity',          // 'identity' | 'landlord' | 'team2v2'
  packs: {},                   // 启用的角色拓展包
  roster: []                   // 本局武将名单（基础 + 启用的拓展包）
};
window.G = G;

/* =========================================================
 *  对局形式（format）
 * =========================================================
 * 三种形式共用同一套规则引擎，差异**全部收在这张表里**。
 *
 *   规矩：`G.format` 只允许在这张表和它下面的 fmt() 里被读到。
 *   ui.js / net.js / main.js / ai.js 一律不准直接读，只能调 E.sideInfo /
 *   E.sideLabel / E.winOf 这些导出函数。这条纪律是"三种形式共用一套规则"
 *   不腐烂的唯一保证 —— 一旦有人在自己文件里写 `if (G.format === ...)`，
 *   分支就会开始到处长。
 *
 *  身份局的内容是**今天代码的逐行搬运**，行为逐字节不变。
 */
function identityVictory(){
  const alive = alivePlayers();
  const dean = G.players.find(p => p.identity === 'dean');
  if (!dean){ endGame(null, '场上没有院长'); return; }   // 旧代码这里会直接抛异常
  const students = G.players.filter(p => p.identity === 'student');
  const moles = G.players.filter(p => p.identity === 'mole');
  if (alive.length === 0){ endGame(null, '全员阵亡'); return; }
  if (!dean.alive){
    if (alive.length === 1 && alive[0].identity === 'mole'){ endGame('mole', '院长死亡且卧底成为唯一存活者'); return; }
    endGame('student', '院长死亡');
    return;
  }
  const bad = students.concat(moles).filter(p => p.alive);
  if (bad.length === 0){ endGame('dean', '学生与卧底全部出局，院长存活'); return; }
}
function identityKillReward(source, victim){
  if (victim.identity === 'student'){
    log(source.name + ' 击杀学生，摸 3 张牌（奖惩）', 'sys');
    return drawCards(source, 3, '击杀学生');
  }
  if (victim.identity === 'staff' && source.identity === 'dean'){
    log(source.name + ' 误杀教务，弃置所有手牌与装备区的牌（奖惩）', 'dmg');
    const all = source.hand.splice(0).concat(
      D.EQUIP_SLOTS.map(k => { const c = source.equips[k]; source.equips[k] = null; return c; }).filter(Boolean));
    toDiscard(all);
    return Promise.resolve();
  }
  if (victim.identity === 'mole' && G.opts.moleReward) return drawCards(source, 1, '击杀卧底（可选奖励）');
  return Promise.resolve();
}

/* ---------------- 2V2 ---------------- */
function team2v2Victory(){
  const a = G.players.filter(p => p.side === 'A' && p.alive).length;
  const b = G.players.filter(p => p.side === 'B' && p.alive).length;
  if (a === 0 && b === 0){ endGame(null, '两队同归于尽'); return; }
  if (a === 0){ endGame('B', '红队全员出局'); return; }
  if (b === 0){ endGame('A', '蓝队全员出局'); return; }
}
/** 1、4 号位一队（红），2、3 号位一队（蓝）—— 交错坐，左右都是敌人 */
function team2v2Setup(){
  G.players.forEach((p, i) => { p.side = (i === 0 || i === 3) ? 'A' : 'B'; });
}

/* ---------------- 斗地主 ---------------- */
function landlordVictory(){
  const ll = G.players.filter(p => p.side === 'landlord' && p.alive).length;
  const fm = G.players.filter(p => p.side === 'farmer' && p.alive).length;
  if (ll === 0 && fm === 0){ endGame(null, '全员阵亡'); return; }
  if (ll === 0){ endGame('farmer', '地主阵亡'); return; }
  if (fm === 0){ endGame('landlord', '两个农民都出局了'); return; }
}

/* 地主的两个专属技能。它们**不属于任何角色** —— 硬塞进 char.skills 会撞上
 * selftest 的"角色牌不含阵营字段"那条，也会让 20 个角色凭空多出技能。
 * 走的是 p.extraSkills 这条路（hasSkill 里加了支路）。 */
const SIDE_SKILLS = {
  飞扬: { name:'飞扬', type:'身份技·主动',
          text:'查考勤阶段开始时，你可以弃置两张牌，然后弃置你通知栏里的所有牌。' },
  跋扈: { name:'跋扈', type:'身份技·锁定',
          text:'你摸牌阶段多摸一张牌；出牌阶段可以多使用一张点名类牌。' }
};

/* ---------------- 斗地主的叫分 ----------------
 * 开局前的一段交互：按座位顺序每人叫一次（0/1/2/3），必须高于当前最高分，
 * 叫满 3 分立即定地主，全不叫则由首位玩家当地主。
 * 状态放在 G.bid 里（可序列化），主客机都靠这三个函数推进。 */
function bidNext(){
  if (!G.bid) G.bid = { order: G.players.map(p => p.seat), best: 0, bestSeat: -1, done: {} };
  const b = G.bid;
  for (const s of b.order){
    if (b.done[s] === undefined) return s;
  }
  return -1;
}
/** 提交一个座位的叫分（0 = 不叫）。不合法（不高于当前最高分）按"不叫"处理 */
function bidSubmit(seat, score){
  const b = G.bid;
  if (!b) return;
  score = Math.max(0, Math.min(3, score | 0));
  if (score > 0 && score <= b.best) score = 0;
  b.done[seat] = score;
  if (score > b.best){ b.best = score; b.bestSeat = seat; }
  // 叫到 3 分直接定局 —— 后面的人不用再叫了
  if (score === 3) b.order.forEach(s => { if (b.done[s] === undefined) b.done[s] = 0; });
}
/** 叫分收尾：定地主、写阵营、重发候选。返回地主座位 */
function bidFinish(){
  const b = G.bid;
  const seat = b.bestSeat >= 0 ? b.bestSeat : b.order[0];
  // 全不叫时按**底分 1** 算 —— 否则"地主胜 = 叫分×2"会直接是 0 分
  G.bidScore = b.best > 0 ? b.best : 1;
  G.bidDone = true;
  G.players.forEach(p => { p.side = (p.seat === seat) ? 'landlord' : 'farmer'; });
  logBig('叫分结束：' + (seat + 1) + ' 号位当地主（' + G.bidScore + ' 分）');
  redealForLandlord();
  return seat;
}
/**
 * 叫分结束后**重发候选**：地主 5 张、农民各 3 张。
 * initGame 里发的那一轮是在还不知道谁是地主的时候发的，只能作废。
 */
function redealForLandlord(){
  const pool = shuffle(G.roster.slice());
  G.dealPer = 3;
  for (const p of G.players){
    if (!p.isHuman){ p.charChoices = []; continue; }
    const n = (p.side === 'landlord') ? 5 : 3;
    p.charChoices = pool.splice(0, Math.min(n, pool.length));
    G.dealPer = Math.max(G.dealPer, p.charChoices.length);
  }
  G.charRest = pool;
}

/* ---------------- 2V2 的禁选 ----------------
 * 简化版剧本：四个座位各禁一名武将，禁掉的从本局名单里剔除，然后重新发候选。
 * （完整版 —— 展示候选池 → 两队交替禁用 4 名 → 选入备选池 → 每队选 2 名登场 ——
 *   以后只替换这三个函数即可：上层只认"谁该禁、禁了什么"，不认具体剧本。）
 * 状态放在 G.ban 里，可序列化。 */
function banNext(){
  if (!G.ban) G.ban = { order: G.players.map(p => p.seat), done: {} };
  for (const s of G.ban.order) if (G.ban.done[s] === undefined) return s;
  return -1;
}
function banSubmit(seat, charId){
  const b = G.ban;
  if (!b || b.done[seat] !== undefined) return;
  b.done[seat] = charId || null;
  if (charId && G.bannedIds.indexOf(charId) < 0) G.bannedIds.push(charId);
}
function banFinish(){
  G.banDone = true;
  const names = G.bannedIds.map(id => {
    const c = D.allCharacters().filter(x => x.id === id)[0];
    return c ? c.name : id;
  });
  logBig(names.length ? '禁用：' + names.join('、') : '没人禁用武将');
  redealAfterBan();
}
/** 禁选之后重发候选（禁掉的武将不再出现） */
function redealAfterBan(){
  const pool = shuffle(G.roster.filter(c => G.bannedIds.indexOf(c.id) < 0));
  G.dealPer = 3;
  for (const p of G.players){
    if (!p.isHuman){ p.charChoices = []; continue; }
    p.charChoices = pool.splice(0, Math.min(3, pool.length));
    G.dealPer = Math.max(G.dealPer, p.charChoices.length);
  }
  G.charRest = pool;
}

const FORMAT = {
  identity: {
    key: 'identity', label: '身份局',
    seats: null,                                        // null = 人数由玩家选（4–8）
    identityConfig: n => D.IDENTITY_CONFIG[n] || D.IDENTITY_CONFIG[5],
    // 院长先手；没有院长时退回 0 号位（旧代码在这里会抛异常）
    firstSeat: () => { const d = G.players.find(p => p.identity === 'dean'); return d ? d.seat : 0; },
    hpBonus: p => (p.identity === 'dean' ? 1 : 0),
    handSize: p => 4 + (p.identity === 'dean' ? 1 : 0)
                    + ((G.players.length === 4 && p.identity === 'student') ? 1 : 0),
    victory: identityVictory,
    killReward: identityKillReward,
    sideOf: p => p.identity,
    sideName: k => (D.IDENTITIES[k] ? D.IDENTITIES[k].name : '？'),
    sideCls: k => (D.IDENTITIES[k] ? D.IDENTITIES[k].cls : ''),
    // 角色面板角标用的是**另一套**类名（dean / revealed-xxx），
    // 和顶栏 .bid 用的 id.cls 不是一回事，别合并
    sideTagCls: p => p.identity ? ((p.identity === 'dean') ? 'dean' : ('revealed-' + p.identity)) : 'hidden',
    goal: k => (D.IDENTITIES[k] ? D.IDENTITIES[k].win : ''),
    visible: p => !!(p.revealed || p.identity === 'dean'),
    winOf: (w, p) => (w === 'dean' ? (p.identity === 'dean' || p.identity === 'staff') : (p.identity === w)),
    drawCount: (p, base) => base,
    setup: null
  },
  /* ---------------- 2V2 竞技 ----------------
   * 无身份，红蓝两队各 2 人，队友明置；一方两人全灭即负。
   * 座位交错（1&4 红、2&3 蓝），所以每个人左右都是敌人。
   * 目标单局 5 分钟 —— 起手与先手补偿见 handSize / drawCount。 */
  team2v2: {
    key: 'team2v2', label: '2V2',
    seats: 4,                                             // 固定 4 人，人数不给选
    identityConfig: () => null,
    firstSeat: () => 0,                                   // 1 号位先手
    hpBonus: () => 0,
    // 1 号位 4 张但第一回合只摸 1 张；4 号位起手 5 张 —— 两头补偿，中间两人 4 张
    handSize: p => (p.seat === 3 ? 5 : 4),
    victory: team2v2Victory,
    killReward: () => Promise.resolve(),                  // 杀死队友不弃牌，杀死敌人也没奖励
    sideOf: p => p.side,
    sideName: k => (k === 'A' ? '红队' : k === 'B' ? '蓝队' : '？'),
    sideCls: k => (k === 'A' ? 'team-a' : k === 'B' ? 'team-b' : ''),
    // 复用身份局那两套角标配色（红队像学生、蓝队像教务），省一套 CSS
    sideTagCls: p => (p.side === 'A' ? 'revealed-student'
                    : p.side === 'B' ? 'revealed-staff' : 'hidden'),
    goal: k => (k === 'A' ? '击败蓝队两人' : k === 'B' ? '击败红队两人' : ''),
    visible: () => true,                                  // 队友明置 = 全员阵营公开
    winOf: (w, p) => p.side === w,
    drawCount: (p, base) => (G.turnId === 1 && p.seat === 0) ? 1 : base,
    setup: team2v2Setup
  },
  /* ---------------- 斗地主 ----------------
   * 1 个地主 vs 2 个农民。地主多 1 点体力上限、多两个专属技能、
   * 起手 4 张 + 3 张底牌；先行动的农民 4 张，后行动的农民 5 张。
   * 阵营由开局前的**叫分**决定（见 landlordBid），不是 initGame 里定的。 */
  landlord: {
    key: 'landlord', label: '斗地主',
    seats: 3,
    identityConfig: () => null,
    // 地主先手。叫分还没走完时没有地主 → 退回 0 号位（不会崩）
    firstSeat: () => {
      const ll = G.players.filter(p => p.side === 'landlord')[0];
      return ll ? ll.seat : 0;
    },
    hpBonus: p => (p.side === 'landlord' ? 1 : 0),
    // 地主 4 张 + 底牌 3 张（底牌不公开）；先行动的农民 4 张，后行动的 5 张
    handSize: p => {
      if (p.side === 'landlord') return 7;
      const fm = G.players.filter(x => x.side === 'farmer').sort((a, b) => a.seat - b.seat);
      return (fm.length > 1 && p === fm[fm.length - 1]) ? 5 : 4;
    },
    victory: landlordVictory,
    killReward: () => Promise.resolve(),      // 地主和农民之间没有身份奖惩
    sideOf: p => p.side,
    sideName: k => (k === 'landlord' ? '地主' : k === 'farmer' ? '农民' : '？'),
    sideCls: k => (k === 'landlord' ? 'dean' : k === 'farmer' ? 'student' : ''),
    sideTagCls: p => (p.side === 'landlord' ? 'dean' : p.side === 'farmer' ? 'revealed-student' : 'hidden'),
    goal: k => (k === 'landlord' ? '击败两个农民' : '击败地主'),
    visible: () => true,                      // 叫分一结束，地主是谁全场都知道
    winOf: (w, p) => p.side === w,
    // 跋扈让地主多摸一张
    drawCount: (p, base) => base + (hasSkill(p, '跋扈') ? 1 : 0),
    setup: null                               // 阵营由叫分决定，见 landlordBid
  }
};
/** 当前形式的实现表。G.format 没设（旧存档/测试）时按身份局走。 */
function fmt(){ return FORMAT[G.format] || FORMAT.identity; }

/* ---------------- 工具 ---------------- */
function sleep(ms){ return new Promise(r => setTimeout(r, Math.max(0, ms * (G.speed||1)))); }
/**
 * 记一条日志。
 *
 * 单机/热座时所有人的眼睛都在同一块屏幕上，所以日志本来就是"大家都看得见"的。
 * 但联机之后日志会发给每个客户端，而有些日志**内容本身就是隐藏信息**
 * （【窃听】【查寝】会把目标手牌逐张打出来），那就等于把规则击穿了。
 *
 * 所以这类日志要用 only 指定"只有哪些座位能看到原文"，其他人看到 redacted。
 * 投影时由 net.js 的 project() 按接收者替换。
 */
function log(text, cls, only, redacted){
  const entry = { text, cls };
  if (only && only.length){
    entry.only = only;
    entry.redacted = redacted || '（内容仅当事人可见）';
  }
  G.log.push(entry);
  if (window.UI && UI.pushLog) UI.pushLog(text, cls);
  // 技能语音：全项目每个技能生效时都会留一条带技能名的日志，
  // 所以在这里嗅探一次就够 —— 不用在 70 多个技能实现里各插一行（见 fx.js）
  if (window.FX && FX.saySkillFromLog) FX.saySkillFromLog(text);
}
function logBig(t){ log(t, 'big'); }

/* ---------------- 赛后评分用的埋点 ----------------
 * 只记"做的事"，不记身份 —— 评分和 MVP 要奖励打得好的人，
 * 而不是"抽到好身份的人"。 */
function noteStat(seat, key, n){
  if (!G.stats) G.stats = {};
  const s = G.stats[seat] || (G.stats[seat] = { dmg:0, kills:0, saves:0, heals:0, skills:0 });
  s[key] = (s[key] || 0) + (n === undefined ? 1 : n);
}
function statOf(seat){
  return (G.stats && G.stats[seat]) || { dmg:0, kills:0, saves:0, heals:0, skills:0 };
}
function toast(t, cls){ if (window.UI && UI.toast) UI.toast(t, cls); }
function rand(n){ return Math.floor(Math.random()*n); }
function shuffle(a){ for (let i=a.length-1;i>0;i--){ const j=rand(i+1); [a[i],a[j]]=[a[j],a[i]]; } return a; }
function pickRandom(a){ return a.length ? a[rand(a.length)] : null; }
function alivePlayers(){ return G.players.filter(p => p.alive); }
function others(p){ return G.players.filter(x => x.alive && x !== p); }

/** 从 seat 开始按座位顺序的存活角色序列 */
function orderFrom(seat){
  const list = [];
  for (let i=0;i<G.players.length;i++){
    const p = G.players[(seat+i) % G.players.length];
    if (p.alive) list.push(p);
  }
  return list;
}
function curTurnPlayer(){ return G.players[G.turnSeat]; }

/* ---------------- 技能判定 ---------------- */
/**
 * 技能判定。全项目唯一的入口（引擎 / UI / AI 共 ~80 处调用）。
 *
 * 第二条支路给**身份技**用（地主的【飞扬】【跋扈】）—— 它们不属于任何角色，
 * 塞进 char.skills 会撞上 selftest 的"角色牌不含阵营字段"，也会让 20 个角色凭空多技能。
 * 身份局里 p.extraSkills 永远是 undefined，所以这条支路对老玩法零影响。
 */
function hasSkill(p, name){
  if (p.char && p.char.skills.some(s => s.name === name)) return true;
  return !!(p.extraSkills && p.extraSkills.indexOf(name) >= 0);
}
function skillUsed(p, name){ return p.skillsUsedThisTurn && p.skillsUsedThisTurn[name]; }
function markSkillUsed(p, name){
  // 同一个技能一回合内可能被标记两次（playPhase 里两份名单有重叠），
  // 提前返回既保证幂等，也避免赛后评分把技能次数算重
  if (p.skillsUsedThisTurn && p.skillsUsedThisTurn[name]) return;
  p.skillsUsedThisTurn[name] = true;
  noteStat(p.seat, 'skills', 1);
}

/* 【炫富】改成**每轮**限一次（原来是每回合一次）。
   弃 1 张牌就能取消任意一张针对你的牌，在多人局里一回合一次太强了。
   用 G.round 打标记 —— skillsUsedThisTurn 是每回合清空的，撑不到"每轮"。 */
function flexReady(p){ return hasSkill(p, '炫富') && p.marks.flexRound !== G.round; }
function markFlex(p){ p.marks.flexRound = G.round; }

/* ---------------- 距离与范围 ---------------- */
function distance(a, b){
  if (a === b) return 0;
  const alive = alivePlayers();
  if (!a.alive || !b.alive) return 99;
  const n = alive.length;
  const ia = alive.indexOf(a), ib = alive.indexOf(b);
  let d = Math.abs(ia - ib);
  d = Math.min(d, n - d);
  if (d < 1) d = 1;
  const bMount = b.equips.mountUp;
  if (bMount && CARDS[bMount.name].mount === '+1') d++;
  if (hasSkill(b, '震慑')) d++;
  const aMount = a.equips.mountDown;
  if (aMount && CARDS[aMount.name].mount === '-1') d--;
  if (hasSkill(a, '观鸟')) d--;
  if (hasSkill(a, '极限')) return 1;   // 最终值锁定
  return Math.max(1, d);
}
function attackRange(p){
  let n = p.equips.weapon ? CARDS[p.equips.weapon.name].range : 1;
  if (hasSkill(p, '全场紧逼')) n++;     // 老湖人：武器之外的范围加成（全项目第一个非武器来源）
  return n;
}
function inAttackRange(a, b){ return distance(a, b) <= attackRange(a); }
function handLimit(p){
  let n = Math.max(0, p.hp);
  if (hasSkill(p, '体能')) n++;      // 波比
  if (hasSkill(p, '持家')) n += 2;   // 李岩
  if (hasSkill(p, '挥金')) n += 2;   // 亨利（代价是受伤 +1，见 damage）
  return n;
}

/* ---------------- 牌堆 ---------------- */
function drawFromDeck(){
  if (G.deck.length === 0){
    if (G.discard.length === 0) return null;
    G.deck = shuffle(G.discard.splice(0));
    log('牌堆用尽，弃牌堆洗入牌堆（' + G.deck.length + ' 张）', 'sys');
    if (G.opts.networkRule){   // 可选规则：网络波动
      const maxHand = Math.max(...alivePlayers().map(p => p.hand.length));
      alivePlayers().filter(p => p.hand.length === maxHand).forEach(p => {
        p.marks.net = (p.marks.net || 0) + 1;
        log(p.name + ' 因网络波动获得【宿舍断网】标记', 'sys');
      });
    }
  }
  return G.deck.pop();
}
function toDiscard(cards){ (Array.isArray(cards) ? cards : [cards]).forEach(c => { if (c) G.discard.push(c); }); }

/** 摸牌（会触发"摸牌后"类技能：董昌程【设局】） */
async function drawCards(p, n, reason){
  const drawn = [];
  for (let i=0;i<n;i++){
    const c = drawFromDeck();
    if (!c) break;
    p.hand.push(c); drawn.push(c);
  }
  if (drawn.length){
    if (window.FX && window.G && G.speed > 0.3) FX.sfx('draw');
    if (window.FX) FX.floatText(p.seat, '+' + drawn.length + ' 张', 'draw');
    log(p.name + ' 摸了 ' + drawn.length + ' 张牌' + (reason ? '（' + reason + '）' : ''), '');
    if (p.isHuman && G.opts.showMyDraws) drawn.forEach(c => toast('摸到：' + cardText(c), ''));
  }
  if (drawn.length){
    await sleep(300);          // 摸牌也留出看清的时间
    await triggerAfterDraw(p);
  }
  return drawn;
}
/** 董昌程【设局】：一名角色摸牌后可令其跳过出牌阶段 */
async function triggerAfterDraw(who){
  for (const p of orderFrom(G.turnSeat)){
    if (!p.alive || p === who) continue;
    if (!hasSkill(p, '设局')) continue;
    if (skillUsed(p, '设局')) continue;
    if (who.skip.play) continue;
    if (p.hand.length < 2) continue;      // 平衡调整：代价从 1 张提到 2 张
    const r = await Ask(p, {
      kind:'choice', prompt:'【设局】' + who.name + ' 刚刚摸了牌，是否弃两张牌令其跳过出牌阶段？',
      options:[{key:'yes', label:'发动（弃两张牌）'}, {key:'no', label:'放弃'}], skillBlock:true
    });
    if (r.option === 'yes'){
      const sel = await Ask(p, { kind:'selectCards', prompt:'【设局】弃置两张牌', from:'self', min:2, max:2 });
      if (sel.cards && sel.cards.length){
        discardFromHand(p, sel.cards);
        markSkillUsed(p, '设局');
        who.skip.play = true;
        log(p.name + ' 发动【设局】，' + who.name + ' 本回合跳过出牌阶段', 'sys');
      }
    }
    break;
  }
}

/* ---------------- 手牌操作 ---------------- */
function removeFromHand(p, cards){
  cards.forEach(c => { const i = p.hand.indexOf(c); if (i >= 0) p.hand.splice(i,1); });
}
function discardFromHand(p, cards){
  removeFromHand(p, cards);
  toDiscard(cards);
  log(p.name + ' 弃置了 ' + cards.map(cardText).join('、'), '');
}
/** 从区域内取牌（手牌随机、装备/通知栏指定） */
function removeFromZone(p, card){
  let i = p.hand.indexOf(card);
  if (i >= 0){ p.hand.splice(i,1); return; }
  for (const k of D.EQUIP_SLOTS){
    if (p.equips[k] === card){
      const lost = p.equips[k]; p.equips[k] = null;
      if (lost.name === '医保卡') { /* 失去医保卡回复 → 由调用方处理 */ }
      return;
    }
  }
  i = p.judge.indexOf(card);
  if (i >= 0){ p.judge.splice(i,1); return; }
}
function allZoneCards(p){
  const arr = [];
  p.hand.forEach(c => arr.push({card:c, zone:'hand'}));
  for (const k of D.EQUIP_SLOTS) if (p.equips[k]) arr.push({card:p.equips[k], zone:'equip'});
  p.judge.forEach(c => arr.push({card:c, zone:'judge'}));
  return arr;
}
function canBeHandTargeted(p){ return !hasSkill(p, '加密'); }

/* ---------------- 伤害与体力 ---------------- */
async function damage(target, amount, source, type, opts){
  opts = opts || {};
  if (!target.alive || amount <= 0) return 0;
  type = type || 'normal';

  /* Hogo【护主】：把这次**普通伤害**整个接过去。
     放在最前面 —— 接过去之后，原目标身上的防具与减伤技能就都不该再生效了
     （伤害打在谁身上就按谁的减伤算）。opts.noHuzhu 防止接过去的人再转手，
     否则两个有护主的角色会互相弹。属性伤害与无来源伤害不能替。 */
  if (type === 'normal' && !opts.noHuzhu){
    for (const h of orderFrom(G.turnSeat)){
      if (!h.alive || h === target) continue;
      if (!hasSkill(h, '护主') || skillUsed(h, '护主')) continue;
      if (!h.hand.length && !D.EQUIP_SLOTS.some(k => h.equips[k])) continue;
      const r = await Ask(h, { kind:'choice',
        prompt:'【护主】' + target.name + ' 即将受到 ' + amount + ' 点普通伤害，是否弃一张牌代替其承受？',
        options:[{key:'yes',label:'发动（弃一张牌）'},{key:'no',label:'放弃'}], skillBlock:true });
      if (r.option !== 'yes') continue;
      const sel = await Ask(h, { kind:'selectCards', prompt:'【护主】弃置一张牌', from:'self', min:1, max:1 });
      if (!sel.cards || !sel.cards.length) continue;
      discardFromHand(h, sel.cards);
      markSkillUsed(h, '护主');
      log(h.name + ' 发动【护主】，代替 ' + target.name + ' 承受这 ' + amount + ' 点伤害', 'sys');
      if (window.UI) UI.render();
      return await damage(h, amount, source, type, Object.assign({}, opts, { noHuzhu:true }));
    }
  }

  let dmg = amount;
  const bonus = [];
  // 雨衣：受到火焰伤害 +1
  if (type === 'fire' && target.equips.armor && target.equips.armor.name === '雨衣' && !opts.ignoreArmor){
    dmg++; bonus.push('雨衣 +1');
  }
  // 张金雪【无私】：对体力值**大于自己**的角色造成伤害时 +1（每回合限一次）。
  // 用通用的 markSkillUsed：它天然被 runTurn 重置、也天然在存档里 ——
  // 自造一个 p.xxxUsed 标志就得多改两处，而存档那处漏了是不报错的（【过滤】漏过一次）。
  if (source && source !== target && hasSkill(source, '无私')
      && !skillUsed(source, '无私') && target.hp > source.hp){
    markSkillUsed(source, '无私');
    dmg++; bonus.push('无私 +1');
  }
  // 医保卡：伤害大于 1 时防止多余伤害
  if (target.equips.armor && target.equips.armor.name === '医保卡' && !opts.ignoreArmor && dmg > 1){
    dmg = 1; bonus.push('医保卡封顶');
  }
  const reductions = [];
  // 亨利【挥金】：**每轮首次受到伤害 -1**（换来的 2 点手牌上限见 handLimit）。
  //
  // 方向是探针逼出来的：原先写的是"受到伤害 +1"，试了三档（不限次 / 每回合首次 /
  // 每轮首次）分别跑出 0.49 / 0.56 / 0.50 —— 三次都是全场最弱。5 人局一局能跑六七轮，
  // 每轮多挨 1 点就是多挨六七点，对 4 血角色等于判死刑。既然"代价型"怎么调都最弱，
  // 就把它反过来做成收益：财富大佬花钱保命，手牌上限 +2 配一个每轮一次的减伤。
  // 用"记轮号"，不需要谁去重置，也自动进存档（同【过滤】【滑不溜秋】）。
  if (hasSkill(target, '挥金') && target.marks.flexRound !== G.round){
    target.marks.flexRound = G.round;
    dmg--; reductions.push('挥金 -1');
  }
  // 周志远【正义】
  if (hasSkill(target, '正义') && source && source.hand.length > target.hand.length){ dmg--; reductions.push('正义 -1'); }
  // 肾小球【过滤】：**每轮首次**受到的非属性伤害 -1
  // （原来是无次数限制的 -1，等于免疫主流伤害源 → 收紧到"每回合首次" → 再放宽到每轮）
  //
  // 用"记轮号"而不是"重置一个布尔标志"：轮号自己会变，所以不需要在回合开始/轮次
  // 回绕处重置，也不会漏进存档（p.filterUsed 就因为漏进存档，房主掉线换人接手后
  // 能多减一次伤害）。同样的写法见西鱼【滑不溜手】。
  if (hasSkill(target, '过滤') && type === 'normal' && target.marks.filterRound !== G.round){
    target.marks.filterRound = G.round;
    dmg--; reductions.push('过滤 -1');
  }
  // 老石【石肤】：受到的**属性**伤害 -1 —— 和【过滤】正好互补（那个管普通伤害）
  if (hasSkill(target, '石肤') && (type === 'fire' || type === 'thunder')){
    dmg--; reductions.push('石肤 -1');
  }
  // 老虎【盘踞】：伤害来源在自己攻击范围内时 -1。
  //
  // **这里特意不限次**：老虎现在只有 2 点体力上限（手牌上限也跟着只剩 2），
  // 血量已经替它还了超模的债。早先"2 血 + 盘踞限次"两个削弱叠在一起时，
  // 平衡探针跑出来它是全场倒数的 0.72（胜率 14%），明显过削。
  // 判据和【正义】不同：那个比手牌数，这个比距离。
  if (hasSkill(target, '盘踞') && source && source !== target && inAttackRange(target, source)){
    dmg--; reductions.push('盘踞 -1');
  }
  // 董启龙【兄弟】：其他角色受伤时弃一张牌令伤害-1
  for (const p of orderFrom(G.turnSeat)){
    if (!p.alive || p === target) continue;
    if (!hasSkill(p, '兄弟') || skillUsed(p, '兄弟')) continue;
    if (dmg <= 0) break;
    if (p.hand.length === 0) continue;
    const r = await Ask(p, { kind:'choice', prompt:'【兄弟】' + target.name + ' 即将受到 ' + dmg + ' 点伤害，是否弃一张牌令伤害-1？',
      options:[{key:'yes',label:'发动（弃一张牌）'},{key:'no',label:'放弃'}], skillBlock:true });
    if (r.option === 'yes'){
      const sel = await Ask(p, { kind:'selectCards', prompt:'【兄弟】弃置一张牌', from:'self', min:1, max:1 });
      if (sel.cards && sel.cards.length){
        discardFromHand(p, sel.cards); markSkillUsed(p, '兄弟');
        dmg--; reductions.push('兄弟 -1');
      }
    }
    break;
  }
  if (dmg <= 0){
    log(target.name + ' 的此次伤害被完全减免（' + reductions.concat(bonus).join('，') + '）', 'sys');
    return 0;
  }
  // 可选规则：保护轮（第一圈内体力不会降到 1 以下）
  if (G.opts.protect && G.round === 1 && !opts.ignoreProtect){
    const cap = Math.max(0, target.hp - 1);
    if (dmg > cap){
      dmg = cap;
      if (dmg <= 0){ log('保护轮：' + target.name + ' 的体力被锁定在 1 点，本次伤害不成立', 'sys'); return 0; }
      log('保护轮：伤害被限制为 ' + dmg + ' 点（第一圈不死亡）', 'sys');
    }
  }
  target.hp -= dmg;
  if (window.FX){
    FX.floatText(target.seat, '-' + dmg, dmg >= 2 ? 'dmg big' : 'dmg');
    FX.shake(target.seat, dmg >= 2);
    FX.sfx(dmg >= 3 ? 'bigHurt' : 'damage');
    if (dmg >= 3) FX.flash('red');
  }
  log(target.name + ' 受到 ' + dmg + ' 点' + dmgTypeName(type) + '伤害' + (source ? '（来源：' + source.name + '）' : '（无来源）')
      + (bonus.length ? ' [' + bonus.join('，') + ']' : '') + (reductions.length ? ' [' + reductions.join('，') + ']' : ''), 'dmg');
  if (window.UI) UI.render();
  await sleep(520);          // 伤害结算后停顿，让人看清数值与来源
  if (source && source !== target){
    if (source.alive) source.damageDealtThisTurn = (source.damageDealtThisTurn||0) + dmg;
    G.harmLog.push({ s: source.seat, t: target.seat, a: dmg, type: type });
    noteStat(source.seat, 'dmg', dmg);          // 赛后评分：实际打出的伤害
  }

  // 超开心【傻乐】：受到伤害后摸一张牌。
  // 位置特意放在**濒死结算之前** —— 摸到的如果是请假条，就能当场自救，
  // 这是"受伤立即摸牌"本该有的互动（放到濒死之后这张牌就白摸了）。
  if (hasSkill(target, '傻乐')) await drawCards(target, 1, '傻乐');

  // 孩子【捣乱】：受伤后伤害来源随机弃一张手牌。无来源（论文查重）不触发。
  if (hasSkill(target, '捣乱') && source && source !== target && source.alive && source.hand.length){
    const i = Math.floor(Math.random() * source.hand.length);
    const c = source.hand[i];
    discardFromHand(source, [c]);
    log('【捣乱】：' + source.name + ' 随机弃置了一张手牌', 'sys');
    if (window.UI) UI.render();
  }

  /* 老姜【辣手】：受伤后反弹 1 点给伤害来源（每回合限一次）。
     opts.noRebound 是必须的 —— 场上两个有辣手的人会互相弹到递归爆栈。
     反伤本身还会再走一遍 damage()，所以濒死/胜负都由引擎照常处理。 */
  if (hasSkill(target, '辣手') && source && source !== target && source.alive
      && !skillUsed(target, '辣手') && !opts.noRebound){
    markSkillUsed(target, '辣手');
    log('【辣手】：' + target.name + ' 反弹 1 点给 ' + source.name, 'dmg');
    if (window.UI) UI.render();
    await sleep(200);
    await damage(source, 1, target, 'normal', Object.assign({}, opts, { noRebound:true }));
    if (G.over) return dmg;
  }

  // 濒死
  if (target.hp <= 0){
    const survived = await enterDying(target, source);
    if (!survived) return dmg;
  }
  // 横置传导（仅属性伤害）
  if (type === 'fire' || type === 'thunder') await chainConduct(target, dmg, source, type);
  return dmg;
}
function dmgTypeName(t){ return t === 'fire' ? '火焰' : t === 'thunder' ? '雷电' : t === 'true' ? '真实' : '普通'; }

async function chainConduct(target, amount, source, type){
  if (!target.chained) return;
  target.chained = false;
  const others = alivePlayers().filter(p => p !== target && p.chained);
  if (!others.length){ log(target.name + ' 的横置状态被属性伤害解除（无传导目标）', 'sys'); return; }
  log(target.name + ' 受到属性伤害，横置解除并向 ' + others.map(o=>o.name).join('、') + ' 传导 ' + amount + ' 点' + dmgTypeName(type) + '伤害', 'sys');
  for (const o of others){
    o.chained = false;
    await damage(o, amount, source, type, { noChain:true });
  }
}

async function heal(target, amount, reason, by){
  if (!target.alive) return;
  const before = target.hp;
  target.hp = Math.min(target.maxHp, target.hp + amount);
  // 赛后评分：治疗**他人**才算（自己喝请假条不算贡献）
  if (by && by !== target && target.hp > before) noteStat(by.seat, 'heals', target.hp - before);
  if (target.hp > before){
    log(target.name + ' 回复 ' + (target.hp - before) + ' 点体力（' + target.hp + '/' + target.maxHp + '）', 'heal');
    if (window.FX){ FX.floatText(target.seat, '+' + (target.hp - before), 'heal'); FX.sfx('heal'); }
    // 馒头【热乎】：回复体力时额外摸一张（每回合限一次）。
    // 只有**真的回了血**才触发 —— 体力已满时 heal 不改变 hp，不该白送一张
    if (hasSkill(target, '热乎') && !skillUsed(target, '热乎')){
      markSkillUsed(target, '热乎');
      if (window.UI) UI.render();
      await drawCards(target, 1, '热乎');
    }
  }
  if (window.UI) UI.render();
  await sleep(380);
}

/** 濒死与救援：返回 true 表示存活 */
async function enterDying(p, source){
  /* 老猫【九条命】：本局第一次进入濒死时直接回到 1 点，不进入求援流程。
     放在最前面 —— 排在"本人自救"之前才有意义，否则就得先掏一张请假条了。
     标志存在 marks 里（marks 整体进存档），不必再改 serializeGame。 */
  if (hasSkill(p, '九条命') && !p.marks.nineLives){
    p.marks.nineLives = 1;
    p.hp = 1;
    logBig('🐱 ' + p.name + ' 发动【九条命】，原地回到 1 点体力（本局仅此一次）');
    if (window.FX){ FX.floatText(p.seat, '+1', 'heal'); FX.sfx('heal'); }
    if (window.UI) UI.render();
    await sleep(560);
    return true;
  }
  logBig('⚠ ' + p.name + ' 进入濒死状态（体力 ' + p.hp + '）');
  if (window.UI) UI.render();
  await sleep(300);

  // 第 0 步：本人自救
  await rescueLoop(p, p, true);
  if (p.hp > 0){ log(p.name + ' 自救成功，脱离濒死', 'heal'); return true; }

  // 第 1 步：从当前回合角色开始按座位顺序求援
  const order = orderFrom(G.turnSeat).filter(x => x !== p);
  for (const helper of order){
    if (p.hp > 0) break;
    if (!helper.alive) continue;
    await rescueLoop(p, helper, false);
  }
  // 第 2 步：追加窗口
  if (p.hp <= 0){
    for (const helper of order){
      if (p.hp > 0) break;
      if (!helper.alive) continue;
      const r = await Ask(helper, { kind:'choice', prompt:p.name + ' 仍在濒死，是否追加救援？',
        options:[{key:'yes',label:'追加救援'},{key:'no',label:'放弃'}] });
      if (r.option === 'yes') await rescueLoop(p, helper, false);
    }
  }
  if (p.hp > 0){ log(p.name + ' 被救回，脱离濒死', 'heal'); return true; }
  // 第 3 步：死亡
  await killPlayer(p, source);
  return false;
}

/** helper 为濒死者提供救援：isSelf 表示本人自救 */
async function rescueLoop(dying, helper, isSelf){
  while (dying.hp <= 0 && dying.alive){
    const options = [];
    const healCards = helper.hand.filter(c => CARDS[c.name].kind === 'heal' || CARDS[c.name].kind === 'buff');
    if (isSelf || true){
      if (healCards.length) options.push({key:'card', label:'使用请假条/红牛（回复1点）'});
    }
    if (hasSkill(helper,'鼓励') && helper.hand.length > 0 && dying.hp <= 0){
      options.push({key:'skill1', label:'发动【鼓励】（弃一张手牌，回复1点）'});
    }
    if (!options.length){
      if (isSelf) return;
      return;
    }
    if (!isSelf){
      // 询问是否救援
      const pre = await Ask(helper, { kind:'choice',
        prompt:'是否救援 ' + dying.name + '？（其体力 ' + dying.hp + '）',
        options: options.concat([{key:'no', label:'不救'}]).map(o => ({key:o.key, label:o.label})) });
      if (pre.option === 'no') return;
      if (pre.option === 'skill1'){
        const sel = await Ask(helper, { kind:'selectCards', prompt:'【鼓励】弃置一张手牌', from:'self', min:1, max:1 });
        if (sel.cards && sel.cards.length){
          discardFromHand(helper, sel.cards);
          noteRescue(helper, dying);
          await heal(dying, 1, '鼓励', helper);
        }
        continue;
      }
      const sel = await Ask(helper, { kind:'selectCards', prompt:'使用一张回复牌救 ' + dying.name,
        from:'self', min:1, max:1, filter:c => CARDS[c.name].kind === 'heal' || CARDS[c.name].kind === 'buff' });
      if (!sel.cards || !sel.cards.length) return;
      removeFromHand(helper, sel.cards); toDiscard(sel.cards);
      log(helper.name + ' 使用 ' + cardText(sel.cards[0]) + ' 救援 ' + dying.name, 'heal');
      noteRescue(helper, dying);
      await heal(dying, 1, 'rescue', helper);
      continue;
    }
    // 本人自救
    const isHeal = healCards.length > 0;
    if (!isHeal && !(hasSkill(helper,'鼓励') && helper.hand.length > 0)) return;
    const opts = [];
    if (isHeal) opts.push({key:'card', label:'使用请假条/红牛自救'});
    if (hasSkill(helper,'鼓励') && helper.hand.length > 0) opts.push({key:'skill1', label:'发动【鼓励】自救（弃一张手牌）'});
    opts.push({key:'no', label:'放弃自救'});
    const r = await Ask(helper, { kind:'choice', prompt:'你正处于濒死（体力 ' + dying.hp + '），是否自救？', options:opts });
    if (r.option === 'no') return;
    if (r.option === 'skill1'){
      const sel = await Ask(helper, { kind:'selectCards', prompt:'【鼓励】弃置一张手牌', from:'self', min:1, max:1 });
      if (sel.cards && sel.cards.length){ discardFromHand(helper, sel.cards); await heal(dying, 1, '鼓励'); }
      continue;
    }
    const sel = await Ask(helper, { kind:'selectCards', prompt:'使用一张回复牌自救',
      from:'self', min:1, max:1, filter:c => CARDS[c.name].kind === 'heal' || CARDS[c.name].kind === 'buff' });
    if (!sel.cards || !sel.cards.length) return;
    removeFromHand(helper, sel.cards); toDiscard(sel.cards);
    log(helper.name + ' 使用 ' + cardText(sel.cards[0]) + ' 自救', 'heal');
    await heal(dying, 1, 'rescue');
  }
}

/**
 * 记一笔救援。
 *   · 院长的救援另记进 G.rescueLog —— 院方 AI 靠它判断"某人更像教务"，从而少打他
 *   · 所有救援都记进评分统计（救谁是贡献，跟身份无关）
 */
function noteRescue(helper, dying){
  if (!helper || !dying || helper === dying) return;   // 自救不算
  noteStat(helper.seat, 'saves', 1);
  if (dying.identity !== 'dean') return;
  if (!G.rescueLog) G.rescueLog = {};
  G.rescueLog[helper.seat] = (G.rescueLog[helper.seat] || 0) + 1;
}

/* ---------------- 死亡与胜负 ---------------- */
async function killPlayer(p, source){
  p.alive = false;
  p.revealed = true;
  // 赛后评分：击杀只算"别人的人头"（自爆/无来源不算）
  if (source && source !== p && source.alive !== false){
    noteStat(source.seat, 'kills', 1);
    if (!G.killLog) G.killLog = [];
    G.killLog.push({ killer: source.seat, victim: p.seat });
  }
  // 用 fmt().sideName 而不是 IDENTITIES[...]：团队形式下 p.identity 是 null，
  // 直接解引用会崩，而且崩在"任何人死亡"这条最常走的路上
  logBig('☠ ' + p.name + ' 死亡，身份揭示：' + fmt().sideName(fmt().sideOf(p)));
  if (window.FX) await FX.death(p);
  // 牌全部进弃牌堆
  const cards = p.hand.splice(0).concat(
    D.EQUIP_SLOTS.map(k => { const c = p.equips[k]; p.equips[k] = null; return c; }).filter(Boolean),
    p.judge.splice(0)
  );
  toDiscard(cards);
  if (window.UI) UI.render();
  await sleep(400);

  // 奖惩：按对局形式分派（团队形式没有身份，也就没有身份奖惩）
  if (source && source.alive && source !== p) await fmt().killReward(source, p);
  if (window.UI) UI.render();
  checkVictory();
}

function checkVictory(){
  if (G.over) return;
  fmt().victory();          // 胜负逻辑按对局形式分派，见文件顶部的 FORMAT 表
}
/* ---------------- 赛后评分 ----------------
 * 只奖励"做的事"，不奖励"抽到什么身份" —— 身份输赢已经由阵营分体现了，
 * 这里比的是"这一局谁打得漂亮"。所以一个打得很凶但输掉的学生，
 * 完全可以拿到比躺赢的教务更高的分。 */
const SCORE_RULE = [
  { key:'dmg',    label:'造成伤害', per:3,  unit:'点' },
  { key:'kills',  label:'击杀',     per:15, unit:'个' },
  { key:'saves',  label:'救援濒死', per:12, unit:'次' },
  { key:'heals',  label:'治疗他人', per:4,  unit:'点' },
  { key:'skills', label:'发动技能', per:2,  unit:'次', cap:20 }
];
const SCORE_WIN = 30, SCORE_DRAW = 10, SCORE_ALIVE = 8;

function buildScoreboard(winner){
  const rows = G.players.map(p => {
    const st = statOf(p.seat);
    // 阵营归属只有这一处实现（fmt().winOf）—— 这里从 4 份重复收敛过来的第 1 份
    const win = !!(winner && fmt().winOf(winner, p));
    const parts = [];
    let score = 0;
    if (win){ score += SCORE_WIN; parts.push({ label:'阵营胜利', v:SCORE_WIN }); }
    else if (!winner){ score += SCORE_DRAW; parts.push({ label:'平局', v:SCORE_DRAW }); }
    SCORE_RULE.forEach(r => {
      let v = (st[r.key] || 0) * r.per;
      if (r.cap) v = Math.min(v, r.cap);
      if (v > 0){ score += v; parts.push({ label:r.label, v:v }); }
    });
    if (p.alive){ score += SCORE_ALIVE; parts.push({ label:'存活到终局', v:SCORE_ALIVE }); }
    // sideName / sideCls 由形式表算好一起发出去 —— 结算界面不该自己认识 D.IDENTITIES
    // （团队玩法下 p.identity 是 null，界面自己查会显示成 "?"）
    return { seat:p.seat, name:p.name, charTitle:(p.char ? p.char.title : ''),
             identity:p.identity,
             sideName: fmt().sideName(fmt().sideOf(p)),
             sideCls: fmt().sideCls(fmt().sideOf(p)),
             alive:!!p.alive, win:win,
             stats:st, score:score, parts:parts };
  });
  // MVP：总分最高；并列时比击杀 → 再比伤害 → 再比座位号（小的优先）
  let mvp = null;
  for (const r of rows){
    if (!mvp){ mvp = r; continue; }
    if (r.score > mvp.score) mvp = r;
    else if (r.score === mvp.score){
      if (r.stats.kills !== mvp.stats.kills) { if (r.stats.kills > mvp.stats.kills) mvp = r; }
      else if (r.stats.dmg > mvp.stats.dmg) mvp = r;
    }
  }
  if (mvp && mvp.score <= 0) mvp = null;      // 一分没得就别评了
  return { winner: winner, rows: rows, mvpSeat: mvp ? mvp.seat : -1 };
}

function endGame(winner, reason){
  if (G.over) return;
  G.over = true;
  // 旁观席的 humanSeat 是 -1，这里要挡住（联机时每个客户端自己算 humanWin）
  const human = G.players[G.humanSeat];
  const humanWin = !!(human && winner && fmt().winOf(winner, human));   // 第 2 份
  G.scoreboard = buildScoreboard(winner);
  logBig('游戏结束：' + (winner ? fmt().sideName(winner) + '阵营胜利' : '平局') + '（' + reason + '）');
  if (window.FX) FX.gameEnd(humanWin);
  if (window.UI && UI.showOver) UI.showOver(winner, reason, humanWin, G.scoreboard);
}

/* =========================================================
 *  询问入口：人类走 UI，AI 走 ai.js
 * ========================================================= */
async function Ask(player, req){
  req.player = player;
  if (G.over) return {};              // 游戏已结束：不再产生任何询问
  if (window.UI) UI.render();
  if (player.isHuman && window.UI && UI.askHuman) return await UI.askHuman(req);
  return await window.AI.decide(req);
}

/* ---------------- 询问是否打出某张响应牌 ---------------- */
/** 询问 order 中的角色是否打出指定牌名（代课/辅导员签字），返回打出的角色或 null */
async function askResponse(needName, reqPlayer, prompt, opts){
  opts = opts || {};
  const order = orderFrom(G.turnSeat);
  for (const p of order){
    if (!p.alive) continue;
    if (opts.onlyTarget && p !== reqPlayer) continue;
    const avail = p.hand.filter(c => c.name === needName || (needName === '代课' && CARDS[c.name].kind === 'dodge'));
    const canSkill = (needName === '代课') && (
      (hasSkill(p,'波比跳') && !skillUsed(p,'波比跳') && p.hand.length > 0) ||
      (p.equips.armor && p.equips.armor.name === '校园卡' && p === reqPlayer)
    );
    if (!avail.length && !canSkill) continue;
    // 校园卡判定失败后仍可用手牌中的代课，因此允许对同一角色重复询问
    let armorUsed = false;
    let answered = false;
    while (!answered){
      const opt2 = Object.assign({}, opts, { ignoreArmor: opts.ignoreArmor || armorUsed });
      const stillAvail = p.hand.filter(c => c.name === needName || (needName === '代课' && CARDS[c.name].kind === 'dodge'));
      const canArmorNow = !!(p.equips.armor && p.equips.armor.name === '校园卡' && !opt2.ignoreArmor);
      const canPopi = hasSkill(p, '波比跳') && !skillUsed(p, '波比跳') && p.hand.length > 0;
      if (!stillAvail.length && !canArmorNow && !canPopi){ answered = true; break; }
      const r = await Ask(p, { kind:'choice', prompt:prompt + '（' + p.name + '）',
        options: buildResponseOptions(p, needName, stillAvail, opt2) });
      if (!r.option || r.option === 'no'){ answered = true; break; }
      if (r.option === 'skill_popi'){
        const sel = await Ask(p, { kind:'selectCards', prompt:'【波比跳】弃置一张手牌', from:'self', min:1, max:1 });
        if (sel.cards && sel.cards.length){
          discardFromHand(p, sel.cards); markSkillUsed(p,'波比跳');
          log(p.name + ' 发动【波比跳】，视为打出【代课】', 'sys');
          if (window.FX){
            FX.skillBanner(p.name, '波比跳');
            FX.addToExchange(p.name, { name:'代课', suit:null }, '', { response:true, tag:'【波比跳】视为代课', sfx:'dodge' });
          }
          return { player:p, via:'波比跳' };
        }
        answered = true; break;
      }
      if (r.option === 'skill_card'){
        armorUsed = true;                       // 校园卡同一张牌只判定一次
        const jc = drawFromDeck();
        if (!jc){ answered = true; break; }
        log(p.name + ' 发动【校园卡】查考勤：' + cardText(jc), 'sys');
        if (window.FX) await FX.judge({ name:'校园卡' }, jc);
        toDiscard(jc);
        if (D.isRedCard(jc)){
          log('判定为红色 → 视为打出【代课】', 'sys');
          if (window.FX) FX.addToExchange(p.name, { name:'代课', suit:null }, '', { response:true, tag:'【校园卡】判定成功', sfx:'dodge' });
          return { player:p, via:'校园卡' };
        }
        log('判定为黑色 → 校园卡未生效，仍可用手牌代课', 'sys');
        continue;                               // 重新询问同一名角色
      }
      if (r.option === 'card'){
        const sel = await Ask(p, { kind:'selectCards', prompt:'打出 ' + needName, from:'self', min:1, max:1,
          filter:c => c.name === needName || (needName === '代课' && CARDS[c.name].kind === 'dodge') });
        if (sel.cards && sel.cards.length){
          removeFromHand(p, sel.cards); toDiscard(sel.cards);
          log(p.name + ' 打出 ' + cardText(sel.cards[0]), '');
          if (window.FX) FX.addToExchange(p.name, sel.cards[0], '', { response:true, tag:'响应 · 抵消', sfx:'dodge' });
          return { player:p, via:'card', card:sel.cards[0] };
        }
        answered = true; break;
      }
      answered = true;
    }
  }
  return null;
}
function buildResponseOptions(p, needName, avail, reqOpts){
  const opts = [];
  reqOpts = reqOpts || {};
  if (avail.length) opts.push({ key:'card', label:'打出' + needName + '（' + avail.map(cardText).join('、') + '）' });
  if (hasSkill(p,'波比跳') && !skillUsed(p,'波比跳') && p.hand.length > 0) opts.push({ key:'skill_popi', label:'发动【波比跳】（弃1张牌当代课）' });
  if (p.equips.armor && p.equips.armor.name === '校园卡' && needName === '代课' && !reqOpts.ignoreArmor)
    opts.push({ key:'skill_card', label:'发动【校园卡】查考勤' });
  opts.push({ key:'no', label:'放弃' });
  return opts;
}

/** 王磊【贬低】：其他角色打出代课时可弃一张牌令其无效（每回合限一次） */
async function tryDibel(dodgePlayer, attackUser){
  for (const p of orderFrom(G.turnSeat)){
    if (!p.alive) continue;
    if (!hasSkill(p, '贬低') || skillUsed(p, '贬低')) continue;
    if (p === dodgePlayer) continue;
    if (p.hand.length === 0 && !D.EQUIP_SLOTS.some(k => p.equips[k])) continue;
    const r = await Ask(p, { kind:'choice', prompt:'【贬低】' + dodgePlayer.name + ' 打出了代课，是否弃一张牌令其无效？',
      options:[{key:'yes',label:'发动（弃一张牌）'},{key:'no',label:'放弃'}], skillBlock:true });
    if (r.option !== 'yes') return false;
    const sel = await Ask(p, { kind:'selectCards', prompt:'【贬低】弃置一张牌（手牌或装备）', from:'any', min:1, max:1 });
    if (!sel.cards || !sel.cards.length) return false;
    const c = sel.cards[0];
    if (p.hand.includes(c)) discardFromHand(p, [c]);
    else { removeFromZone(p, c); toDiscard(c); log(p.name + ' 弃置了装备区的 ' + cardText(c), ''); }
    markSkillUsed(p, '贬低');
    log(p.name + ' 发动【贬低】，令代课无效！', 'sys');
    return true;
  }
  return false;
}

/* =========================================================
 *  使用牌的主流程
 * ========================================================= */
function cardText(c){
  if (!c) return '？';
  if (c.virtual) return '【视为' + c.name + '】';
  if (!D.SUITS[c.suit]) return c.name;
  return D.suitOf(c).sym + D.rankLabel(c.rank) + '·' + c.name;
}

/**
 * 这张牌是不是"点名类牌"（上课点名 / 公开处刑 / 雷同警告）。
 * 规则书 5.1.1：三者统称点名类牌，共用每出牌阶段 1 张的次数上限。
 * 火杀/雷杀在三国杀里也是"杀"，这里同理 —— 一切按类别判定的地方都用它。
 */
function isPointCard(card){
  return !!(card && D.ATTACK_CARDS.includes(card.name));
}

/** 计算某人是否免疫某张牌（防具 / 锁定技） */
function isImmuneByCard(target, card, attacker){
  // 【试卷】：使用者以点名类牌指定目标时无视其防具
  const paper = attacker && attacker.equips.weapon && attacker.equips.weapon.name === '试卷'
                && isPointCard(card);
  const armor = paper ? null : target.equips.armor;
  const attr = (card.dmg === 'fire' || card.dmg === 'thunder');
  if (card.kind === 'attack'){
    // 学生证挡"黑色点名" —— 雷同警告全黑，所以它现在也会被挡
    if (armor && armor.name === '学生证' && D.isBlackCard(card)) return '学生证（黑色点名无效）';
    // 雨衣只挡**非属性**点名（上课点名）。公开处刑/雷同警告是属性伤害，
    // 雨衣对它们不生效 —— 这是它的代价所在（受到火焰伤害 +1）。
    if (armor && armor.name === '雨衣' && !attr) return '雨衣（普通点名无效）';
  }
  if (card.kind === 'aoeAttack'){
    if (armor && armor.name === '雨衣') return '雨衣（群伤免疫）';
  }
  return null;
}

/** 目标合法性 */
function validTargets(user, card){
  const res = [];
  const othersAlive = others(user);
  const k = card.kind;
  const canTarget = t => !(t.marks && t.marks.slideFrom === user.seat && t.marks.slideTurn === G.turnId);
  if (k === 'attack'){
    for (const t of othersAlive){
      if (!inAttackRange(user, t)) continue;
      if (!canTarget(t)) continue;
      res.push(t);
    }
    return res;
  }
  if (k === 'heal' || k === 'buff') return [user];
  if (k === 'draw2') return [user];
  if (k === 'lightning') return [user];
  if (k === 'aoeAttack') return othersAlive;
  if (k === 'massHeal' || k === 'harvest') return othersAlive.concat([user]);
  if (k === 'dismantle'){
    for (const t of othersAlive){
      const z = allZoneCards(t);
      if (z.some(x => x.zone !== 'hand' || canBeHandTargeted(t))) res.push(t);
    }
    return res;
  }
  if (k === 'snatch'){
    for (const t of othersAlive){
      if (card.tag === 'probe' && hasSkill(t, '潜行')) continue;
      if (distance(user, t) > 1) continue;
      const z = allZoneCards(t);
      if (z.some(x => x.zone !== 'hand' || canBeHandTargeted(t))) res.push(t);
    }
    return res;
  }
  if (k === 'duel'){
    for (const t of othersAlive){ if (hasSkill(t, '伦理')) continue; res.push(t); }
    return res;
  }
  if (k === 'relay'){
    for (const t of othersAlive){ if (t.equips.weapon) res.push(t); }
    return res;
  }
  if (k === 'fireTalk'){
    for (const t of othersAlive){ if (t.hand.length > 0 && canBeHandTargeted(t)) res.push(t); }
    return res;
  }
  if (k === 'chain') return alivePlayers();
  if (k === 'delayPlay'){
    for (const t of othersAlive){ if (hasSkill(t,'潜行')) continue; res.push(t); }
    return res;
  }
  if (k === 'delayDraw'){
    for (const t of othersAlive){ if (distance(user, t) <= 1) res.push(t); }
    return res;
  }
  return res;
}

/** 使用一张牌（外层包装：一次"出牌 + 其所有后续响应牌"= 一次结算连锁，
 *  连锁期间所有牌都留在中央出牌区，整条链结束后才清空） */
let _exchDepth = 0;
async function useCard(user, card, targets){
  const outer = (_exchDepth === 0);
  _exchDepth++;
  if (outer && window.FX) FX.beginExchange();
  try {
    return await useCardInner(user, card, targets);
  } finally {
    _exchDepth--;
    if (_exchDepth === 0 && window.FX) await FX.endExchange();
  }
}

async function useCardInner(user, card, targets){
  // 从手牌移除
  removeFromHand(user, [card]);
  card._usedBy = user.seat;
  if (!user.usedCardsThisTurn) user.usedCardsThisTurn = [];
  user.usedCardsThisTurn.push(card);
  // 使用次数记录（点名类 / 延时类）
  if (D.ATTACK_CARDS.includes(card.name)){
    user.usedAttackCardThisPhase = (user.usedAttackCardThisPhase||0) + 1;
    // Tania【双语】的加成只兑现在**这一张**上（冲锋的虚拟点名不算，它自己只有单目标）
    user.bilingual = false;
  }
  if (card.type === 'delayed') user.usedDelayed = (user.usedDelayed||0) + 1;

  // 学生证 / 雨衣 的"牌无效"在这里先过滤目标
  const effTargets = [];
  if (targets && targets.length){
    for (const t of targets){
      const imm = isImmuneByCard(t, card, user);
      if (imm){ log(t.name + ' 的 【' + imm + '】 令 ' + card.name + ' 无效', 'sys'); continue; }
      effTargets.push(t);
    }
  }

  log('▶ ' + user.name + ' 使用 ' + cardText(card) + (effTargets.length ? ' → ' + effTargets.map(t=>t.name).join('、') : ''), 'hl');

  // 出牌特写：中央放大展示，给所有玩家看清的时间
  if (window.FX){
    const names = effTargets.map(t => t.name);
    const tgt = names.length
      ? '→ ' + (names.length > 3 ? names.slice(0, 2).join('、') + ' 等 ' + names.length + ' 人' : names.join('、'))
      : '';
    const isEquip = card.type === 'equip';
    await FX.cardPlay(user.name, card, tgt, { sfx: isEquip ? 'equip' : (card.kind === 'attack' ? 'attack' : 'play') });
  }

  // 【炫富】：目标可取消针对自己的此牌
  let canceledFor = new Set();
  for (const t of effTargets){
    if (!t.alive || t === user) continue;   // 自己对自己使用牌不触发炫富
    if (flexReady(t) && t.hand.length > 0){
      const r = await Ask(t, { kind:'choice', prompt:'【炫富】' + user.name + ' 对你使用了 ' + card.name + '，是否弃一张牌取消此牌？',
        options:[{key:'yes',label:'发动【炫富】（弃1张牌，对方摸1张，取消此牌）'},{key:'no',label:'放弃'}], skillBlock:true });
      if (r.option === 'yes'){
        const sel = await Ask(t, { kind:'selectCards', prompt:'【炫富】弃置一张牌', from:'self', min:1, max:1 });
        if (sel.cards && sel.cards.length){
          discardFromHand(t, sel.cards); markFlex(t);
          await drawCards(user, 1, '炫富');
          canceledFor.add(t.seat);
          log(t.name + ' 发动【炫富】，取消了对自己的 ' + card.name, 'sys');
        }
      }
    }
  }
  const live = effTargets.filter(t => !canceledFor.has(t.seat));

  // 【人脉】：有人使用事件牌时可令其额外摸一张
  if (card.type === 'event' || card.type === 'delayed') await triggerRenmai(user);

  // Tania【板书】：使用事件牌**指定了其他角色**为目标时摸一张（每回合限一次）。
  // 用 live 而不是 effTargets —— 被【炫富】取消掉的目标不算数。
  // 只对自己用的牌（如放假通知、小组作业之外的）不触发。
  if (card.type === 'event' && live.some(t => t !== user)
      && hasSkill(user, '板书') && !skillUsed(user, '板书')){
    markSkillUsed(user, '板书');
    log(user.name + ' 发动【板书】，摸一张牌', 'sys');
    await drawCards(user, 1, '板书');
  }

  // 辅导员签字：**只在牌真正起作用的那一刻**才能被抵消。
  //   · 普通事件牌 → 就是现在（作用时）
  //   · 延时牌（手机没电/饭卡没钱/论文查重）→ 等到回合开始查考勤、**翻开抽签牌之前**问，
  //     放置的时候不开放（见 judgePhase）。跟闪电一样：翻开了就只剩改判窗口，不能再补。
  //   · 群体牌（随堂测验/突击查寝）→ 在 resolveAoe 里对**每个目标**单独问
  const isAoe = (card.kind === 'aoeAttack');
  if (card.type === 'event' && card.kind !== 'nullify' && !isAoe){
    const nul = await nullifyCheck(user, card);
    if (nul){ toDiscard(card); finishUse(user, card); return; }
  }

  // 【伦理】：其他角色的事件牌指定你为目标时，你摸一张牌。
  // （原来这条技能只有一个"免疫课堂辩论"，而全场就 3 张课堂辩论 ——
  //   等于半个技能是死的。加一条实际收益，坐实"伦理课代表能讲道理"的人设。）
  if (card.type === 'event'){
    for (const t of live){
      if (t === user || !t.alive || !hasSkill(t, '伦理')) continue;
      log(t.name + ' 发动【伦理】，摸一张牌', 'sys');
      await drawCards(t, 1, '伦理');
    }
  }

  // 分派效果
  switch (card.kind){
    case 'attack':       await resolveAttack(user, card, live); break;
    case 'dodge':        break;
    case 'heal':         await heal(user, 1, '请假条'); break;
    case 'buff':         user.marks.buff = (user.marks.buff||0) + 1;
                          log(user.name + ' 使用红牛，本回合下一张点名类牌伤害+1', 'sys'); break;
    case 'dismantle':    await resolveDismantle(user, live[0]); break;
    case 'snatch':       await resolveSnatch(user, live[0]); break;
    case 'draw2':        await drawCards(user, 2, '借笔记'); break;
    case 'duel':         await resolveDuel(user, live[0]); break;
    case 'aoeAttack':    await resolveAoe(user, card); break;
    case 'relay':        await resolveRelay(user, live[0]); break;
    case 'harvest':      await resolveHarvest(user); break;
    case 'massHeal':     for (const p of alivePlayers()) await heal(p, 1, '放假通知', user); break;
    case 'fireTalk':     await resolveFireTalk(user, live[0]); break;
    case 'chain':        await resolveChain(user, live); break;
    case 'delayPlay':    placeDelayed(live[0], card); finishUse(user, card); return;
    case 'delayDraw':    placeDelayed(live[0], card); finishUse(user, card); return;
    case 'lightning':    placeDelayed(user, card); finishUse(user, card); return;
    case 'equip':        equipCard(user, card); return;   // 装备牌不进弃牌堆
    case 'nullify':      break;
  }
  toDiscard(card);
  finishUse(user, card);
}
function finishUse(user, card){
  if (window.UI) UI.render();
}
function placeDelayed(target, card){
  if (!target) return;
  target.judge.push(card);
  log(card.name + ' 置于 ' + target.name + ' 的通知栏', 'sys');
  if (window.UI) UI.render();
}
function equipCard(user, card){
  const slot = card.slot;
  const old = user.equips[slot];
  user.equips[slot] = card;
  user.hand = user.hand.filter(c => c !== card);
  log(user.name + ' 装备了 ' + cardText(card), 'sys');
  if (old){
    toDiscard(old);
    log(user.name + ' 的 ' + old.name + ' 被替换，进入弃牌堆', 'sys');
    if (old.name === '医保卡') heal(user, 1, '失去医保卡');
  }
  if (window.UI) UI.render();
}

/* ---------------- 点名类牌结算 ---------------- */
async function resolveAttack(user, card, targets){
  for (const t of targets){
    if (!t.alive) continue;
    await resolveAttackOne(user, card, t);
  }
}
async function resolveAttackOne(user, card, target, opts){
  opts = opts || {};
  // 【试卷】锁定技：以"上课点名"指定目标时无视其防具（校园卡/学生证/医保卡/雨衣全部失效）
  const ignoreArmor = !!(user.equips.weapon && user.equips.weapon.name === '试卷' && isPointCard(card));

  /* 西鱼【滑不溜手】：每轮你第一次被点名类牌指定时，此牌对你无效。
     排在【吠叫】之前 —— 牌都已经无效了，就不该再向使用者收税。
     用"标记里存的轮号 == 当前轮号"来判断"这一轮已经躲过一次"，天然进存档。 */
  if (target !== user && isPointCard(card) && hasSkill(target, '滑不溜手')
      && target.marks.slipperyRound !== G.round){
    target.marks.slipperyRound = G.round;
    log('【滑不溜手】：' + target.name + ' 每轮首次被点名无效，【' + card.name + '】落空', 'sys');
    if (window.UI) UI.render();
    return;
  }

  /* Hogo【吠叫】：其他角色对你使用点名类牌时，须先弃一张牌，否则此牌无效。
     排在代课窗口**之前** —— 牌都已经无效了，就不该再走一遍代课响应。
     付不出牌（手牌和装备区都空）时直接无效，不用问。 */
  if (target !== user && isPointCard(card) && hasSkill(target, '吠叫')){
    let paid = false;
    if (countPayable(user) > 0){
      const r = await Ask(user, { kind:'choice',
        prompt:'【吠叫】' + target.name + ' 有【吠叫】：弃一张牌这张 ' + card.name + ' 才生效，是否弃牌？',
        options:[{key:'yes',label:'弃一张牌（照常生效）'},{key:'no',label:'不弃（此牌无效）'}], skillBlock:true });
      if (r.option === 'yes'){
        const sel = await Ask(user, { kind:'selectCards', prompt:'【吠叫】弃置一张牌', from:'any', min:1, max:1 });
        if (sel.cards && sel.cards.length){ payCards(user, sel.cards); paid = true; }
      }
    }
    if (!paid){
      log('【吠叫】：' + card.name + ' 对 ' + target.name + ' 无效'
          + (countPayable(user) === 0 ? '（' + user.name + ' 无牌可弃）' : ''), 'sys');
      if (window.UI) UI.render();
      return;
    }
  }

  let dodged = false;
  if (target.dodgeBan){
    log(target.name + ' 本回合不能使用"代课"', 'sys');
  } else {
    const res = await askResponse('代课', target, '【' + card.name + '】' + user.name + ' 指定 ' + target.name + ' 为目标，是否打出代课？', { onlyTarget:true, ignoreArmor });
    if (res){
      let negated = false;
      if (res.via === 'card' || res.via === '波比跳'){
        negated = await tryDibel(target, user);
      }
      if (!negated){
        dodged = true;
        // 红笔：被代课抵消时可弃两张牌令伤害照常
        if (user.equips.weapon && user.equips.weapon.name === '红笔' && isPointCard(card)){
          const canPay = countPayable(user) >= 2;
          if (canPay){
            const r = await Ask(user, { kind:'choice', prompt:'【红笔】是否弃两张牌令此"上课点名"依然造成伤害？',
              options:[{key:'yes',label:'发动（弃两张牌）'},{key:'no',label:'放弃'}], skillBlock:true });
            if (r.option === 'yes'){
              const sel = await Ask(user, { kind:'selectCards', prompt:'【红笔】弃置两张牌', from:'any', min:2, max:2 });
              if (sel.cards && sel.cards.length === 2){
                payCards(user, sel.cards);
                log(user.name + ' 发动【红笔】，伤害照常结算！', 'sys');
                dodged = false;
              }
            }
          }
        }
        // 戒尺：被代课抵消时可再使用一张上课点名（每回合限一次）
        if (dodged && user.equips.weapon && user.equips.weapon.name === '戒尺' && isPointCard(card)
            && !skillUsed(user, '戒尺') && user.hand.some(c => c.name === '上课点名')){
          const r = await Ask(user, { kind:'choice', prompt:'【戒尺】是否对 ' + target.name + ' 再使用一张"上课点名"？',
            options:[{key:'yes',label:'发动'},{key:'no',label:'放弃'}], skillBlock:true });
          if (r.option === 'yes'){
            const sel = await Ask(user, { kind:'selectCards', prompt:'【戒尺】选择一张上课点名', from:'self', min:1, max:1, filter:c => c.name === '上课点名' });
            if (sel.cards && sel.cards.length){
              markSkillUsed(user, '戒尺');
              await useCard(user, sel.cards[0], [target]);
            }
          }
        }
      }
    }
  }
  if (dodged){
    log(card.name + ' 被 ' + target.name + ' 抵消', 'sys');
    // 老湖人【快攻】：点名类牌被代课抵消时补两张（每回合限一次）
    if (isPointCard(card) && hasSkill(user, '快攻') && !skillUsed(user, '快攻')){
      markSkillUsed(user, '快攻');
      log('【快攻】：' + user.name + ' 的点名被挡下，摸两张牌', 'sys');
      await drawCards(user, 2, '快攻');
    }
    return;
  }
  // 教鞭：造成伤害时可改为弃目标两张牌
  if (user.equips.weapon && user.equips.weapon.name === '教鞭' && isPointCard(card)){
    const z = allZoneCards(target).filter(x => x.zone !== 'hand' || canBeHandTargeted(target));
    if (z.length){
      const r = await Ask(user, { kind:'choice', prompt:'【教鞭】是否防止此伤害，改为弃置 ' + target.name + ' 两张牌？',
        options:[{key:'yes',label:'发动'},{key:'no',label:'放弃'}], skillBlock:true });
      if (r.option === 'yes'){
        const take = Math.min(2, z.length);
        for (let i=0;i<take;i++){
          const zz = allZoneCards(target).filter(x => x.zone !== 'hand' || canBeHandTargeted(target));
          if (!zz.length) break;
          const chosen = await chooseZoneCard(user, target, zz, '【教鞭】弃置 ' + target.name + ' 一张牌');
          if (!chosen) break;
          removeFromZone(target, chosen);
          toDiscard(chosen);
          log(user.name + ' 弃置了 ' + target.name + ' 的 ' + cardText(chosen), '');
          if (chosen.name === '医保卡') await heal(target, 1, '失去医保卡');
        }
        return;
      }
    }
  }
  // 伤害计算 —— 点名类牌三者统一（火杀/雷杀也是"杀"）
  let dmg = 1;
  if (isPointCard(card)){
    if (hasSkill(user,'热血') && !user.hotUsed && !opts.noHot) { dmg++; user.hotUsed = true; log(user.name + ' 发动【热血】，伤害+1', 'sys'); }
    if (user.marks.buff > 0){ user.marks.buff--; dmg++; log('红牛增益生效，伤害+1（剩余 ' + user.marks.buff + ' 层）', 'sys'); }
    if (user.equips.weapon && user.equips.weapon.name === '红头文件' && target.hand.length === 0){ dmg++; log('【红头文件】生效，伤害+1', 'sys'); }
  }
  // 激光笔
  if (user.equips.weapon && user.equips.weapon.name === '激光笔' && isPointCard(card)){
    const opposite = isOppositeSex(user, target);
    if (opposite){
      const r = await Ask(target, { kind:'choice', prompt:'【激光笔】' + user.name + ' 指定了你，请选择：弃一张手牌，或让其摸一张牌',
        options:[{key:'discard',label:'弃一张手牌'},{key:'draw',label:'让 ' + user.name + ' 摸一张牌'}] });
      if (r.option === 'draw'){ await drawCards(user, 1, '激光笔'); }
      else if (target.hand.length){
        const sel = await Ask(target, { kind:'selectCards', prompt:'【激光笔】弃置一张手牌', from:'self', min:1, max:1 });
        if (sel.cards && sel.cards.length) discardFromHand(target, sel.cards);
      }
    }
  }
  const dealt = await damage(target, dmg, user, card.dmg || 'normal', { ignoreArmor });
  // 监控摄像头：+1 / −1 是两个独立栏位，两匹都在时由使用者挑一匹
  if (dealt > 0 && user.equips.weapon && user.equips.weapon.name === '监控摄像头' && target.alive){
    const mounts = ['mountUp', 'mountDown'].filter(k => target.equips[k]);
    if (mounts.length){
      let slot = mounts[0];
      if (mounts.length > 1){
        // 两匹都有：让使用者选（改双栏位之前只有一匹，不存在这个选择）
        const m0 = target.equips[mounts[0]], m1 = target.equips[mounts[1]];
        const r2 = await Ask(user, { kind:'choice',
          prompt:'【监控摄像头】弃置 ' + target.name + ' 的哪一匹坐骑？',
          options:[{key:mounts[0], label:'弃 ' + m0.name + '（' + CARDS[m0.name].mount + ' 坐骑）'},
                   {key:mounts[1], label:'弃 ' + m1.name + '（' + CARDS[m1.name].mount + ' 坐骑）'},
                   {key:'no', label:'放弃'}], skillBlock:true });
        if (r2.option === 'no' || !r2.option) return;
        slot = r2.option;
      } else {
        const r = await Ask(user, { kind:'choice',
          prompt:'【监控摄像头】是否弃置 ' + target.name + ' 的坐骑 ' + target.equips[slot].name + '？',
          options:[{key:'yes',label:'弃置'},{key:'no',label:'放弃'}], skillBlock:true });
        if (r.option !== 'yes') return;
      }
      const m = target.equips[slot]; target.equips[slot] = null; toDiscard(m);
      log(user.name + ' 弃置了 ' + target.name + ' 的 ' + m.name, 'sys');
      if (m.name === '医保卡') await heal(target, 1, '失去医保卡');
    }
  }
}
function isOppositeSex(a, b){
  const A = SEX[a.char.name], B = SEX[b.char.name];
  if (!A || !B) return true;
  if (A === 'other' || B === 'other') return true;
  return A !== B;
}
/* 性别表（激光笔按它判定"异性"）。
 * 值只认 '男' / '女' / 'other' 三种；写成 'other' 的等于**恒定算作异性**。
 * 新增角色必须补进这张表，否则 selftest 会红。 */
const SEX = { '李心瑶':'女','宋美丽':'女','夜露':'女','奶扣':'女',
  '周志远':'男','王磊':'男','董昌程':'男','史鉴明':'男','数学郭':'男','肾小球':'男','钓鱼老':'男',
  '董旭':'男','董启龙':'男','王三金':'男','方三水':'男','虎爷':'男','京爷':'男','鸟爷':'男','波比':'男','董伦':'男',
  // 超开心是吉祥物，没有性别设定 —— 'other' 让它对谁都算异性
  '超开心':'other',
  // 牢师包
  'Tania':'女','Hogo':'男','韩鹏':'男','李岩':'女','孩子':'other','亨利':'男','张金雪':'女',
  // 第一包（英文名进的是称号，姓名保持中文 —— 中文名字才不会打坏 AI 的按名找人）
  '馒头':'other','老猫':'男','老姜':'男','老瓶':'男','老湖人':'男','老石':'男','老虎':'男','黄熊':'男','西鱼':'男' };

/* ---------------- 其他牌的效果 ---------------- */
async function resolveDismantle(user, target){
  if (!target) return;
  const z = allZoneCards(target).filter(x => x.zone !== 'hand' || canBeHandTargeted(target));
  if (!z.length) return;
  const chosen = await chooseZoneCard(user, target, z, '【通报批评】选择要弃置的牌');
  if (!chosen) return;
  removeFromZone(target, chosen); toDiscard(chosen);
  log(user.name + ' 弃置了 ' + target.name + ' 的 ' + cardText(chosen), 'sys');
  if (chosen.name === '医保卡') await heal(target, 1, '失去医保卡');
}
async function resolveSnatch(user, target){
  if (!target) return;
  const z = allZoneCards(target).filter(x => x.zone !== 'hand' || canBeHandTargeted(target));
  if (!z.length) return;
  const chosen = await chooseZoneCard(user, target, z, '【抄作业】选择要获得的牌');
  if (!chosen) return;
  removeFromZone(target, chosen);
  user.hand.push(chosen);
  log(user.name + ' 获得了 ' + target.name + ' 的 ' + cardText(chosen), 'sys');
  if (chosen.name === '医保卡') await heal(target, 1, '失去医保卡');
}
async function resolveDuel(user, target){
  if (!target) return;
  log('【课堂辩论】开始：由 ' + target.name + ' 先打出"上课点名"', 'sys');
  let attacker = target, defender = user;
  while (true){
    if (!attacker.alive){ return; }
    const card = attacker.hand.find(c => c.name === '上课点名');
    if (!card){
      log(attacker.name + ' 无法打出"上课点名"，受到 1 点伤害', 'dmg');
      await damage(attacker, 1, defender, 'normal');
      return;
    }
    let play = false;
    if (attacker.isHuman || true){
      const r = await Ask(attacker, { kind:'choice', prompt:'【课堂辩论】是否打出"上课点名"？（不出则受 1 点伤害）',
        options:[{key:'yes',label:'打出上课点名'},{key:'no',label:'不出（受伤）'}], skillBlock:true });
      play = r.option === 'yes';
    }
    if (!play){
      await damage(attacker, 1, defender, 'normal');
      return;
    }
    removeFromHand(attacker, [card]); toDiscard(card);
    log(attacker.name + ' 打出 ' + cardText(card), '');
    [attacker, defender] = [defender, attacker];
  }
}
async function resolveAoe(user, card){
  const targets = others(user).slice();
  for (const t of targets){
    if (!t.alive) continue;
    // 群体牌对**每个目标**单独开放一次辅导员签字 ——
    // 抵消掉某一个目标的结算，不影响其他目标（规则书：仅能抵消对某一目标的结算）
    if (await nullifyCheck(user, card, { target: t })){
      log('【' + card.name + '】对 ' + t.name + ' 的结算被辅导员签字抵消', 'sys');
      if (window.UI) UI.render();
      continue;
    }
    if (isImmuneByCard(t, card, user)){ log(t.name + ' 的防具令 ' + card.name + ' 无效', 'sys'); continue; }
    // 炫富
    if (flexReady(t) && t.hand.length > 0){
      const r = await Ask(t, { kind:'choice', prompt:'【炫富】' + user.name + ' 使用了 ' + card.name + '，是否取消对你的结算？',
        options:[{key:'yes',label:'发动【炫富】'},{key:'no',label:'放弃'}], skillBlock:true });
      if (r.option === 'yes'){
        const sel = await Ask(t, { kind:'selectCards', prompt:'【炫富】弃置一张牌', from:'self', min:1, max:1 });
        if (sel.cards && sel.cards.length){ discardFromHand(t, sel.cards); markFlex(t);
          await drawCards(user, 1, '炫富'); log(t.name + ' 发动【炫富】取消了自己的结算', 'sys'); continue; }
      }
    }
    if (card.need === '代课'){
      if (t.dodgeBan){ log(t.name + ' 不能使用代课', 'sys'); }
      else {
        const res = await askResponse('代课', t, '【' + card.name + '】是否打出代课？', { onlyTarget:true });
        if (res){
          const negated = (res.via === 'card' || res.via === '波比跳') ? await tryDibel(t, user) : false;
          if (!negated){ log(t.name + ' 打出代课，化解了 ' + card.name, 'sys'); continue; }
        }
      }
      await damage(t, 1, user, card.dmg || 'normal');
    } else {
      const need = t.hand.find(c => c.name === card.need);
      if (need){
        const r = await Ask(t, { kind:'choice', prompt:'【' + card.name + '】是否打出"上课点名"化解？',
          options:[{key:'yes',label:'打出上课点名'},{key:'no',label:'不出（受1点伤害）'}], skillBlock:true });
        if (r.option === 'yes'){ removeFromHand(t, [need]); toDiscard(need); log(t.name + ' 打出 ' + cardText(need) + ' 化解', ''); continue; }
      } else {
        log(t.name + ' 没有"上课点名"', 'sys');
      }
      await damage(t, 1, user, card.dmg || 'normal');
    }
  }
}
async function resolveRelay(user, target){
  if (!target || !target.equips.weapon) return;
  const w = target.equips.weapon;
  // 指定第三名角色（在目标的攻击范围内且非目标自己）
  const cand = alivePlayers().filter(p => p !== target && distance(target, p) <= CARDS[w.name].range);
  if (!cand.length){ log('无可指定的第三方，' + user.name + ' 直接获得武器', 'sys'); gainWeapon(user, target); return; }
  const third = (user.isHuman)
    ? (await Ask(user, { kind:'selectTargets', prompt:'【点名接力】指定被点名的第三者', targets:cand, min:1, max:1 })).targets[0]
    : await window.AI.pickTarget(user, cand, 'relay');
  if (!third){ log('未指定目标，结算中止', 'sys'); return; }
  const hasPoint = target.hand.some(c => c.name === '上课点名');
  let doIt = false;
  if (hasPoint){
    const r = await Ask(target, { kind:'choice',
      prompt:'【点名接力】' + user.name + ' 要求你对 ' + third.name + ' 使用"上课点名"，否则其获得你的武器（' + w.name + '）',
      options:[{key:'yes',label:'执行（使用上课点名）'},{key:'no',label:'拒绝（失去武器）'}] });
    doIt = r.option === 'yes';
  } else {
    log(target.name + ' 手中没有"上课点名"，无法执行', 'sys');
  }
  if (doIt){
    const card = target.hand.find(c => c.name === '上课点名');
    await useCard(target, card, [third]);
  } else {
    gainWeapon(user, target);
  }
}
function gainWeapon(user, target){
  const w = target.equips.weapon;
  if (!w) return;
  target.equips.weapon = null;
  const old = user.equips.weapon;
  user.equips.weapon = w;
  if (old){ toDiscard(old); }
  log(user.name + ' 获得了 ' + target.name + ' 的武器 ' + w.name, 'sys');
  if (window.UI) UI.render();
}
async function resolveHarvest(user){
  const X = alivePlayers().length;
  const shown = [];
  for (let i=0;i<X;i++){ const c = drawFromDeck(); if (c) shown.push(c); }
  log('【小组作业】亮出：' + shown.map(cardText).join('、'), 'sys');
  const order = orderFrom(user.seat);
  for (const p of order){
    if (!shown.length) break;
    let idx = 0;
    if (p.isHuman && window.UI){
      const sel = await Ask(p, { kind:'selectCards', prompt:'【小组作业】选择一张牌获得', cards:shown, min:1, max:1 });
      const c = sel.cards && sel.cards[0];
      idx = shown.indexOf(c); if (idx < 0) idx = 0;
    } else {
      idx = (await window.AI.pickShown(p, shown)) || 0;
    }
    const got = shown.splice(idx,1)[0];
    p.hand.push(got);
    log(p.name + ' 选择了 ' + cardText(got), '');
  }
  toDiscard(shown);
}
async function resolveFireTalk(user, target){
  if (!target || !target.hand.length) return;
  let shownCard;
  if (target.isHuman && window.UI){
    const sel = await Ask(target, { kind:'selectCards', prompt:'【当面约谈】展示一张手牌', from:'self', min:1, max:1, reveal:true });
    shownCard = sel.cards && sel.cards[0];
  } else {
    shownCard = pickRandom(target.hand);
  }
  if (!shownCard) return;
  log(target.name + ' 展示了 ' + cardText(shownCard), 'sys');
  const same = user.hand.filter(c => c.suit === shownCard.suit);
  if (!same.length){ log(user.name + ' 没有同花色手牌，无法造成伤害', 'sys'); return; }
  const r = await Ask(user, { kind:'choice', prompt:'是否弃一张同花色（' + D.suitOf(shownCard).sym + '）手牌造成 1 点火焰伤害？',
    options:[{key:'yes',label:'弃牌并造成伤害'},{key:'no',label:'放弃'}], skillBlock:true });
  if (r.option !== 'yes') return;
  const sel = await Ask(user, { kind:'selectCards', prompt:'弃置一张同花色手牌', from:'self', min:1, max:1, filter:c => c.suit === shownCard.suit });
  if (!sel.cards || !sel.cards.length) return;
  discardFromHand(user, sel.cards);
  await damage(target, 1, user, 'fire');
}
async function resolveChain(user, targets){
  // 重铸在出牌阶段由 UI 提供"重铸"选项；此处处理横置/重置
  for (const t of (targets||[])){
    if (!t) continue;
    t.chained = !t.chained;
    log(t.name + ' 被' + (t.chained ? '横置' : '重置'), 'sys');
  }
  if (window.UI) UI.render();
}

/* ---------------- 辅导员签字 ---------------- */
async function nullifyCheck(user, card, opts){
  opts = opts || {};
  // 提示语要说清楚"抵消的是什么"，不然群体牌逐个询问时人分不清在问哪个目标
  const what = opts.target ? (user.name + ' 对 ' + opts.target.name + ' 的【' + card.name + '】')
             : opts.judge  ? ('即将生效的【' + card.name + '】')
             :               (user.name + ' 的【' + card.name + '】');
  let layer = 0;
  let nullified = false;
  while (layer < 3){
    const order = orderFrom(G.turnSeat);
    let played = false;
    for (const p of order){
      if (!p.alive) continue;
      const has = p.hand.some(c => c.name === '辅导员签字');
      if (!has) continue;
      const r = await Ask(p, { kind:'choice',
        prompt:'是否使用【辅导员签字】' + (nullified ? '（救援·再抵消）' : '') + '抵消 ' + what + '？',
        options:[{key:'yes',label:'使用辅导员签字'},{key:'no',label:'放弃'}], skillBlock:true,
        meta:{ cardName: card.name, caster: user.seat } });
      if (r.option === 'yes'){
        const c = p.hand.find(x => x.name === '辅导员签字');
        removeFromHand(p, [c]); toDiscard(c);
        log(p.name + ' 使用【辅导员签字】' + (nullified ? '再次抵消' : '抵消了 ' + card.name), 'sys');
        if (window.FX) FX.addToExchange(p.name, c, '', { response:true, tag: nullified ? '再抵消' : '无效化', sfx:'dodge' });
        // 韩鹏【批示】：打出辅导员签字就补两张。这里同时覆盖"抵消"和"再抵消"
        if (hasSkill(p, '批示')) await drawCards(p, 2, '批示');
        nullified = !nullified;
        played = true;
        break;
      }
    }
    if (!played) break;
    layer++;
  }
  return nullified;
}
async function triggerRenmai(user){
  for (const p of orderFrom(G.turnSeat)){
    if (!p.alive) continue;
    if (!hasSkill(p, '人脉') || skillUsed(p, '人脉')) continue;
    if (p.hand.length === 0) continue;
    const r = await Ask(p, { kind:'choice', prompt:'【人脉】' + user.name + ' 使用了事件牌，是否弃一张牌令其额外摸一张？',
      options:[{key:'yes',label:'发动'},{key:'no',label:'放弃'}], skillBlock:true });
    if (r.option === 'yes'){
      const sel = await Ask(p, { kind:'selectCards', prompt:'【人脉】弃置一张牌', from:'self', min:1, max:1 });
      if (sel.cards && sel.cards.length){
        discardFromHand(p, sel.cards); markSkillUsed(p, '人脉');
        await drawCards(user, 1, '人脉');
      }
    }
    break;
  }
}

/* ---------------- 费用支付工具 ---------------- */
function countPayable(p){
  let n = p.hand.length;
  D.EQUIP_SLOTS.forEach(k => { if (p.equips[k]) n++; });
  return n;
}
function payCards(p, cards){
  cards.forEach(c => {
    if (p.hand.includes(c)) discardFromHand(p, [c]);
    else { removeFromZone(p, c); toDiscard(c); log(p.name + ' 弃置了装备区的 ' + cardText(c), ''); }
  });
}
/** 让玩家在目标区域内选一张牌（手牌随机不可指定） */
async function chooseZoneCard(chooser, target, zoneCards, prompt){
  const handZone = zoneCards.filter(z => z.zone === 'hand');
  const tableZone = zoneCards.filter(z => z.zone !== 'hand');
  if (tableZone.length && !handZone.length){
    const list = tableZone.map(z => z.card);
    const sel = await Ask(chooser, { kind:'selectCards', prompt:prompt + '（' + target.name + '）', cards:list, min:1, max:1, owner:target });
    return (sel.cards && sel.cards[0]) || list[0];
  }
  if (handZone.length && !tableZone.length){
    return pickRandom(handZone).card;
  }
  // 两者都有：先选手牌区还是装备/通知栏
  const r = await Ask(chooser, { kind:'choice', prompt:prompt + '：选择区域（' + target.name + '）',
    options:[{key:'hand', label:'手牌区（随机一张）'}, {key:'table', label:'装备区/通知栏（可指定）'}] });
  if (r.option === 'table'){
    const list = tableZone.map(z => z.card);
    const sel = await Ask(chooser, { kind:'selectCards', prompt:prompt, cards:list, min:1, max:1, owner:target });
    return (sel.cards && sel.cards[0]) || list[0];
  }
  return pickRandom(handZone).card;
}

/* =========================================================
 *  主动技实现
 * ========================================================= */
const SKILLS = {
  /* R-01 */
  async 吹牛(p){
    const names = Object.keys(CARDS);
    let name;
    if (p.isHuman && window.UI){
      const r = await Ask(p, { kind:'selectOption', prompt:'【吹牛】宣言一种牌名', options:names.map(n => ({key:n, label:n})) });
      name = r.option;
    } else name = pickRandom(names);
    const drawn = await drawCards(p, 1, '吹牛');
    if (!drawn.length) return;
    const c = drawn[0];
    log(p.name + ' 宣言【' + name + '】，亮出 ' + cardText(c), 'sys');
    if (c.name !== name){
      p.pointBan = true;
      log('未宣言中：' + p.name + ' 本回合不能使用"上课点名"', 'dmg');
    } else {
      log('宣言命中！', 'sys');
    }
  },
  /* R-02 */
  async 挂科(p, targets){
    const t = targets[0];
    if (!t) return;
    log(p.name + ' 发动【挂科】指定 ' + t.name, 'sys');
    await damage(t, 1, p, 'normal');
    if (t.alive) await drawCards(t, 1, '挂科的补偿');
  },
  /* R-03 */
  async 系统(p, targets){ await viewAndDiscard(p, targets[0]); },
  /* R-04 */
  async 奉承(p, targets){
    const t = targets[0]; if (!t) return;
    const sel = await Ask(p, { kind:'selectCards', prompt:'【奉承】选择一张手牌交给 ' + t.name, from:'self', min:1, max:1 });
    if (!sel.cards || !sel.cards.length) return;
    removeFromHand(p, sel.cards); t.hand.push(sel.cards[0]);
    log(p.name + ' 交给 ' + t.name + ' 一张手牌', 'sys');
    await drawCards(p, 2, '奉承');
  },
  async 施压(p, targets){
    const t = targets[0]; if (!t) return;
    t.dodgeBan = true;
    log(p.name + ' 发动【施压】指定 ' + t.name + '，其本回合不能使用代课', 'sys');
    await damage(t, 1, p, 'normal');
  },
  /* R-05 */
  async 解密(p, targets){
    const t = targets[0]; if (!t || !t.hand.length) return;
    const sel = await Ask(p, { kind:'selectCards', prompt:'【解密】弃置一张牌', from:'any', min:1, max:1 });
    if (!sel.cards || !sel.cards.length) return;
    payCards(p, sel.cards);
    const got = pickRandom(t.hand);
    removeFromHand(t, [got]); p.hand.push(got);
    // 规则书：【解密】是"背面洗混随机抽取"，只有抽的人知道抽到了什么
    log(p.name + ' 发动【解密】，获得 ' + t.name + ' 一张手牌：' + cardText(got), 'sys',
        [p.seat], p.name + ' 发动【解密】，获得 ' + t.name + ' 一张手牌');
  },
  /* R-06 */
  async 概率(p){
    const jc = drawFromDeck(); if (!jc) return;
    log(p.name + ' 发动【概率】查考勤：' + cardText(jc), 'sys');
    toDiscard(jc);
    // 平衡调整：原来黑色是"弃一张手牌"，EV 只有 +0.48 张，而且一半概率是倒贴 ——
    // 3 血角色最需要牌来防守。现在黑色也摸一张，只是比红色少：
    // 随机性保留（"查考勤决定收益多少"），负收益去掉。
    if (D.isRedCard(jc)) await drawCards(p, 2, '概率');
    else await drawCards(p, 1, '概率');
  },
  /* R-07 */
  async 共情(p, targets){
    // 平衡调整：只能治疗**其他**角色。原来能自奶还白摸一张，
    // 是奶扣【治愈】（要弃一张牌才能回复 1 点）的严格上位替代。
    const t = targets[0];
    if (!t || t === p) return;
    await heal(t, 1, '共情', p);
    await drawCards(p, 1, '共情');
  },
  /* R-08 */
  async 透析(p, targets){
    if (countPayable(p) < 2) return;
    const t = targets[0] || p;
    const sel = await Ask(p, { kind:'selectCards', prompt:'【透析】弃置两张牌', from:'any', min:2, max:2 });
    if (!sel.cards || sel.cards.length < 2) return;
    payCards(p, sel.cards);
    await heal(t, 1, '透析', p);
    await drawCards(t, 1, '透析');
  },
  /* R-09 */
  async 垂钓(p){
    const sel = await Ask(p, { kind:'selectCards', prompt:'【垂钓】将一张手牌置于牌堆顶', from:'self', min:1, max:1 });
    if (!sel.cards || !sel.cards.length) return;
    removeFromHand(p, sel.cards);
    G.deck.push(sel.cards[0]);
    log(p.name + ' 将一张手牌置于牌堆顶', 'sys');
    await drawCards(p, 2, '垂钓');
  },
  /* R-10 */
  async 窃听(p, targets){ await viewAndDiscard(p, targets[0]); },
  /* R-11 */
  async 冲锋(p, targets){
    const t = targets[0]; if (!t) return;
    const sel = await Ask(p, { kind:'selectCards', prompt:'【冲锋】弃置一张牌', from:'any', min:1, max:1 });
    if (!sel.cards || !sel.cards.length) return;
    payCards(p, sel.cards);
    log(p.name + ' 发动【冲锋】，视为使用"上课点名"', 'sys');
    if (window.FX) FX.addToExchange(p.name, { name:'上课点名', suit:null }, '→ ' + t.name, { tag:'【冲锋】视为使用' });
    p.usedAttackCardThisPhase++;
    p.usedPoint = true;
    await resolveAttackOne(p, { name:'上课点名', kind:'attack', dmg:'normal', _virtual:true }, t);
  },
  /* R-12 */
  async 龙吟(p, targets){
    const t = targets[0]; if (!t) return;
    t.dodgeBan = true;
    await drawCards(t, 1, '龙吟');
    log(p.name + ' 发动【龙吟】：' + t.name + ' 摸一张牌，本回合不能使用代课', 'sys');
  },
  /* R-13 */
  async 氪金(p){
    if (countPayable(p) < 2) return;
    const sel = await Ask(p, { kind:'selectCards', prompt:'【氪金】弃置两张牌', from:'any', min:2, max:2 });
    if (!sel.cards || sel.cards.length < 2) return;
    payCards(p, sel.cards);
    const dig = [];
    while (true){
      const c = drawFromDeck();
      if (!c) break;
      if (c.type === 'equip'){
        p.hand.push(c);
        log(p.name + ' 发动【氪金】，亮出 ' + dig.length + ' 张后获得装备：' + cardText(c), 'sys');
        break;
      }
      dig.push(c);
      if (dig.length > 30) break;
    }
    toDiscard(dig);
  },
  /* R-14 */
  async 划水(p, targets){
    const t = targets[0]; if (!t) return;
    const sel = await Ask(p, { kind:'selectCards', prompt:'【划水】交给 ' + t.name + ' 一张手牌', from:'self', min:1, max:1 });
    if (!sel.cards || !sel.cards.length) return;
    removeFromHand(p, sel.cards); t.hand.push(sel.cards[0]);
    p.marks.noTargetBy = t.seat;   // t 不能对 p 用牌
    p.marks.noTargetTurn = G.turnId;
    // 记录在 t 上更便于校验：t 不能以 p 为目标
    t.marks.slideFrom = p.seat;
    t.marks.slideTurn = G.turnId;
    log(p.name + ' 发动【划水】：' + t.name + ' 本回合不能对 ' + p.name + ' 使用牌', 'sys');
    // 平衡调整：原来交出一张牌换来的只是"一个人本回合不打你"，净亏一张。
    // 补一张牌，让这次交换不亏手牌 —— 技能的意义变成"用一张牌换一回合的安全"。
    await drawCards(p, 1, '划水');
  },
  /* R-15 */
  async 查寝(p, targets){
    const t = targets[0]; if (!t) return;
    if (!canBeHandTargeted(t)){ log('【加密】令【查寝】无法发动', 'sys'); return; }
    // 【查寝】的"观看手牌"只给发动者看，不能发给全场
    log(p.name + ' 观看 ' + t.name + ' 的手牌：' + t.hand.map(cardText).join('、'), 'sys',
        [p.seat], p.name + ' 观看了 ' + t.name + ' 的手牌');
    const eq = t.hand.filter(c => c.type === 'equip');
    if (!eq.length){ log(t.name + ' 手中没有装备牌', 'sys'); return; }
    const sel = await Ask(p, { kind:'selectCards', prompt:'【查寝】弃置 ' + t.name + ' 一张装备牌', cards:eq, min:1, max:1, owner:t });
    if (sel.cards && sel.cards.length) discardFromHand(t, sel.cards);
  },
  /* R-16 */
  async 侃山(p, targets){
    const t = targets[0];
    if (!t || !t.hand.length || !p.hand.length) return;
    const mine = p.isHuman ? (await Ask(p, { kind:'selectCards', prompt:'【侃山】选择一张手牌拼绩点', from:'self', min:1, max:1 })).cards[0] : pickRandom(p.hand);
    const his = t.isHuman ? (await Ask(t, { kind:'selectCards', prompt:'【侃山】选择一张手牌拼绩点', from:'self', min:1, max:1 })).cards[0] : pickRandom(t.hand);
    if (!mine || !his) return;
    log('拼绩点：' + p.name + ' ' + cardText(mine) + '（' + D.cardPoint(mine) + '） vs ' + t.name + ' ' + cardText(his) + '（' + D.cardPoint(his) + '）', 'sys');
    if (D.cardPoint(mine) > D.cardPoint(his)){ log(p.name + ' 赢下拼绩点', 'sys'); await drawCards(p, 2, '侃山'); }
    else { log(t.name + ' 赢下拼绩点（平点视为发起方输）', 'sys'); await drawCards(t, 1, '侃山'); }
  },
  /* R-17 */
  async 撒娇(p, targets){
    const t = targets[0];
    if (!t || !t.hand.length) return;
    let give;
    if (t.isHuman && window.UI){
      const sel = await Ask(t, { kind:'selectCards', prompt:'【撒娇】' + p.name + ' 要求你交给其一张手牌', from:'self', min:1, max:1 });
      give = sel.cards && sel.cards[0];
    } else give = pickRandom(t.hand);
    if (!give) return;
    removeFromHand(t, [give]); p.hand.push(give);
    log(t.name + ' 交给 ' + p.name + ' 一张手牌', 'sys');
    if (p.hand.length > 1){
      const sel = await Ask(p, { kind:'selectCards', prompt:'【撒娇】交给 ' + t.name + ' 一张手牌', from:'self', min:1, max:1 });
      if (sel.cards && sel.cards.length){ removeFromHand(p, sel.cards); t.hand.push(sel.cards[0]);
        log(p.name + ' 交给 ' + t.name + ' 一张手牌', 'sys'); }
      // 平衡调整：交换本身是零收益（而且人类目标会把最差的牌给你），3 血角色很快打光手牌。
      // 补一张牌，让【撒娇】每回合净 +1 张，和宋美丽【共情】同一档。
      await drawCards(p, 1, '撒娇');
    }
  },
  async 治愈(p, targets){
    const t = targets[0] || p;
    const sel = await Ask(p, { kind:'selectCards', prompt:'【治愈】弃置一张牌', from:'any', min:1, max:1 });
    if (!sel.cards || !sel.cards.length) return;
    payCards(p, sel.cards);
    await heal(t, 1, '治愈', p);
  },
  /* R-18 */
  async 鸽王(p, targets){
    const t = targets[0]; if (!t) return;
    const sel = await Ask(p, { kind:'selectCards', prompt:'【鸽王】弃置一张手牌', from:'self', min:1, max:1 });
    if (!sel.cards || !sel.cards.length) return;
    discardFromHand(p, sel.cards);
    t.marks.pigeon = 1;
    log(p.name + ' 发动【鸽王】：' + t.name + ' 下一个摸牌阶段被跳过', 'sys');
  },
  /* R-20 */
  async 轮值(p){
    await drawCards(p, 1, '轮值');
    if (p.hand.length){
      const sel = await Ask(p, { kind:'selectCards', prompt:'【轮值】弃置一张手牌', from:'self', min:1, max:1 });
      if (sel.cards && sel.cards.length) discardFromHand(p, sel.cards);
    }
  },
  /* L-01 Tania */
  async 双语(p){
    const sel = await Ask(p, { kind:'selectCards', prompt:'【双语】弃置一张牌', from:'self', min:1, max:1 });
    if (!sel.cards || !sel.cards.length) return;
    discardFromHand(p, sel.cards);
    p.bilingual = true;      // 由 useCardInner 在本回合下一张点名类牌用掉时清除
    log(p.name + ' 发动【双语】：本回合下一张点名类牌可额外指定一名攻击范围内的角色', 'sys');
    if (window.UI) UI.render();
  },
  /* L-03 韩鹏 */
  async 分管(p, targets){
    const t = targets[0]; if (!t || !t.judge.length) return;
    const sel = await Ask(p, { kind:'selectCards', prompt:'【分管】弃置一张牌', from:'self', min:1, max:1 });
    if (!sel.cards || !sel.cards.length) return;
    discardFromHand(p, sel.cards);
    // 取最上面那张 —— 和查考勤的结算顺序（后进先出）保持一致
    const card = t.judge[t.judge.length - 1];
    t.judge.splice(t.judge.indexOf(card), 1);
    toDiscard([card]);
    log(p.name + ' 发动【分管】，拆掉了 ' + t.name + ' 通知栏里的【' + card.name + '】', 'sys');
    if (window.UI) UI.render();
  },
  /* L-04 李岩 */
  async 布施(p, targets){
    const t = targets[0]; if (!t) return;
    const sel = await Ask(p, { kind:'selectCards', prompt:'【布施】交给 ' + t.name + ' 一张手牌', from:'self', min:1, max:1 });
    if (!sel.cards || !sel.cards.length) return;
    removeFromHand(p, [sel.cards[0]]);
    t.hand.push(sel.cards[0]);
    log(p.name + ' 发动【布施】，交给 ' + t.name + ' 一张牌', 'sys');
    await heal(t, 1, '布施', p);
    if (window.UI) UI.render();
  },
  /* L-05 孩子 */
  async 打滚(p, targets){
    const t = targets[0]; if (!t || !t.hand.length) return;
    const sel = await Ask(p, { kind:'selectCards', prompt:'【打滚】弃置一张牌', from:'self', min:1, max:1 });
    if (!sel.cards || !sel.cards.length) return;
    discardFromHand(p, sel.cards);
    // 拒绝的代价必须**大于**给一张牌，否则理性的对手永远拒绝，
    // 这个技能就退化成"弃一张摸一张"（比【摆尾】还差）。所以拒绝是摸两张。
    const r = await Ask(t, { kind:'choice',
      prompt:'【打滚】' + p.name + ' 向你撒泼讨一张牌，是否给他？',
      options:[{key:'yes',label:'给一张'},{key:'no',label:'不给（对方摸两张）'}], skillBlock:true });
    if (r.option === 'yes'){
      const give = await Ask(t, { kind:'selectCards', prompt:'【打滚】交给 ' + p.name + ' 一张手牌', from:'self', min:1, max:1 });
      if (give.cards && give.cards.length){
        removeFromHand(t, [give.cards[0]]);
        p.hand.push(give.cards[0]);
        log(p.name + ' 发动【打滚】，' + t.name + ' 交出了一张手牌', 'sys');
      } else {
        await drawCards(p, 2, '打滚');   // 答应给却给不出（手牌被清空），按拒绝算
      }
    } else {
      log(p.name + ' 发动【打滚】，' + t.name + ' 不给，' + p.name + ' 摸两张牌', 'sys');
      await drawCards(p, 2, '打滚');
    }
    if (window.UI) UI.render();
  },
  /* L-06 亨利 */
  async 钞能力(p, targets){
    const t = targets[0]; if (!t) return;
    const eq = D.EQUIP_SLOTS.map(k => t.equips[k]).filter(Boolean);
    if (!eq.length) return;
    // 弃一张（原为两张）：探针跑 500 局，亨利连续两轮都是全场最弱（0.49 / 0.54，
    // 存活率 22% 全场垫底）。原因是他的两个技能都没有实感 —— 手牌上限 +2 在能正常
    // 出牌时几乎用不上，而唯一有威胁的【钞能力】代价重到 AI 很少值得用。
    const sel = await Ask(p, { kind:'selectCards', prompt:'【钞能力】弃置一张牌', from:'self', min:1, max:1 });
    if (!sel.cards || !sel.cards.length) return;
    discardFromHand(p, sel.cards);
    const removed = D.EQUIP_SLOTS.map(k => { const c = t.equips[k]; t.equips[k] = null; return c; }).filter(Boolean);
    toDiscard(removed);
    log(p.name + ' 发动【钞能力】，弃置了 ' + t.name + ' 装备区的 ' + removed.length + ' 张牌', 'sys');
    if (window.UI) UI.render();
  },
  /* L-07 张金雪 */
  async 铁面(p, targets){
    const t = targets[0]; if (!t) return;
    const sel = await Ask(p, { kind:'selectCards', prompt:'【铁面】弃置两张牌', from:'self', min:2, max:2 });
    if (!sel.cards || sel.cards.length < 2) return;
    discardFromHand(p, sel.cards);
    t.eventBan = true;
    log(p.name + ' 发动【铁面】：' + t.name + ' 本回合不能使用事件牌', 'sys');
    if (window.UI) UI.render();
  },
  /* 地主身份技 —— 不属于任何角色，靠 p.extraSkills 挂上去 */
  async 飞扬(p){
    const r = await Ask(p, { kind:'choice',
      prompt:'【飞扬】查考勤开始：是否弃两张牌，弃置你通知栏里的全部 ' + p.judge.length + ' 张牌？',
      options:[{key:'yes',label:'发动（弃两张牌）'},{key:'no',label:'放弃'}], skillBlock:true });
    if (r.option !== 'yes') return;
    const sel = await Ask(p, { kind:'selectCards', prompt:'【飞扬】弃置两张牌', from:'self', min:2, max:2 });
    if (!sel.cards || sel.cards.length < 2) return;
    discardFromHand(p, sel.cards);
    const z = p.judge.splice(0);
    toDiscard(z);
    log(p.name + ' 发动【飞扬】，弃置了通知栏里的 ' + z.length + ' 张牌', 'sys');
    if (window.UI) UI.render();
  },
  /* P-01 馒头 */
  async 管饱(p, targets){
    const t = targets[0]; if (!t) return;
    const sel = await Ask(p, { kind:'selectCards', prompt:'【管饱】弃置一张牌', from:'self', min:1, max:1 });
    if (!sel.cards || !sel.cards.length) return;
    discardFromHand(p, sel.cards);
    log(p.name + ' 发动【管饱】，喂了 ' + t.name + ' 一口', 'sys');
    await heal(t, 1, '管饱', p);
    await drawCards(t, 1, '管饱');
    if (window.UI) UI.render();
  },
  /* P-02 老猫 */
  async 爪子(p, targets){
    const t = targets[0]; if (!t || !t.hand.length) return;
    const sel = await Ask(p, { kind:'selectCards', prompt:'【爪子】弃置一张牌', from:'self', min:1, max:1 });
    if (!sel.cards || !sel.cards.length) return;
    discardFromHand(p, sel.cards);
    const i = Math.floor(Math.random() * t.hand.length);
    const c = t.hand[i];
    discardFromHand(t, [c]);
    log(p.name + ' 发动【爪子】，挠掉了 ' + t.name + ' 一张手牌', 'sys');
    if (window.UI) UI.render();
  },
  /* P-03 老姜 */
  async 老辣(p, targets){
    const t = targets[0]; if (!t) return;
    const sel = await Ask(p, { kind:'selectCards', prompt:'【老辣】弃置一张牌', from:'self', min:1, max:1 });
    if (!sel.cards || !sel.cards.length) return;
    discardFromHand(p, sel.cards);
    if (t.chained){
      // 已经横置了，横置没有意义 —— 改成补一刀（和超开心【起哄】拉开区别）
      log(p.name + ' 发动【老辣】：' + t.name + ' 已横置，改为造成 1 点伤害', 'sys');
      await damage(t, 1, p, 'normal');
    } else {
      t.chained = true;
      log(p.name + ' 发动【老辣】，横置 ' + t.name, 'sys');
      if (window.UI) UI.render();
    }
  },
  /* P-04 老瓶 */
  async 新酒(p){
    const sel = await Ask(p, { kind:'selectCards', prompt:'【新酒】弃置一张手牌', from:'self', min:1, max:1 });
    if (!sel.cards || !sel.cards.length) return;
    discardFromHand(p, sel.cards);
    if (!G.discard.length){ log('弃牌堆是空的，【新酒】无事发生', 'sys'); return; }
    const i = Math.floor(Math.random() * G.discard.length);
    const got = G.discard.splice(i, 1)[0];
    p.hand.push(got);
    log(p.name + ' 发动【新酒】，从弃牌堆取回一张牌', 'sys');
    if (window.UI) UI.render();
  },
  /* P-06 老石 */
  async 硬碰硬(p, targets){
    const t = targets[0]; if (!t) return;
    // 弃两张：原先只要一张，而它经常能打出 2 点 —— 那是全场最高伤害/代价比，
    // 平衡探针跑 500 局把它标成 1.65（全场最强，基础 20 人的上限是 1.57）
    const sel = await Ask(p, { kind:'selectCards', prompt:'【硬碰硬】弃置两张牌', from:'self', min:2, max:2 });
    if (!sel.cards || sel.cards.length < 2) return;
    discardFromHand(p, sel.cards);
    const big = t.hp > p.hp;
    log(p.name + ' 发动【硬碰硬】' + (big ? '（对方体力更高，伤害翻倍）' : ''), 'sys');
    await damage(t, big ? 2 : 1, p, 'normal');
  },
  /* P-07 老虎 */
  async 虎啸(p, targets){
    const sel = await Ask(p, { kind:'selectCards', prompt:'【虎啸】弃置一张牌', from:'self', min:1, max:1 });
    if (!sel.cards || !sel.cards.length) return;
    discardFromHand(p, sel.cards);
    const hit = alivePlayers().filter(t => t !== p && inAttackRange(p, t));
    hit.forEach(t => { t.dodgeBan = true; });
    log(p.name + ' 发动【虎啸】：' + (hit.length ? hit.map(t => t.name).join('、') + ' 本回合不能使用代课' : '范围内没有人'), 'sys');
    if (window.UI) UI.render();
  },
  /* P-08 黄熊 */
  async 拍(p, targets){
    const t = targets[0]; if (!t) return;
    const sel = await Ask(p, { kind:'selectCards', prompt:'【拍】弃置一张牌', from:'self', min:1, max:1 });
    if (!sel.cards || !sel.cards.length) return;
    discardFromHand(p, sel.cards);
    log(p.name + ' 发动【拍】', 'sys');
    await damage(t, 1, p, 'normal');
  },
  /* P-09 西鱼 */
  async 摆尾(p){
    await drawCards(p, 2, '摆尾');
    if (!p.hand.length) return;
    const sel = await Ask(p, { kind:'selectCards', prompt:'【摆尾】弃置一张手牌', from:'self', min:1, max:1 });
    if (sel.cards && sel.cards.length) discardFromHand(p, sel.cards);
  },
  /* R-21 */
  async 起哄(p, targets){
    const t = targets[0]; if (!t) return;
    const sel = await Ask(p, { kind:'selectCards', prompt:'【起哄】弃置一张牌', from:'self', min:1, max:1 });
    if (!sel.cards || !sel.cards.length) return;
    discardFromHand(p, sel.cards);
    // 直接置位而不是走 resolveChain：那个函数是**切换**，万一 skillTargets
    // 的过滤哪天被改坏了，切换会把已经横置的敌人**解除**横置（帮倒忙）。
    t.chained = true;
    log(p.name + ' 发动【起哄】，横置 ' + t.name, 'sys');
    if (window.UI) UI.render();
  }
};
async function viewAndDiscard(p, t){
  if (!t) return;
  if (!canBeHandTargeted(t)){ log('【加密】令该技能无法发动', 'sys'); return; }
  if (!t.hand.length){ log(t.name + ' 没有手牌', 'sys'); return; }
  // 【窃听】的"观看手牌"只给发动者看，不能发给全场
  log(p.name + ' 观看 ' + t.name + ' 的手牌：' + t.hand.map(cardText).join('、'), 'sys',
      [p.seat], p.name + ' 观看了 ' + t.name + ' 的手牌');
  const sel = await Ask(p, { kind:'selectCards', prompt:'选择弃置 ' + t.name + ' 一张手牌', cards:t.hand.slice(), min:1, max:1, owner:t });
  if (sel.cards && sel.cards.length){ discardFromHand(t, sel.cards); }
}

/* =========================================================
 *  回合流程
 * ========================================================= */
async function runTurn(p){
  G.turnId++;
  p.skillsUsedThisTurn = {};
  p.usedCardsThisTurn = [];
  p.usedAttackCardThisPhase = 0;
  p.damageDealtThisTurn = 0;
  p.dodgeBan = false;
  p.pointBan = false;
  p.eventBan = false;        // 张金雪【铁面】
  p.bilingual = false;       // Tania【双语】
  p.hotUsed = false;
  p.shuikeUsed = false;
  // （【过滤】现在是"每轮一次"，靠 marks.filterRound 记轮号自判，这里不用重置）
  // （【无私】【板书】这类"每回合一次"走的是 skillsUsedThisTurn，上面那行已统一清空）

  if (G.opts.hotseat) G.humanSeat = p.seat;
  p.skip = { draw:false, play:false, judge:false };
  p.usedDelayed = 0;
  if (window.UI){ UI.setPhase('start'); UI.render(); }
  logBig('—— ' + p.name + ' 的回合（第 ' + G.round + ' 轮）——');
  if (window.FX) await FX.turnBanner(p);

  await sleep(320);            // 每个阶段之间留出停顿

  /* 阶段 1：回合开始 */
  if (hasSkill(p, '轮值')){
    const r = await Ask(p, { kind:'choice', prompt:'【轮值】是否摸一张牌然后弃一张牌？',
      options:[{key:'yes',label:'发动'},{key:'no',label:'放弃'}], skillBlock:true });
    if (r.option === 'yes') await SKILLS.轮值(p);
  }
  await sleep(200);
  if (G.over) return;

  /* 阶段 2：查考勤 */
  if (UI) UI.setPhase('judge');
  await sleep(260);
  // 地主【飞扬】：必须在 judgePhase **之前** —— 它的语义是"查考勤开始时先清干净"，
  // 放到后面就等于清了个结算完的空壳。通知栏没牌时不用问。
  if (hasSkill(p, '飞扬') && p.judge.length) await SKILLS.飞扬(p);
  await judgePhase(p);
  if (G.over || !p.alive) return;

  /* 阶段 3：摸牌 */
  if (UI) UI.setPhase('draw');
  await sleep(260);
  if (p.marks.pigeon){ p.marks.pigeon = 0; log(p.name + ' 因【鸽王】跳过摸牌阶段', 'sys'); }
  else if (p.skip.draw) log(p.name + ' 跳过摸牌阶段', 'sys');
  else {
    // 基础 2 张 → 各形式自己改（2V2 的 1 号位第一回合只摸 1 张）→ 再由角色技能改
    let n = fmt().drawCount(p, 2);
    if (hasSkill(p, '扛')) n--;   // 黄熊：换来的是体力上限 +1，见 finalizeGame
    await drawCards(p, Math.max(0, n), '摸牌阶段');
  }
  if (G.over || !p.alive) return;

  /* 阶段 4：出牌 */
  if (UI) UI.setPhase('play');
  await sleep(260);
  if (p.skip.play){
    log(p.name + ' 跳过出牌阶段', 'sys');
    if (hasSkill(p, '水课') && !p.shuikeUsed){ p.shuikeUsed = true; log(p.name + ' 发动【水课】，摸两张牌', 'sys'); await drawCards(p, 2, '水课'); }
  } else {
    await playPhase(p);
    // 【水课】的两种触发情形：
    //   ① 出牌阶段被【设局】之类的效果终止（p.skip.play 变真）
    //   ② **自己一张牌都没出、一个技能都没用就结束了**
    // ②是平衡调整加上去的：原来这个技能只在被设局时才亮，等于没有。
    // 现在它变成一个每回合都能主动做的取舍 —— 要么正常出牌，要么"水一节课"换两张牌。
    const idle = (p.usedCardsThisTurn || []).length === 0 &&
                 Object.keys(p.skillsUsedThisTurn || {}).length === 0;
    if ((p.skip.play || idle) && hasSkill(p, '水课') && !p.shuikeUsed){
      p.shuikeUsed = true;
      log(p.name + ' 发动【水课】' + (p.skip.play ? '' : '（本回合没出手）') + '，摸两张牌', 'sys');
      await drawCards(p, 2, '水课');
    }
  }
  if (G.over || !p.alive) return;

  /* 阶段 5：弃牌 */
  if (UI) UI.setPhase('discard');
  await sleep(260);
  const limit = handLimit(p);
  if (p.hand.length > limit){
    const need = p.hand.length - limit;
    log(p.name + ' 需要弃置 ' + need + ' 张手牌（上限 ' + limit + '）', '');
    if (window.FX && !p.isHuman) FX.floatText(p.seat, '弃 ' + need + ' 张', 'draw');
    const sel = await Ask(p, { kind:'selectCards', prompt:'弃牌阶段：请弃置 ' + need + ' 张手牌', from:'self', min:need, max:need });
    if (sel.cards && sel.cards.length) discardFromHand(p, sel.cards);
    else { const auto = p.hand.slice(0, need); discardFromHand(p, auto); }
  }
  if (G.over || !p.alive) return;

  /* 阶段 6：回合结束 */
  if (UI) UI.setPhase('end');
  await sleep(240);
  await endTurn(p);
}

/** 回合结束阶段的收尾。抽成独立函数是为了能单独测（和 judgePhase 一个道理）。 */
async function endTurn(p){
  if (hasSkill(p, '摸鱼') && p.damageDealtThisTurn === 0) await drawCards(p, 1, '摸鱼');
  // 老瓶【旧瓶】：这一整个回合一张牌都没用过，摸两张。
  // usedCardsThisTurn 由 runTurn 开局清空、出牌时累加，判据比"没造成伤害"严格得多
  if (hasSkill(p, '旧瓶') && !(p.usedCardsThisTurn || []).length){
    log('【旧瓶】：' + p.name + ' 本回合未出牌，摸两张牌', 'sys');
    await drawCards(p, 2, '旧瓶');
  }
  p.marks.buff = 0;
  p.marks.pigeon = 0;
  p.marks.slideTurn = -1;
  p.marks.noTargetTurn = -1;
  await sleep(420);            // 回合之间留白，避免"刚看完就换人"
}

/**
 * 【论文查重】传给下一位存活角色。
 *
 * 两条路都走这里：判定没命中，和判定被辅导员签字抵消 ——
 * 两者都等于"这次没劈中"，而这张牌的身份就是热土豆，没劈中就得传下去。
 *
 * 规则书 6.5 说得明确：这个"移动"**不是"使用"** ——
 * 不触发"成为目标"类技能、不进响应窗口、也不能被再一张辅导员签字抵消。
 */
function passZhuancha(from, card, why){
  const alive = alivePlayers();
  const i = alive.indexOf(from);
  const next = alive[(i + 1) % alive.length];
  if (next && next !== from){
    next.judge.push(card);
    log((why ? why + '：' : '') + '论文查重移动到 ' + next.name + ' 的通知栏', 'sys');
  } else toDiscard([card]);
}

async function judgePhase(p){
  // 断网标记
  if (p.marks.net > 0){
    while (p.marks.net > 0){
      const jc = drawFromDeck();
      p.marks.net--;
      if (!jc) break;
      log('【宿舍断网】查考勤：' + cardText(jc), 'sys');
      toDiscard(jc);
      if (D.isBlackCard(jc)){
        p.skip.draw = true; p.skip.play = true;
        log('判定为黑色：跳过摸牌与出牌阶段', 'dmg');
      } else log('判定为红色：断网解除', 'sys');
    }
  }
  while (p.judge.length){
    if (!p.alive) return;
    const card = p.judge[p.judge.length - 1];   // 后进先出
    // 辅导员签字在**翻开抽签牌之前**问，而不是等看到结果再问 ——
    // 这就是闪电的规矩：无懈可击必须抢在判定牌翻开之前，翻开了就只剩改判窗口。
    // （"放置时也开放"那条规则书原来写过，按房规砍掉了，见修订 2。）
    // 注意问的时候还不知道会不会生效：问完才 drawFromDeck()。这是对的，别调换。
    if (await nullifyCheck(p, card, { judge: true })){
      const ni = p.judge.indexOf(card);
      if (ni >= 0) p.judge.splice(ni, 1);
      log('【' + card.name + '】被辅导员签字抵消，不进行查考勤', 'sys');
      if (card.name === '论文查重'){
        // 签字抵消掉的是"受到 3 点雷电伤害"**这一次判定**，不是这张牌本身。
        // 它的身份是热土豆：没劈中就该传给下家（规则书 5.3 F8'）。
        // 这里以前和别的延时牌一样直接弃掉 —— 等于把整张牌的存在感抹了。
        passZhuancha(p, card, '判定被抵消');
      } else {
        toDiscard([card]);
      }
      if (window.UI) UI.render();
      await sleep(200);
      continue;
    }
    const jc = drawFromDeck();
    if (!jc) return;
    log('查考勤：' + p.name + ' 的【' + card.name + '】→ 抽签牌 ' + cardText(jc), 'sys');
    if (window.FX) await FX.judge(card, jc);
    else { if (window.UI) UI.showJudge(card, jc); await sleep(600); }
    const idx = p.judge.indexOf(card);
    if (idx >= 0) p.judge.splice(idx, 1);
    if (card.name === '手机没电'){
      if (!(jc.suit === 'H')){ p.skip.play = true; log('判定不为红桃：' + p.name + ' 跳过出牌阶段', 'dmg'); }
      else log('判定为红桃：躲过', 'sys');
      toDiscard([card, jc]);
      // 【水课】的摸牌统一在出牌阶段被跳过时结算（避免重复触发）
    } else if (card.name === '饭卡没钱'){
      if (!(jc.suit === 'C')){ p.skip.draw = true; log('判定不为梅花：' + p.name + ' 跳过摸牌阶段', 'dmg'); }
      else log('判定为梅花：躲过', 'sys');
      toDiscard([card, jc]);
    } else if (card.name === '论文查重'){
      if (jc.suit === 'S' && jc.rank >= 2 && jc.rank <= 9){
        log('命中 ♠2-♠9：' + p.name + ' 受到 3 点雷电伤害', 'dmg');
        toDiscard([card, jc]);
        await damage(p, 3, null, 'thunder');
      } else {
        toDiscard([jc]);
        passZhuancha(p, card, '未命中');
      }
    } else {
      toDiscard([card, jc]);
    }
    if (window.UI) UI.render();
    await sleep(200);
    if (G.over) return;
  }
}

/* ---------------- 出牌阶段 ---------------- */
function playableList(p){
  const list = [];
  const seen = new Set();
  const hand = p.hand.slice();
  for (const c of hand){
    if (seen.has(c.name)) continue;
    const meta = CARDS[c.name];
    if (meta.kind === 'dodge' || meta.kind === 'nullify') continue;
    // 张金雪【铁面】：本回合不能使用事件牌。延时事件牌是事件牌的子类，一并封掉
    if (p.eventBan && (c.type === 'event' || c.type === 'delayed')) continue;
    if (c.type === 'equip'){
      list.push({ card:c, count: hand.filter(x => x.name === c.name).length });
      seen.add(c.name);
      continue;
    }
    if (meta.kind === 'attack'){
      if (!canUseAttack(p, c)) continue;
    }
    if (meta.kind === 'heal' && p.hp >= p.maxHp) continue;   // 出牌阶段使用请假条要求体力未满
    if (c.type === 'delayed' && p.usedDelayed >= 1) continue;
    if (validTargets(p, c).length === 0 && !['aoeAttack','massHeal','harvest','draw2','lightning'].includes(meta.kind)) continue;
    list.push({ card:c, count: hand.filter(x => x.name === c.name).length });
    seen.add(c.name);
  }
  return list;
}
/* 点名类牌的每回合次数上限。默认 1；地主【跋扈】+1。
 * 注意这两个函数是**同一段判据的两份拷贝**，改一个必须改另一个 ——
 * 只改一个的症状是"装备点名册时正常、其它武器出第二张杀被拒"，随装备变化，极难排查。 */
function attackQuota(p){ return 1 + (hasSkill(p, '跋扈') ? 1 : 0); }
function canUseAttack(p, card){
  // 点名类牌（上课点名/公开处刑/雷同警告）共用同一个次数上限，
  // 「点名册」和【吹牛】的禁令也都作用于整个类别 —— 规则书 5.1.1
  if (p.pointBan) return false;
  if (p.equips.weapon && p.equips.weapon.name === '点名册') return true;
  return p.usedAttackCardThisPhase < attackQuota(p);
}
function canUsePointCard(p){
  if (p.equips.weapon && p.equips.weapon.name === '点名册') return true;
  return p.usedAttackCardThisPhase < attackQuota(p);
}
function usableSkills(p){
  const out = [];
  const add = (name, needTarget, extra) => {
    if (skillUsed(p, name)) return;
    extra = extra || {};
    if (extra.needCards && countPayable(p) < extra.needCards) return;
    out.push(Object.assign({ name, needTarget, desc: skillDesc(p, name) }, extra));
  };
  const has = n => hasSkill(p, n);
  if (has('吹牛')) add('吹牛', false);
  if (has('挂科')) add('挂科', true);
  if (has('系统')) add('系统', true);
  if (has('奉承')) add('奉承', true);
  if (has('施压')) add('施压', true);
  if (has('解密')) add('解密', true);
  if (has('概率')) add('概率', false);
  if (has('共情')) add('共情', true, { healOnly:true });
  if (has('透析')) add('透析', true, { includeSelf:true, needCards:2, healOnly:true });
  if (has('垂钓')) add('垂钓', false, { needCards:1 });
  if (has('窃听')) add('窃听', true);
  if (has('冲锋')) add('冲锋', true, { needCards:1, attackSkill:true });
  if (has('龙吟')) add('龙吟', true, { includeSelf:true });
  if (has('氪金')) add('氪金', false, { needCards:2 });
  if (has('划水')) add('划水', true, { needCards:1 });
  if (has('查寝')) add('查寝', true);
  if (has('侃山')) add('侃山', true);
  if (has('撒娇')) add('撒娇', true);
  if (has('治愈')) add('治愈', true, { needCards:1, includeSelf:true, healOnly:true });
  if (has('鸽王')) add('鸽王', true, { needCards:1 });
  if (has('起哄')) add('起哄', true, { needCards:1 });
  if (has('双语')) add('双语', false, { needCards:1 });   // 只需要弃牌，不用选人
  if (has('分管')) add('分管', true, { needCards:1 });
  if (has('布施')) add('布施', true, { needCards:1, healOnly:true });
  if (has('打滚')) add('打滚', true, { needCards:1 });
  if (has('钞能力')) add('钞能力', true, { needCards:1 });
  if (has('铁面')) add('铁面', true, { needCards:2 });
  if (has('管饱')) add('管饱', true, { needCards:1, healOnly:true });
  if (has('爪子')) add('爪子', true, { needCards:1 });
  if (has('老辣')) add('老辣', true, { needCards:1 });
  if (has('新酒')) add('新酒', false, { needCards:1 });   // 只弃自己的牌，不用选人
  if (has('硬碰硬')) add('硬碰硬', true, { needCards:2 });
  if (has('虎啸')) add('虎啸', false, { needCards:1 });   // 目标是"范围内所有人"，自动算
  if (has('拍')) add('拍', true, { needCards:1 });
  if (has('摆尾')) add('摆尾', false);
  // 武器转化技（电风扇 / 粉笔）—— 同样受"点名类牌每回合 1 张"的限制
  if (p.equips.weapon && p.equips.weapon.name === '电风扇'
      && p.hand.some(c => c.name === '上课点名') && canUseAttack(p, { name:'公开处刑' }))
    out.push({ name:'电风扇·转化', eqSkill:true, needTarget:true, desc:'将一张"上课点名"当"公开处刑"使用（火焰伤害）' });
  if (p.equips.weapon && p.equips.weapon.name === '粉笔'
      && p.hand.length >= 2 && canUseAttack(p, { name:'上课点名' }))
    out.push({ name:'粉笔·转化', eqSkill:true, needTarget:true, desc:'将两张手牌当一张"上课点名"使用' });
  return out;
}
function skillDesc(p, name){
  const s = p.char && p.char.skills.find(x => x.name === name);
  // 过一遍 md()：技能文案里允许写 **粗体**，不过就会显示成字面星号
  if (s) return D.md ? D.md(s.text) : s.text;
  return (SIDE_SKILLS[name] && SIDE_SKILLS[name].text) || '';   // 身份技（地主专属）
}
/** 角色技 + 身份技的合并列表 —— 面板与详情弹窗都用它，否则玩家看不到地主技说明 */
function skillList(p){
  const out = (p.char && p.char.skills ? p.char.skills.slice() : []);
  (p.extraSkills || []).forEach(n => { if (SIDE_SKILLS[n]) out.push(SIDE_SKILLS[n]); });
  return out;
}
function skillTargets(p, skill){
  const out = [];
  for (const t of alivePlayers()){
    if (t === p){
      if (skill.includeSelf || ['透析','龙吟','治愈'].includes(skill.name)) out.push(t);
      continue;
    }
    if (skill.name === '挂科' || skill.name === '系统' || skill.name === '窃听'){
      if (t.hand.length && canBeHandTargeted(t)) out.push(t);
    } else if (skill.name === '奉承' || skill.name === '划水' || skill.name === '撒娇'){
      if (skill.name === '撒娇'){ if (t.hand.length) out.push(t); }
      else out.push(t);
    } else if (skill.name === '施压' || skill.name === '解密' || skill.name === '查寝'){
      if (skill.name === '解密' && (!t.hand.length)) continue;
      out.push(t);
    } else if (skill.name === '侃山'){ if (t.hand.length && p.hand.length) out.push(t); }
    else if (skill.name === '鸽王'){ out.push(t); }
    // 起哄只能指定**未横置**的：已经横置的人再横置一次是纯浪费一张牌
    else if (skill.name === '起哄'){ if (!t.chained) out.push(t); }
    else if (skill.name === '分管'){ if (t.judge && t.judge.length) out.push(t); }
    else if (skill.name === '钞能力'){ if (D.EQUIP_SLOTS.some(k => t.equips[k])) out.push(t); }
    else if (skill.name === '打滚'){ if (t.hand.length) out.push(t); }
    else if (skill.name === '爪子'){ if (t.hand.length) out.push(t); }
    // 注意：像【虎啸】这种"目标由技能自己算"的技能，**不能**在这里返回空数组。
    // 界面按钮的禁用条件是 `候选数 === 0`（ui.js），返回空会让它永远点不动；
    // "不用选人"是靠 usableSkills 里的 needTarget:false 表达的（ui.js 见到它直接结算）。
    else if (skill.name === '冲锋'){ if (inAttackRange(p, t)) out.push(t); }
    else out.push(t);
  }
  if (skill.healOnly) return out.filter(t => t.hp < t.maxHp);
  return out;
}

async function playPhase(p){
  let guard = 0;
  while (!G.over && p.alive && !p.skip.play){
    if (guard++ > 60) break;
    // 电脑玩家行动前留出"思考时间"，让所有人看清它准备做什么
    if (!p.isHuman){
      if (window.FX) FX.thinking(p, true);
      await sleep(560);
      if (window.FX) FX.thinking(p, false);
    }
    const req = { kind:'playPhase', playable: playableList(p), skills: usableSkills(p) };
    const res = await Ask(p, req);
    if (!res || res.action === 'end' || (res.action && res.action.type === 'end')) break;
    const act = res.action;
    if (!act) break;
    if (act.type === 'card'){
      const card = act.card;
      if (!p.hand.includes(card)) continue;
      const meta = CARDS[card.name];
      let targets = act.targets || [];
      if (meta.kind === 'chain' && act.recast){
        removeFromHand(p, [card]); toDiscard(card);
        log(p.name + ' 重铸了 ' + cardText(card), 'sys');
        await drawCards(p, 1, '重铸');
        continue;
      }
      if (meta.kind === 'equip'){
        if (window.FX) await FX.cardPlay(p.name, card, '自己（装备到' + (card.slot === 'weapon' ? '武器' : card.slot === 'armor' ? '防具' : '坐骑') + '栏）', { sfx:'equip' });
        equipCard(p, card);
        continue;
      }
      await useCard(p, card, targets);
      if (card.name === '上课点名' || card.name === '公开处刑' || card.name === '雷同警告'){
        if (p.equips.weapon && p.equips.weapon.name === '点名册' && card.name === '上课点名'){ /* 不限 */ }
      }
    } else if (act.type === 'virtual'){
      // 武器转化：电风扇（点名→公开处刑）/ 粉笔（两张手牌→点名）
      const cost = act.cost || [];
      if (!cost.length || !cost.every(c => p.hand.includes(c))) continue;
      if (!canUseAttack(p, { name: act.asName })){        // 次数上限校验
        if (window.UI) UI.toast('本回合点名类牌已用满 1 张', 'warn');
        continue;
      }
      const vc = { name: act.asName, kind:'attack', dmg: act.dmg || 'normal',
                   type:'basic', suit: act.suit || 'C', rank: act.rank || 8, virtual:true };
      removeFromHand(p, cost);
      log(p.name + ' 转化使用：' + cost.map(cardText).join(' + ') + ' → ' + vc.name, 'sys');
      await useCard(p, vc, act.targets || []);
      if (window.UI) UI.render();
      continue;
    } else if (act.type === 'skill'){
      const s = act.skill;
      if (skillUsed(p, s.name)) continue;
      if (window.FX) FX.skillBanner(p.name, s.name);
      log('✦ ' + p.name + ' 发动【' + s.name + '】', 'sys');
      await SKILLS[s.name](p, act.targets || []);
      if (s.name !== '波比跳') markSkillUsed(p, s.name);
      if (['吹牛','挂科','系统','奉承','施压','解密','概率','共情','透析','垂钓','窃听','冲锋','龙吟','氪金','划水','查寝','侃山','撒娇','治愈','鸽王'].includes(s.name))
        markSkillUsed(p, s.name);
    }
    if (window.UI) UI.render();
    await sleep(300);        // 每次行动后停顿，方便看清结果
  }
}

/* =========================================================
 *  游戏启动
 * ========================================================= */
function initGame(opts){
  G.opts = opts || {};
  G.format = G.opts.format || 'identity';     // 对局形式，见文件顶部的 FORMAT 表
  // 保护轮只对身份局有意义：它把第一圈的伤害钳到 hp-1，而 3~4 人局本来轮次就少，
  // 白白多拖一圈、直接顶掉新玩法"一局 5 分钟"的目标
  G.opts.protect = !!G.opts.protect && G.format === 'identity';
  // 「快速动画」以前是个**死开关**：页面上点得动，但没有任何地方读它。
  // sleep() 是按 G.speed 放大的，所以这里改它就够了，不用动每个停顿点。
  G.speed = opts.fast ? 0.6 : 1.35;
  G.gen = (G.gen || 0) + 1;
  G.players = []; G.deck = []; G.discard = []; G.over = false; G.round = 1; G.turnId = 0;
  // 开局前两段交互的状态：上一局的残留必须清掉，否则新的一局会直接跳过叫分/禁选
  G.bid = null; G.bidDone = false; G.bidScore = 0;
  G.ban = null; G.banDone = false; G.bannedIds = [];
  G.log = []; G.firstRound = true; G.roundDone = new Set(); G.harmLog = []; G.turnSeat = 0;
  // 谁救过院长（公开信息，AI 靠它推断"这人更像教务"）
  // 以前 AI 读的是 p._memo.rescue，但 _memo 全项目只读不写，那个判断从来没生效过。
  G.rescueLog = {};
  // 赛后评分用：每人的 伤害 / 击杀 / 救援 / 治疗 / 技能次数
  G.stats = {};
  G.killLog = [];
  const n = opts.count;
  // 本局的武将名单 = 基础角色 + 房主启用的拓展包。
  // 不启用任何包时，G.roster 与旧的 D.CHARACTERS 逐字相同 —— 老对局不受影响。
  G.packs = opts.packs || {};
  G.roster = D.roster(G.packs);
  const total = G.roster.length;
  // 哪些座位是真人在操作。单机/热座时就是 [0]。
  const humanSeats = (opts.humanSeats && opts.humanSeats.length)
    ? opts.humanSeats.slice().sort((a, b) => a - b)
    : [0];
  const humanCount = humanSeats.length;
  // 每个真人都要吃掉 deal 张候选，剩下的武将必须够给 (n - humanCount) 个电脑各留 1 张。
  // 人类玩家多的时候这个上限会明显收紧：8 个真人 × 3 选 1 = 24 张，超过全部 20 张武将了。
  // humanCount === 1 时，下面的式子等价于原来的 total - (n - 1)，单机行为完全不变。
  const dealCap = Math.floor((total - (n - humanCount)) / humanCount);
  const deal = Math.max(2, Math.min(opts.deal || 3, dealCap));
  // 只有身份局才碰 IDENTITY_CONFIG —— 斗地主 3 人在这张表里根本没有档位，
  // 硬补一档会把 p.identity 填上值，于是击杀奖惩/投影隐藏/AI 推断又全部按
  // 身份局语义跑起来，等于把两套模型搅在一起。
  const cfg = (G.format === 'identity') ? fmt().identityConfig(n) : null;
  // 身份模式（规则书 9.1）：
  //   A 随机身份 —— 洗混后每人一张（默认）
  //   B 自选阵营 —— 身份池公开，按座位顺序轮流挑，挑完只有本人知道（院长公开）
  //   C 半随机   —— 先选角色、后揭晓身份（选角界面不显示身份）
  // 非身份局没有"身份模式"这回事：G.mode 必须清空，否则身份轮抽会对空池子死循环
  G.mode = (G.format === 'identity') ? (opts.mode || 'A') : null;
  const drafting = (G.mode === 'B');
  // 身份池
  const idPool = [];
  if (cfg) for (const k of Object.keys(cfg)) for (let i=0;i<cfg[k];i++) idPool.push(k);
  shuffle(idPool);
  // B 模式下不预先分配，留一个公开的池子等人来挑
  G.idPool = drafting ? idPool.slice() : [];
  // 角色发放：每个真人各拿一批互不重叠的候选
  const charPool = shuffle(G.roster.slice());
  const choicesBySeat = {};
  for (const s of humanSeats){
    choicesBySeat[s] = charPool.splice(0, Math.min(deal, charPool.length));
  }
  G.dealPer = deal;                  // 候选数（供界面显示）
  G.charRest = charPool;             // 剩余武将池：电脑从这里挑
  for (let i=0;i<n;i++){
    const choices = choicesBySeat[i] || [];
    const player = {
      seat:i, char:null, charChoices:choices,
      // 非身份局 identity 恒为 null —— 阵营走 p.side（见各形式的 setup）
      identity: (drafting || !cfg) ? null : (idPool[i] || null),
      side: null,
      hp:0, maxHp:0, alive:true, hand:[],
      equips:{ weapon:null, armor:null, mountUp:null, mountDown:null },
      judge:[], chained:false, marks:{}, isHuman: (humanSeats.indexOf(i) >= 0),
      revealed: !drafting && !!cfg && idPool[i] === 'dean',
      skillsUsedThisTurn:{}, usedCardsThisTurn:[],
      damageDealtThisTurn:0, usedAttackCardThisPhase:0,
      skip:{}, dodgeBan:false, pointBan:false, eventBan:false, bilingual:false
    };
    // 角色名以 getter 形式提供：p.name = 角色牌上的名字
    Object.defineProperty(player, 'name', {
      get(){ return this.char ? this.char.name : ('座位 ' + (this.seat + 1)); },
      enumerable: false, configurable: true
    });
    G.players.push(player);
  }
  G.humanSeat = humanSeats[0];
  G.humanSeats = humanSeats;         // 联机时用来知道哪些座位要发选角请求
  // 各形式自己的开局编排（身份局不需要 —— 它上面已经按 IDENTITY_CONFIG 分好了）
  if (fmt().setup) fmt().setup();
  window.G = G;
}
/* ---------------- 选角 ----------------
 * 单机和联机共用这一套：真人各自选完（联机时由房主收齐），
 * 再调 finalizeRoles() 让电脑补位。 */

/** 电脑从剩余武将池里挑一个（评分 + 一点随机） */
function aiPickChar(p, taken, pool){
  // 兜底一律回落到**本局名单**（G.roster），不是基础名单 ——
  // 否则开了拓展包的局在补位时会挑到一个本局根本没发出去的角色
  const fallback = (G.roster && G.roster.length) ? G.roster : D.CHARACTERS;
  const src = (pool && pool.length) ? pool : fallback;
  let list = src.filter(c => !taken || !taken.has(c.id));
  if (!list.length) list = fallback.filter(c => !taken || !taken.has(c.id));
  if (!list.length) list = fallback.slice();
  if (!list.length) return fallback[0];
  let best = list[0], bestScore = -1;
  for (const c of list){
    let s = c.hp * 12 + Math.random() * 22;
    if (p.identity === 'dean') s += c.hp * 7;
    if (p.identity === 'staff') s += (c.skills.some(k => /回复|救援/.test(k.text)) ? 14 : 0);
    if (p.identity === 'student') s += (c.skills.some(k => /伤害|造成/.test(k.text)) ? 14 : 0);
    if (p.identity === 'mole') s += (c.hp >= 4 ? 10 : 0);
    if (s > bestScore){ bestScore = s; best = c; }
  }
  return best;
}

/** 某个座位选定了武将 */
function assignRole(seat, char){
  const p = G.players[seat];
  if (!p || !char) return false;
  p.char = char;
  return true;
}

/** 还有哪些真人在等着选角 */
function pendingRoleSeats(){
  return (G.humanSeats || []).filter(s => G.players[s] && !G.players[s].char);
}

/* ---------------- 身份轮抽（模式 B 自选阵营） ----------------
 * 规则书 9.1：按配置表**公开**分配身份，玩家轮抽或协商选择，
 * 但选择结果只有本人知道（院长抽到后立即公开）。 */

/** 电脑挑身份时的偏好顺序：院长最抢手，其次卧底，再教务/学生 */
const IDENTITY_DRAFT_ORDER = ['dean', 'mole', 'staff', 'student'];

function assignIdentity(seat, key){
  const p = G.players[seat];
  if (!p || p.identity) return false;
  const i = (G.idPool || []).indexOf(key);
  if (i < 0) return false;
  G.idPool.splice(i, 1);
  p.identity = key;
  p.revealed = (key === 'dean');         // 院长身份始终公开
  return true;
}

function aiPickIdentity(){
  for (const k of IDENTITY_DRAFT_ORDER) if ((G.idPool || []).indexOf(k) >= 0) return k;
  return (G.idPool || [])[0];
}

/**
 * 按座位顺序推进轮抽：轮到电脑就立刻替它挑好，遇到还没挑的真人就停下来等他。
 * 返回"正在等哪个座位"，都挑完了返回 -1。
 */
/** 轮抽时哪些座位要问人：热座模式下每个座位都要问，联机时只问真人座位 */
function draftHumanSeats(){
  if (G.opts && G.opts.hotseat) return G.players.map(p => p.seat);
  return G.humanSeats || [];
}

function advanceIdentityDraft(){
  const humans = draftHumanSeats();
  for (const p of G.players){
    if (p.identity) continue;
    if (humans.indexOf(p.seat) >= 0) return p.seat;
    const pick = aiPickIdentity();
    if (pick === undefined) break;       // 池子空了，理论上不会发生
    assignIdentity(p.seat, pick);
  }
  return -1;
}

/** 还有哪些座位在等着挑身份 */
function pendingIdentitySeats(){
  return draftHumanSeats().filter(s => G.players[s] && !G.players[s].identity);
}

/** 身份池里还剩什么（给界面显示） */
function identityPoolLeft(){
  return (G.idPool || []).slice();
}

/**
 * 所有真人都选完之后调用：把没选走的候选并回池子，电脑再从剩下的里挑，
 * 最后做一次"绝不允许两个座位拿到同一个角色"的兜底校验。
 * 不负责 finalizeGame() / 发手牌 —— 那是调用方的事。
 */
function finalizeRoles(){
  const taken = new Set();
  G.players.forEach(p => { if (p.char) taken.add(p.char.id); });
  // 真人没选走的那几张候选回归武将池
  const pool = (G.charRest || []).slice();
  G.players.forEach(p => {
    (p.charChoices || []).forEach(x => { if (!taken.has(x.id)) pool.push(x); });
  });
  G.players.forEach(p => {
    if (p.char) return;
    const pick = aiPickChar(p, taken, pool);
    taken.add(pick.id);
    p.char = pick;
  });
  // 兜底校验：绝不允许两个座位拿到同一个角色
  const ids = G.players.map(p => p.char && p.char.id);
  if (new Set(ids).size !== ids.length){
    const used = new Set();
    G.players.forEach(p => {
      if (!p.char || used.has(p.char.id)){
        const alt = ((G.roster && G.roster.length) ? G.roster : D.CHARACTERS)
                      .find(x => !used.has(x.id));
        if (alt) p.char = alt;
      }
      used.add(p.char.id);
    });
    log('⚠ 检测到重复角色，已自动替换为不同角色', 'dmg');
  }
}

/** 发起手牌（院长 5 张；4 人局学生补偿到 5 张，见规则书 9.5） */
function dealInitialHands(){
  for (const p of G.players){
    const n = fmt().handSize(p);      // 按对局形式决定起手张数
    for (let i=0;i<n;i++){
      const c = G.deck.pop();
      if (c) p.hand.push(c);
    }
  }
}

function finalizeGame(){
  const G2 = G;
  G2.deck = shuffle(D.buildDeck());
  G2.discard = [];
  G2.turnSeat = fmt().firstSeat();    // 身份局是院长先手；团队形式各自定
  for (const p of G2.players){
    // 身份加成 + 黄熊【扛】的体力上限 +1（代价是摸牌阶段少摸一张，见 runTurn）
    p.maxHp = p.char.hp + fmt().hpBonus(p) + (hasSkill(p, '扛') ? 1 : 0);
    p.hp = p.maxHp;
    // 地主的两个身份技走 p.extraSkills（见 hasSkill 的第二条支路）。
    // 放在这里而不是 initGame：叫分是在那之后才定下地主的。
    if (p.side === 'landlord') p.extraSkills = ['飞扬', '跋扈'];
  }
}
async function gameLoop(){
  const myGen = G.gen;
  while (!G.over && G.gen === myGen){
    const p = G.players[G.turnSeat];
    if (p && p.alive){
      await runTurn(p);
      if (G.over) break;
    }
    // 下一名存活角色
    let next = G.turnSeat;
    for (let i=1;i<=G.players.length;i++){
      const idx = (G.turnSeat + i) % G.players.length;
      if (G.players[idx].alive){ next = idx; break; }
    }
    // 只剩一个人活着了，没人可轮 —— 胜负交给 checkVictory 判。
    // 注意别在这里先写 G.over：checkVictory 和 endGame 开头都有 `if (G.over) return`，
    // 先写就等于把它们整个跳过，结果是**不弹结算界面**就黑在那里。
    if (next === G.turnSeat){ checkVictory(); break; }
    const wrapped = next <= G.turnSeat;
    G.turnSeat = next;
    if (G.players.filter(x=>x.alive).length <= 1) { checkVictory(); if (G.over) break; }
    if (wrapped){
      G.round++;
      G.firstRound = false;
      log('===== 第 ' + G.round + ' 轮开始 =====', 'big');
      // 打太久了判平局。这里同样必须走 endGame（它自己会写 G.over 并弹结算）——
      // 以前是先写 G.over，于是 endGame 直接在门口返回：一局磨到 40 轮之后
      // 界面就那么停在棋盘上，既没结算也没法继续。
      if (G.round > 40){ endGame(null, '回合数过多，判定平局'); break; }
    }
  }
  // 收尾。循环有两种退出方式：这局真的打完了，或者 G.gen 变了（有人开了新的一局）。
  // 后一种情况下本局已经作废，**绝不能**再去动 G —— 那会把刚开的新局标成已结束，
  // 表现是新局一进去就"游戏结束"、什么都点不动。
  // 触发场景很日常：一局还没跑完（比如正好轮到电脑）就点「再来一局」或「新手教学局」。
  //
  // 还留在这里则说明循环没停在"已分出胜负"上（某个 break 漏设了 G.over）：
  // 先让 checkVictory 判，判不出来就当平局收尾 —— 无论如何都得有个结算界面。
  // 注意别自己先写 G.over：checkVictory / endGame 开头都有 `if (G.over) return`。
  if (G.gen === myGen && !G.over){
    checkVictory();
    if (!G.over) endGame(null, '对局结束');
  }
}

window.Engine = {
  G, initGame, finalizeGame, gameLoop, Ask, useCard, damage, heal, drawCards,
  distance, attackRange, inAttackRange, handLimit, validTargets, playableList, usableSkills,
  skillTargets, hasSkill, cardText, alivePlayers, orderFrom, others, log, logBig, sleep,
  checkVictory, endGame, SEX, killPlayer,
  // 选角与开局（单机与联机共用）
  assignRole, finalizeRoles, pendingRoleSeats, dealInitialHands,
  // 身份轮抽（模式 B）
  assignIdentity, advanceIdentityDraft, pendingIdentitySeats, identityPoolLeft,
  // 赛后评分（供自测与扩展使用）
  buildScoreboard, SCORE_RULE,
  // 供自检与扩展使用
  isImmuneByCard, canUseAttack, allZoneCards, countPayable, judgePhase, endTurn,
  // 开局前的两段交互（主客机共用）：斗地主的叫分、2V2 的禁选
  bidNext, bidSubmit, bidFinish, skillList,
  banNext, banSubmit, banFinish,
  // 对局形式的对外接口 —— ui / net / main / ai 只能通过这些拿信息，不许直接读 G.format
  winOf: (winner, p) => fmt().winOf(winner, p),
  sideLabel: k => fmt().sideName(k),
  sideInfo: p => {
    const k = fmt().sideOf(p);
    return { key:k, name: fmt().sideName(k), cls: fmt().sideCls(k),
             tagCls: fmt().sideTagCls(p),
             goal: fmt().goal(k), visible: fmt().visible(p) };
  },
  formatLabel: () => fmt().label,
  /** 可选玩法列表（开始界面与联机大厅都从它生成，别在别处硬编码一份） */
  formats: () => Object.keys(FORMAT).map(k => ({
    key: FORMAT[k].key, label: FORMAT[k].label, seats: FORMAT[k].seats
  })),
  _skills: SKILLS          // 主动技函数表：测试要能单独驱动一个技能，不看渲染
};
})();
