﻿# =========================================================
#  东秦杀 · 因特网联机一条龙
#
#  双击 start-online.bat 会跑到这里。它做四件事：
#    1. 起 server.py（如果没在跑）
#    2. 起 cloudflared 隧道，把 8080 端口捅到公网
#    3. 从隧道输出里抓出 https://xxx.trycloudflare.com
#    4. 用那个公网地址打开浏览器
#
#  ⚠ 房主必须**用这个公网地址玩，别用 localhost**。
#    邀请链接里的服务器地址是从**当前网页的地址**推断的（net.js 的 serverBase()），
#    用 localhost 打开的话，发出去的是 http://localhost:8080/?room=1234 ——
#    同学点开连的是他自己的电脑。这个脚本直接帮你打开对的那个。
#
#  按 Ctrl+C（或直接关掉窗口）就结束，服务器和隧道都会一起收掉。
#
#  ---------------------------------------------------------
#  本文件是 **UTF-8 带 BOM** 的。
#
#  项目里别的 .ps1 都是纯 ASCII，因为 PowerShell 5.1 按 ANSI/GBK 读没有 BOM 的
#  .ps1，中文会变成乱码。带 BOM 就没这个问题（实测过：带 BOM 正常，去掉就乱）。
#  这是个要双击的给玩家用的脚本，提示语得是中文，所以这里破例用 BOM ——
#  **改这个文件时注意别把 BOM 弄丢**，丢了中文就会花掉。
# =========================================================
param(
  [switch]$NoBrowser    # 只建隧道、不开浏览器（给自动化验证用）
)
$ErrorActionPreference = 'Stop'

$tools = Split-Path -Parent $MyInvocation.MyCommand.Path
$root  = Split-Path -Parent $tools

function Say($text, $color) {
  if ($color) { Write-Host $text -ForegroundColor $color } else { Write-Host $text }
}

# cloudflared 会**一直**往它的输出文件里写，所以读的时候必须允许共享。
# 用 [IO.File]::ReadAllText 会抛"文件正被另一进程使用"，整个脚本当场崩掉 ——
# 这个坑踩过一次，别再改回去。
function ReadShared([string]$path) {
  if (-not (Test-Path $path)) { return '' }
  try {
    $fs = New-Object System.IO.FileStream($path, [System.IO.FileMode]::Open,
              [System.IO.FileAccess]::Read, [System.IO.FileShare]::ReadWrite)
    $sr = New-Object System.IO.StreamReader($fs, [System.Text.Encoding]::UTF8)
    $t = $sr.ReadToEnd(); $sr.Close(); $fs.Close(); return $t
  } catch { return '' }
}

# ---------------------------------------------------------------- cloudflared
$cf = (Get-Command cloudflared -ErrorAction SilentlyContinue)
if ($cf) { $cfExe = $cf.Source } else {
  $cfExe = $null
  foreach ($p in @(
    (Join-Path ${env:ProgramFiles(x86)} 'cloudflared\cloudflared.exe'),
    (Join-Path $env:ProgramFiles 'cloudflared\cloudflared.exe'),
    (Join-Path $env:LOCALAPPDATA 'Microsoft\WinGet\Links\cloudflared.exe')
  )) { if (Test-Path $p) { $cfExe = $p; break } }
}
if (-not $cfExe) {
  Say ''
  Say '  找不到 cloudflared —— 它是内网穿透工具，A 方案靠它把服务器捅到公网。' Yellow
  Say '  装一次就行：' Yellow
  Say '      winget install Cloudflare.cloudflared' Cyan
  Say ''
  Say '  （装完可能要把这个窗口关掉重开一次，让 PATH 生效）' DarkGray
  Say ''
  exit 1
}

# ---------------------------------------------------------------- 服务器
$port = 8080
$server = $null
$already = $false
try {
  $null = Invoke-WebRequest "http://127.0.0.1:$port/index.html" -UseBasicParsing -TimeoutSec 3
  $already = $true
} catch { $already = $false }

if ($already) {
  Say ("  检测到 127.0.0.1:{0} 已经在跑服务器，直接用它。" -f $port) DarkGray
} else {
  Say '  正在启动游戏服务器…' DarkGray
  $server = Start-Process -FilePath 'python' -ArgumentList @('-I', 'server.py', "$port") `
                          -WorkingDirectory $root -WindowStyle Hidden -PassThru
  $ok = $false
  for ($i = 0; $i -lt 30; $i++) {
    Start-Sleep -Milliseconds 400
    try {
      $null = Invoke-WebRequest "http://127.0.0.1:$port/index.html" -UseBasicParsing -TimeoutSec 2
      $ok = $true; break
    } catch { }
  }
  if (-not $ok) {
    Say ''
    Say '  服务器起不来。单独跑一次看看报什么错：' Red
    Say '      python server.py' Cyan
    Say ''
    exit 1
  }
}

# ---------------------------------------------------------------- 隧道
Say '  正在建立公网隧道…（第一次要等几秒）' DarkGray
$log = Join-Path $env:TEMP ('dqk-tunnel-' + [guid]::NewGuid().ToString('N').Substring(0, 6) + '.log')
$tunnel = Start-Process -FilePath $cfExe `
  -ArgumentList @('tunnel', '--url', "http://localhost:$port", '--no-autoupdate') `
  -RedirectStandardError $log -RedirectStandardOutput ($log + '.out') `
  -WindowStyle Hidden -PassThru

$publicUrl = $null
for ($i = 0; $i -lt 60; $i++) {
  Start-Sleep -Milliseconds 500
  if ($tunnel.HasExited) { break }
  $t = ReadShared $log
  if ($t) {
    $m = [regex]::Match($t, 'https://[a-z0-9][a-z0-9-]*\.trycloudflare\.com')
    if ($m.Success) { $publicUrl = $m.Value; break }
  }
}

if (-not $publicUrl) {
  Say ''
  Say '  隧道没能建立。可能是网络不通，或者 Cloudflare 暂时抽风。' Red
  Say '  原始输出在这儿，可以直接看：' DarkGray
  Say ("      " + $log) Cyan
  if (Test-Path $log) { Say ''; (Get-Content $log -Tail 12) | ForEach-Object { Say ('      ' + $_) DarkGray } }
  Say ''
  if ($tunnel -and -not $tunnel.HasExited) { $null = cmd /c "taskkill /F /T /PID $($tunnel.Id) >nul 2>&1" }
  if ($server -and -not $server.HasExited) { $null = cmd /c "taskkill /F /T /PID $($server.Id) >nul 2>&1" }
  exit 1
}

# 从公网这一侧回访一次，确认真的通了（本地通 ≠ 公网通）
Say '  正在验证公网地址…' DarkGray
$verified = $false
for ($i = 0; $i -lt 20; $i++) {
  try {
    $r = Invoke-WebRequest ($publicUrl + '/api/info') -UseBasicParsing -TimeoutSec 6
    if ($r.StatusCode -eq 200) { $verified = $true; break }
  } catch { Start-Sleep -Milliseconds 700 }
}

$line = '=' * 62
Say ''
Say $line Green
if ($verified) { Say '  公网地址已就绪 —— 用下面这个地址打开游戏！' Green }
else           { Say '  隧道地址拿到了，但回访没成功（可能还要再等几秒）' Yellow }
Say $line Green
Say ''
Say ('      ' + $publicUrl) White
Say ''
Say $line Green
Say ''
Say '  接下来：' White
Say '    1. 浏览器会自动打开这个地址（没打开就手动复制上面那行）' DarkGray
Say '    2. 在里面点「联机对战 → 创建房间」' DarkGray
Say '    3. 点「复制邀请链接」，发到群里 —— 链接里已经带着这个公网地址和房间号' DarkGray
Say ''
Say '  ⚠ 你自己也要用这个公网地址玩，别切回 localhost ——' Yellow
Say '    邀请链接里的服务器地址是从当前网页地址推断的。' DarkGray
Say ''
Say '  按 Ctrl+C 结束（服务器和隧道会一起关掉）' DarkGray
Say ''

if (-not $NoBrowser) { Start-Process $publicUrl | Out-Null }   # 用默认浏览器打开

try {
  Wait-Process -Id $tunnel.Id
  Say ''
  Say '  隧道已断开。' DarkGray
} finally {
  if ($tunnel -and -not $tunnel.HasExited) { $null = cmd /c "taskkill /F /T /PID $($tunnel.Id) >nul 2>&1" }
  if ($server -and -not $server.HasExited) {
    Say '  正在关掉游戏服务器…' DarkGray
    $null = cmd /c "taskkill /F /T /PID $($server.Id) >nul 2>&1"
  }
}
