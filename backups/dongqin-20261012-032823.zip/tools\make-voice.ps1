﻿# =========================================================
#  东秦杀 · 音色包生成器（一般从 make-voice.bat 双击进入）
#
#  用开源模型 Kokoro-82M-v1.1-zh 把游戏台词念成 mp3，放进 audio\voice\，
#  游戏设置里就能逐个试听、切换音色。台词表从 js\data.js 现场解析 ——
#  以后加了新武将新牌，重跑一次就有对应语音（没跑到的会静默退回系统语音）。
#
#  第一次跑会做三件事（要联网，约 1GB 磁盘）：
#    1. 建独立 venv：tools\.voicevenv（不碰你系统里的 Python，删掉即净）
#    2. 装依赖：torch(CPU 版) + kokoro + misaki[zh] + soundfile + lameenc
#    3. 下载模型：约 330MB，缓存在 tools\.voicecache
#  之后重跑就快了，而且是**断点续跑**：已有的 mp3 会跳过。
#
#  参数（不想用默认清单时才需要）：
#      -Audition        100 个音色各念一句，生成可点的试听页，先挑音色
#      -Voices <ids>    指定音色，如 -Voices zf_001,zm_010
#      -Force           已存在的文件也重新生成
#      -Limit <n>       每个音色只做前 n 句（冒烟测试用，不写清单）
#
#  ---------------------------------------------------------
#  本文件是 **UTF-8 带 BOM** 的。
#
#  项目里多数 .ps1 是纯 ASCII，因为 PowerShell 5.1 会把没有 BOM 的 .ps1 按 ANSI/GBK 读，
#  中文会变成乱码。这个脚本是给玩家双击用的，提示语必须是中文，所以带 BOM 破例
#  （tools\online.ps1 也是这么办的）。
#  **改这个文件时别把 BOM 弄丢**，丢了中文就会花。
# =========================================================
param(
  [switch]$Audition,
  [switch]$Force,
  [int]$Limit = 0,
  [string]$Voices = ''
)
$ErrorActionPreference = 'Stop'

$tools  = Split-Path -Parent $MyInvocation.MyCommand.Path
$root   = Split-Path -Parent $tools
$venv   = Join-Path $tools '.voicevenv'
$py     = Join-Path $venv 'Scripts\python.exe'
$cache  = Join-Path $tools '.voicecache'
$script = Join-Path $tools 'voicegen.py'

function Say($text, $color) {
  if ($color) { Write-Host $text -ForegroundColor $color } else { Write-Host $text }
}

if (-not (Test-Path $script)) { Say ("  找不到 " + $script) Red; exit 1 }

# ---------------------------------------------------------------- 1. venv + 依赖
if (-not (Test-Path $py)) {
  Say ''
  Say '  第一次跑：建一个独立 venv 并装依赖（约 1GB，走 CPU 版 torch）。' Yellow
  Say '  不碰你系统里的 Python —— 以后不想要了，删掉 tools\.voicevenv 和 tools\.voicecache 即可。' DarkGray
  Say ''
  if (-not (Get-Command python -ErrorAction SilentlyContinue)) {
    Say '  找不到 python。先装 Python 3（安装时勾上 Add python.exe to PATH）：' Red
    Say '      https://www.python.org/' Cyan
    exit 1
  }
  & python -m venv $venv
  & $py -m pip install --upgrade pip --quiet
}

# 依赖自检：venv 在但包缺了（手动删过、或上次装到一半）也能自动补
& $py -c "import torch, kokoro, misaki, soundfile, lameenc" 2>$null
if ($LASTEXITCODE -ne 0) {
  Say ''
  Say '  正在装依赖（torch 走 CPU-only 源，否则 Windows 上会拖 2GB 的 CUDA 库）…' DarkGray
  & $py -m pip install torch --index-url https://download.pytorch.org/whl/cpu
  if ($LASTEXITCODE -ne 0) { Say '  torch 装失败了，看上面的报错。' Red; exit 1 }
  & $py -m pip install kokoro "misaki[zh]" soundfile lameenc
  if ($LASTEXITCODE -ne 0) { Say '  依赖装失败了，看上面的报错。' Red; exit 1 }
}

# ---------------------------------------------------------------- 2. 缓存与编码
# 模型缓存留在项目里，不写进 %USERPROFILE%\.cache
$env:HF_HOME = $cache
# 让 python 的 stdout 也是 UTF-8，否则控制台里的中文进度会花掉
$env:PYTHONIOENCODING = 'utf-8'
$null = New-Item -ItemType Directory -Force $cache

# ---------------------------------------------------------------- 3. 生成
Say ''
$callArgs = @($script)
if ($Audition) { $callArgs += '--audition' }
if ($Force)    { $callArgs += '--force' }
if ($Voices)   { $callArgs += @('--voices', $Voices) }
if ($Limit -gt 0) { $callArgs += @('--limit', "$Limit") }

& $py @callArgs
$code = $LASTEXITCODE

Say ''
if ($code -eq 0) {
  Say '  音色就绪。回到游戏（刷新页面）→ 设置 → 语音报牌，在音色列表里逐个试听。' Green
  if ($Audition) {
    Say ("  试听页也可以直接用浏览器打开：" + (Join-Path $tools '_audition\index.html')) Cyan
  }
} else {
  Say '  生成没跑完（看上面的报错）。已生成的文件不会白费 —— 再跑一次会接着做。' Yellow
}
Say ''
exit $code
