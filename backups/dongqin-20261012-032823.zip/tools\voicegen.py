#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""东秦杀 · 音色包生成器 —— 用开源 TTS 给游戏配音。

模型用 Kokoro-82M-v1.1-zh（Apache-2.0，82M 参数，CPU 就能跑，
含 100 个中文说话人，中文数据由龙猫数据无偿提供）。
官方中文用法见模型卡自带的 samples/make_zh.py。

一般不用手敲这个脚本，双击 `tools\\make-voice.ps1` 即可（它会建 venv、装依赖、设缓存目录）。

直接跑的话：

    python tools/voicegen.py                  # 生成下面 VOICES 清单里的音色
    python tools/voicegen.py --audition       # 只念一句「上课点名」，把 100 个音色全生成出来给你挑
    python tools/voicegen.py --voices zf_001,zm_010
    python tools/voicegen.py --limit 3        # 每个音色只做前 3 句（冒烟用，不写清单）
    python tools/voicegen.py --force          # 重生成（默认跳过已有文件，可以中断后续跑）

产物：

    audio/voice/packs.json         音色包清单，游戏读它
    audio/voice/<id>/c-<牌名>.mp3  45 个
    audio/voice/<id>/s-<技能名>.mp3 74 个

台词表是**从 js/data.js 现场解析**的，不维护第二份清单 ——
以后加了新武将、新牌，重跑一次就有对应的语音（没跑的会静默退回系统语音，不会哑）。
"""

import argparse
import json
import os
import re
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
DATA_JS = ROOT / 'js' / 'data.js'
OUT_DIR = ROOT / 'audio' / 'voice'
AUDITION_DIR = ROOT / 'tools' / '_audition'

MODEL_REPO = 'hexgrad/Kokoro-82M-v1.1-zh'
SAMPLE_RATE = 24000       # Kokoro 的输出采样率，别改
BITRATE_KBPS = 32         # 单声道 32kbps：一句话约 5KB，12 个音色总共约 7MB
SPEED = 1.05              # 报牌要利索；官方对长句会降速，我们的句子都很短
AUDITION_LINE = '上课点名'  # --audition 用这句：它本身也是张牌，念出来最好判断

# ---------------------------------------------------------------- 音色清单
# 改这里就能换音色： (模型里的音色 id, 设置里显示的名字, 性别)
# 不知道选哪个就先跑 --audition，把 100 个各念一句生成到 tools\_audition\ 里听。
# 音色 id 是模型数据集里的编号，跟音色特征无关，所以名字只能按性别排号。
VOICES = [
    ('zf_001', '女声 1', 'female'),
    ('zf_002', '女声 2', 'female'),
    ('zf_003', '女声 3', 'female'),
    ('zf_019', '女声 4', 'female'),
    ('zf_040', '女声 5', 'female'),
    ('zf_077', '女声 6', 'female'),
    ('zm_009', '男声 1', 'male'),
    ('zm_010', '男声 2', 'male'),
    ('zm_011', '男声 3', 'male'),
    ('zm_025', '男声 4', 'male'),
    ('zm_050', '男声 5', 'male'),
    ('zm_081', '男声 6', 'male'),
]

# 文件名里不能出现的字符（Windows 最严：这些在 Linux 上合法，在 Windows 上直接建不出文件）
BAD_FILE_CHARS = set('<>:"/\\|?*')


# ---------------------------------------------------------------- 台词表
def read_lines():
    """从 js/data.js 解析出要念的东西 -> [(kind, 名字, 念出来的文本), ...]

    kind: 'c' = 牌名（报牌），'s' = 技能台词。
    """
    src = DATA_JS.read_text(encoding='utf-8')

    m = re.search(r'const CARDS = \{(.*?)\n\};', src, re.S)
    if not m:
        raise SystemExit('解析不出 data.js 里的 CARDS —— 是不是改过格式？')
    card_names = re.findall(r"^  '([^']+)':", m.group(1), re.M)

    m = re.search(r'const SKILL_LINES = \{(.*?)\n\};', src, re.S)
    if not m:
        raise SystemExit('解析不出 data.js 里的 SKILL_LINES')
    skills = re.findall(r"^  '([^']+)':\s*'([^']*)'", m.group(1), re.M)

    if not card_names or not skills:
        raise SystemExit('台词表解析出来是空的，别往下跑了')

    lines = []
    for name in card_names:
        # 牌名直接念。'代课·补充' 里的间隔号念出来会顿一下，去掉更像人话。
        lines.append(('c', name, name.replace('·', '')))
    for name, text in skills:
        lines.append(('s', name, text))
    return lines


def file_name(kind, name):
    """c-上课点名.mp3 / s-正义.mp3 —— 中文文件名，服务器和浏览器都认（实测过）。"""
    key = kind + '-' + name
    bad = [c for c in key if c in BAD_FILE_CHARS]
    if bad:
        raise SystemExit('台词名里有不能当文件名的字符：%r -> %r' % (name, bad))
    return key + '.mp3'


# ---------------------------------------------------------------- 音频
def trim_silence(a, thresh=0.01, pad_ms=20):
    """掐掉首尾静音。不掐的话连续两次报牌之间会拖一拍，听感很钝。"""
    import numpy as np
    idx = np.where(np.abs(a) > thresh)[0]
    if len(idx) == 0:
        return a
    pad = int(SAMPLE_RATE * pad_ms / 1000)
    return a[max(0, idx[0] - pad): min(len(a), idx[-1] + pad)]


def write_mp3(path, audio):
    import lameenc
    import numpy as np

    a = np.asarray(audio, dtype=np.float32).reshape(-1)
    a = trim_silence(a)
    pcm16 = (np.clip(a, -1.0, 1.0) * 32767.0).astype('<i2')

    enc = lameenc.Encoder()
    enc.set_bit_rate(BITRATE_KBPS)
    enc.set_in_sample_rate(SAMPLE_RATE)
    enc.set_out_sample_rate(SAMPLE_RATE)
    enc.set_channels(1)
    enc.set_quality(4)          # 2=最慢最好，7=最快；语音用 4 足够
    data = enc.encode(pcm16.tobytes()) + enc.flush()

    # 先写 .part 再改名：中途 Ctrl+C 不会留下一个"看起来已经生成好"的半截文件
    part = path.with_name(path.name + '.part')
    part.write_bytes(data)
    os.replace(part, path)
    return len(data)


def make_pipeline():
    """加载模型。第一次会从 HuggingFace 下载约 330MB 到 HF_HOME（make-voice.ps1 指向 tools\\.voicecache）。"""
    from kokoro import KModel, KPipeline
    print('  加载模型 %s …（第一次要下 300MB 左右）' % MODEL_REPO, flush=True)
    t0 = time.time()
    model = KModel(repo_id=MODEL_REPO).to('cpu').eval()
    pipe = KPipeline(lang_code='z', repo_id=MODEL_REPO, model=model)
    print('  模型就绪，用时 %.0f 秒' % (time.time() - t0), flush=True)
    return pipe


def synth(pipe, text, voice_id):
    """念一句 -> numpy 波形。"""
    import numpy as np
    chunks = []
    for result in pipe(text, voice=voice_id, speed=SPEED):
        a = result.audio
        if hasattr(a, 'detach'):        # torch tensor
            a = a.detach().cpu().numpy()
        chunks.append(np.asarray(a, dtype=np.float32).reshape(-1))
    if not chunks:
        raise RuntimeError('模型没吐出音频：%r' % text)
    return np.concatenate(chunks)


# ---------------------------------------------------------------- 音色列表（--audition 用）
def repo_voice_ids():
    """模型仓库里全部音色 id（55 女 + 45 男）"""
    from huggingface_hub import list_repo_files
    ids = [f[:-3].split('/')[-1] for f in list_repo_files(MODEL_REPO) if f.startswith('voices/') and f.endswith('.pt')]
    # 只留中文音色（zf_/zm_）；仓库里还有 3 个英语音色 af_/bf_
    return sorted(i for i in ids if i.startswith('zf_') or i.startswith('zm_'))


# ---------------------------------------------------------------- 主流程
def run_audition(pipe, force):
    """把 100 个音色各念一句，生成一个能点的试听页 —— 用耳朵定 12 个正式音色。"""
    ids = repo_voice_ids()
    print('试听模式：%d 个音色 × 一句「%s」 -> %s' % (len(ids), AUDITION_LINE, AUDITION_DIR), flush=True)
    AUDITION_DIR.mkdir(parents=True, exist_ok=True)

    done, failed = 0, []
    for i, vid in enumerate(ids, 1):
        out = AUDITION_DIR / (vid + '.mp3')
        if out.exists() and not force:
            done += 1
            continue
        try:
            write_mp3(out, synth(pipe, AUDITION_LINE, vid))
            done += 1
        except Exception as e:                       # 单个音色崩了不该毁掉整轮
            failed.append((vid, str(e)[:80]))
        if i % 10 == 0:
            print('  %d/%d' % (i, len(ids)), flush=True)

    rows = '\n'.join(
        '<li><b>%s</b><audio controls preload="none" src="%s.mp3"></audio></li>' % (v, v)
        for v in ids if (AUDITION_DIR / (v + '.mp3')).exists())
    (AUDITION_DIR / 'index.html').write_text(
        '<!doctype html><meta charset="utf-8"><title>音色试听</title>\n'
        '<p>双击打开这个页面，逐个点播放 —— 挑出你喜欢的，把 id 填进 '
        '<code>tools/voicegen.py</code> 顶部的 VOICES，再跑一次 make-voice.ps1。</p>\n'
        '<ul style="list-style:none;padding:0">\n' + rows + '\n</ul>\n',
        encoding='utf-8')
    print('完成：%d 个音色 -> %s' % (done, AUDITION_DIR))
    print('试听页：%s' % (AUDITION_DIR / 'index.html'))
    if failed:
        print('这些音色失败了：' + ', '.join(v for v, _ in failed))
    return 0 if done else 1


def run_generate(pipe, voices, force, limit):
    lines = read_lines()
    if limit:
        lines = lines[:limit]
    print('台词 %d 句（牌名 %d + 技能 %d） × 音色 %d 个' % (
        len(lines),
        sum(1 for k, _, _ in lines if k == 'c'),
        sum(1 for k, _, _ in lines if k == 's'),
        len(voices)), flush=True)

    OUT_DIR.mkdir(parents=True, exist_ok=True)
    packs, total_bytes = [], 0

    for vi, (vid, label, sex) in enumerate(voices, 1):
        vdir = OUT_DIR / vid
        vdir.mkdir(parents=True, exist_ok=True)
        t0 = time.time()
        made, skipped, failed = 0, 0, []
        for kind, name, text in lines:
            out = vdir / file_name(kind, name)
            if out.exists() and out.stat().st_size > 0 and not force:
                skipped += 1
                continue
            try:
                total_bytes += write_mp3(out, synth(pipe, text, vid))
                made += 1
            except Exception as e:
                failed.append((name, str(e)[:80]))
        dt = time.time() - t0
        print('[%2d/%d] %s %s：新生成 %d，跳过 %d%s（%.0f 秒）' % (
            vi, len(voices), vid, label, made, skipped,
            ('，失败 %d' % len(failed)) if failed else '', dt), flush=True)
        for n, e in failed:
            print('        ! %s: %s' % (n, e), flush=True)

        have = len([f for f in vdir.glob('*.mp3') if f.stat().st_size > 0])
        if not limit and have >= len(lines):
            packs.append({'id': vid, 'name': label, 'sex': sex, 'dir': vid, 'files': have})
        elif limit:
            print('        （--limit 冒烟模式：不写进清单）', flush=True)
        else:
            print('        （只有 %d/%d 个文件，先不写进清单 —— 再跑一次补齐）' % (have, len(lines)), flush=True)

    manifest = OUT_DIR / 'packs.json'
    if not limit:
        manifest.write_text(json.dumps({
            'engine': 'Kokoro-82M-v1.1-zh',
            'license': 'Apache-2.0',
            'source': 'https://huggingface.co/hexgrad/Kokoro-82M-v1.1-zh',
            'note': '中文说话人由龙猫数据无偿提供给该开源模型；音频为本机离线生成',
            'generated': time.strftime('%Y-%m-%d %H:%M'),
            'speed': SPEED,
            'ext': 'mp3',
            'lineCount': len(lines),
            'packs': packs,
        }, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
        print('清单：%s（%d 个音色）' % (manifest, len(packs)))
    print('这一轮写出去的音频共 %.1f MB' % (total_bytes / 1024 / 1024))
    return 0 if packs or limit else 1


def main():
    ap = argparse.ArgumentParser(description='东秦杀音色包生成器')
    ap.add_argument('--voices', help='逗号分隔的音色 id（默认用脚本顶部 VOICES 清单）')
    ap.add_argument('--force', action='store_true', help='已存在的文件也重生成')
    ap.add_argument('--audition', action='store_true', help='100 个音色各念一句，生成试听页')
    ap.add_argument('--limit', type=int, default=0, help='每个音色只做前 N 句（冒烟用）')
    args = ap.parse_args()

    if args.voices:
        want = [v.strip() for v in args.voices.split(',') if v.strip()]
        known = {v[0]: v for v in VOICES}
        voices = [(v, known[v][1], known[v][2]) if v in known else (v, v, 'female') for v in want]
    else:
        voices = VOICES

    pipe = make_pipeline()
    if args.audition:
        return run_audition(pipe, args.force)
    return run_generate(pipe, voices, args.force, args.limit)


if __name__ == '__main__':
    sys.exit(main())
