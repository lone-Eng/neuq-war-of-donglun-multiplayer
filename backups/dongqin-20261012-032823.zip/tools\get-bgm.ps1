# =========================================================
#  Fetch a public-domain background music track.
#
#  The tracks below come from FreePD (Kevin MacLeod's public-domain
#  catalogue, mirrored on archive.org). Public domain / CC0: no
#  attribution required, commercial use allowed.
#
#  Usage:
#    powershell -ExecutionPolicy Bypass -File tools\get-bgm.ps1
#    powershell -ExecutionPolicy Bypass -File tools\get-bgm.ps1 -List
#
#  The archive.org directory layout changes now and then. If every
#  candidate 404s this script says so and points at the browse page
#  instead of failing silently.
#
#  NOTE: this script must stay ASCII-only (PowerShell 5.1 reads .ps1 as ANSI).
# =========================================================
param(
  [switch]$List,
  [string]$Name = 'bgm'
)
$ErrorActionPreference = 'Stop'

$tools = Split-Path -Parent $MyInvocation.MyCommand.Path
$root  = Split-Path -Parent $tools
$dest  = Join-Path $root 'audio\bgm'
if (-not (Test-Path $dest)) { $null = New-Item -ItemType Directory -Path $dest }

# Candidate tracks, in preference order. All from the FreePD public-domain
# catalogue mirrored on archive.org. The one currently installed is the first.
$TRACKS = @(
  @{ file = 'Page2/Ambient J Thoughtful.mp3';    title = 'Ambient J Thoughtful' },
  @{ file = 'Page2/Ambient C Motion.mp3';        title = 'Ambient C Motion' },
  @{ file = 'Page2/Chill Dark.mp3';              title = 'Chill Dark' },
  @{ file = 'Page2/Urban Confused Mystery.mp3';  title = 'Urban Confused Mystery' },
  @{ file = 'Page2/Ambient K Slow Go.mp3';       title = 'Ambient K Slow Go' }
)

function Show-Sources {
  Write-Host ""
  Write-Host "Public-domain / free music sources:" -ForegroundColor Cyan
  Write-Host "  FreePD        https://freepd.com/                     (public domain, no attribution)"
  Write-Host "  Pixabay Music https://pixabay.com/music/              (Pixabay licence, no attribution)"
  Write-Host "  OpenGameArt   https://opengameart.org/                (check each track)"
  Write-Host "  incompetech   https://incompetech.com/music/royalty-free/  (CC-BY: credit required)"
  Write-Host ""
  Write-Host ("Save the file as: " + (Join-Path $dest 'bgm.mp3')) -ForegroundColor Green
  Write-Host ""
}

if ($List) { Show-Sources; exit 0 }

# The page you can browse if the direct links stop working.
$browse = 'https://archive.org/details/freepd'

Write-Host ""
Write-Host "Looking for a public-domain track..." -ForegroundColor Cyan
Write-Host ""

# Resolve the storage node FIRST. https://archive.org/download/<item>/<file>
# answers 500 for this item; the real file lives on a node host, and which node
# it is comes from the metadata API. (Learned the hard way.)
$base = $null
try {
  $meta = (Invoke-WebRequest 'https://archive.org/metadata/freepd' -UseBasicParsing -TimeoutSec 40).Content | ConvertFrom-Json
  if ($meta.d1 -and $meta.dir) { $base = 'https://' + $meta.d1 + $meta.dir }
} catch { $base = $null }

if (-not $base) {
  Write-Host "Could not reach the archive.org metadata API." -ForegroundColor Yellow
  Write-Host ("Browse here instead: " + $browse) -ForegroundColor Yellow
  Show-Sources
  exit 1
}
Write-Host ("  node: " + $base) -ForegroundColor DarkGray

$got = $null
foreach ($t in $TRACKS) {
  # Encode each path segment; the names contain spaces.
  $enc = (($t.file -split '/') | ForEach-Object { [uri]::EscapeDataString($_) }) -join '/'
  $url = $base + '/' + $enc
  $tmp = Join-Path $env:TEMP ('dqk-bgm-' + [System.Guid]::NewGuid().ToString('N').Substring(0, 8) + '.mp3')
  Write-Host ("  trying " + $t.title + " ...") -NoNewline
  try {
    Invoke-WebRequest $url -OutFile $tmp -UseBasicParsing -TimeoutSec 180
  } catch {
    Write-Host " failed" -ForegroundColor DarkGray
    if (Test-Path $tmp) { Remove-Item $tmp -Force }
    continue
  }
  # Trust nothing: confirm the bytes really are an audio container before
  # putting it in the project. A 404 page saved as .mp3 would otherwise be
  # copied in happily and show up much later as "music doesn't play".
  $bytes = [System.IO.File]::ReadAllBytes($tmp)
  $ok = $false
  if ($bytes.Length -gt 12) {
    $h = ($bytes[0..11] | ForEach-Object { $_.ToString('x2') }) -join ''
    # ID3 tag, or an MPEG frame sync (ff fb / ff f3 / ff f2), or RIFF/OGG
    if ($h -like '494433*' -or $h -like 'fffb*' -or $h -like 'fff3*' -or $h -like 'fff2*' -or
        $h -like '52494646*' -or $h -like '4f676753*') { $ok = $true }
  }
  if (-not $ok) {
    Write-Host " not audio (got " + $bytes.Length + " bytes)" -ForegroundColor DarkGray
    Remove-Item $tmp -Force
    continue
  }
  Write-Host (" ok  (" + [int]($bytes.Length / 1KB) + " KB)") -ForegroundColor Green
  $got = @{ tmp = $tmp; title = $t.title; size = $bytes.Length }
  break
}

Write-Host ""
if (-not $got) {
  Write-Host "Could not download any track." -ForegroundColor Yellow
  Write-Host ("The archive.org layout may have moved. Browse here instead: " + $browse) -ForegroundColor Yellow
  Show-Sources
  exit 1
}

$target = Join-Path $dest ($Name + '.mp3')
Move-Item $got.tmp $target -Force
Write-Host ("Saved: " + $target) -ForegroundColor Green
Write-Host ("Track: " + $got.title + "  (" + [int]($got.size / 1KB) + " KB)") -ForegroundColor Green
Write-Host "Licence: public domain (CC0) - no attribution needed." -ForegroundColor DarkGray
Write-Host ""
Write-Host "Now open the game, click anywhere, and the music starts." -ForegroundColor Cyan
Write-Host "Toggle / volume live in Settings." -ForegroundColor Cyan
Write-Host ""
